from __future__ import annotations
import json, os
from pathlib import Path
from datetime import datetime, timezone

BASE=Path(__file__).resolve().parent

def load(p):
    try:return json.loads(Path(p).read_text(encoding='utf-8'))
    except Exception:return {}
def save(p,o):
    p=Path(p);t=Path(str(p)+'.tmp');t.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n',encoding='utf-8');os.replace(t,p)

def main():
    sp=BASE/'server.py'
    text=sp.read_text(encoding='utf-8')
    text=text.replace('VERSION = "5.13.5.5-supervised-live"','VERSION = "5.13.5.6-supervised-live"',1)
    text=text.replace('UPGRADE_LABEL = "R5.8.1 — Verified Restart Updater — 2026-08-23"',
                      'UPGRADE_LABEL = "R5.8.2 — Updater End-to-End Proven — 2026-08-23"',1)
    sp.write_text(text,encoding='utf-8')
    bi=load(BASE/'BUILD_INFO.json')
    if bi:
        bi['compatibility_version']='5.13.5.6-supervised-live'
        bi['semantic_version']='5.13.5.6'
        bi['release']='R5.8.2 Updater End-to-End Proven'
        bi['patch']='R5.8.2'
        bi['sidebar_label']='v5.13.5.6 • R5.8.2 Updater Proven'
        bi['topbar_label']='v5.13.5.6 • R5.8.2'
        bi['full_label']="Andy's Bot v5.13.5.6 — R5.8.2 Updater End-to-End Proven"
        feats=list(bi.get('features') or [])
        if 'GitHub one-click updater end-to-end proof' not in feats:feats.append('GitHub one-click updater end-to-end proof')
        bi['features']=feats;bi['built_utc']=datetime.now(timezone.utc).isoformat()
        save(BASE/'BUILD_INFO.json',bi)
    (BASE/'UPDATER_END_TO_END_PROVEN.txt').write_text(
        'R5.8.2 updater proof installed successfully.\\n',encoding='utf-8'
    )
    return 0
if __name__=='__main__':raise SystemExit(main())
