@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "BOTURL=http://127.0.0.1:8765/"
set "HEALTH=http://127.0.0.1:8765/api/health"

rem Check whether Andy's Bot is already running.
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing '%HEALTH%' -TimeoutSec 2; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){exit 0}; exit 1 } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 goto :already_running

rem The desktop launcher owns browser opening. Prevent server.py from opening a second page.
set "CRYPTO_BOT_OPEN_BROWSER=0"

rem Start the normal verified bot entry point minimized.
start "Andy's Bot Engine" /min cmd /c ""%~dp000_START_HERE_V5_13_2.bat""

rem Wait up to 60 seconds for the local dashboard to become ready.
for /L %%N in (1,1,60) do (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing '%HEALTH%' -TimeoutSec 1; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){exit 0}; exit 1 } catch { exit 1 }" >nul 2>nul
  if not errorlevel 1 goto :open_dashboard
  timeout /t 1 /nobreak >nul
)

echo Andy's Bot did not become ready within 60 seconds.
echo Open the main bot folder and run 00_START_HERE_V5_13_2.bat to see any startup error.
pause
exit /b 1

:already_running
rem Do not create another browser tab/window. If the dashboard is already the active
rem browser tab, bring that window forward; otherwise leave the existing page alone.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; if(-not $w.AppActivate('Andy''s Bot')){ $null=$w.AppActivate('Andy’s Bot') }" >nul 2>nul
exit /b 0

:open_dashboard
start "" "%BOTURL%"
exit /b 0
