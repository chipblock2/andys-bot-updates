from pathlib import Path

ROOT = Path(__file__).resolve().parent
launcher = (ROOT / 'START_ANDYS_BOT_DESKTOP.bat').read_text(encoding='utf-8')
server = (ROOT / 'server.py').read_text(encoding='utf-8')

checks = {
    'launcher suppresses server browser auto-open': 'set "CRYPTO_BOT_OPEN_BROWSER=0"' in launcher,
    'launcher still opens dashboard once after startup': 'start "" "%BOTURL%"' in launcher,
    'already-running path exists': ':already_running' in launcher,
    'already-running path exits without dashboard start': ':already_running' in launcher and 'exit /b 0' in launcher.rsplit('\n:already_running',1)[1].split('\n:open_dashboard',1)[0] and 'start "" "%BOTURL%"' not in launcher.rsplit('\n:already_running',1)[1].split('\n:open_dashboard',1)[0],
    'server honours browser suppression environment': 'CRYPTO_BOT_OPEN_BROWSER' in server and 'threading.Thread(target=open_browser' in server,
    'health check remains': '127.0.0.1:8765/api/health' in launcher,
    'normal verified entry point remains': '00_START_HERE_V5_13_2.bat' in launcher,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
if failed:
    raise SystemExit('Failed: ' + ', '.join(failed))
print(f'{len(checks)}/{len(checks)} PASS')
