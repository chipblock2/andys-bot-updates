ANDY'S BOT — R5.6.2 SINGLE DASHBOARD LAUNCHER

What changed
------------
- Fixes the two-page startup problem on Windows.
- The desktop launcher now sets CRYPTO_BOT_OPEN_BROWSER=0 before starting the engine, so server.py does not open a second dashboard.
- The launcher opens exactly one dashboard after the health check passes.
- If Andy's Bot is already running, clicking the desktop shortcut again does not open another tab/window. It attempts to bring an existing Andy's Bot browser window forward and then exits.

Preserved live safety
---------------------
- Up to 8 supervised-live positions.
- £10 maximum per approved order.
- £20 maximum simultaneous live exposure.
- 4 new live entries/day.
- Manual PC Preview -> Approve remains mandatory.
- Existing positions, brackets, credentials, ledger, journals and evidence are preserved by the normal updater.

Normal use
----------
Use the desktop shortcut 'Andys Bot'. One click starts the engine and opens one dashboard page.
