#!/usr/bin/env python3
import json
import tempfile
from pathlib import Path

import coinbase_live_canary
from coinbase_live_ledger import LiveTradeLedger

ROOT = Path(__file__).resolve().parent


def intent(client_id="client-1"):
    return {
        "client_order_id": client_id,
        "product_id": "ETH-GBP",
        "symbol": "ETH",
        "side": "BUY",
        "quote_size": 9.09,
        "stop_price": 1732.24,
        "target_price": 1903.61,
        "manual_approval_id": "approval-1",
        "created_ts": 100.0,
        "ledger_recorded": True,
        "order_id": None,
    }


def test_intent_commit_is_idempotent_and_conflicts_fail_closed():
    with tempfile.TemporaryDirectory() as td:
        ledger = LiveTradeLedger(Path(td) / "ledger.db", clock=lambda: 200.0)
        first = ledger.create_intent(intent())
        second = ledger.create_intent(intent())
        assert first["client_order_id"] == second["client_order_id"]
        assert ledger.status()["intents"] == 1
        changed = intent()
        changed["quote_size"] = 8.00
        try:
            ledger.create_intent(changed)
        except RuntimeError as exc:
            assert "different live intent" in str(exc)
        else:
            raise AssertionError("conflicting idempotency key was accepted")


def test_unknown_submission_blocks_and_diagnostics_are_redacted():
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / "ledger.db"
        ledger = LiveTradeLedger(path, clock=lambda: 200.0)
        ledger.create_intent(intent())
        ledger.mark_submission_started("client-1")
        ledger.mark_submission_unknown(
            "client-1", "Authorization: Bearer abc123 private_key=xyz987 api_key=key456"
        )
        status = ledger.status()
        assert not status["ok"] and status["state"] == "RECONCILING"
        assert status["unknown_submissions"] == 1
        assert not status["credentials_stored"] and not status["submits_orders"]
        raw = path.read_bytes().lower()
        assert b"abc123" not in raw and b"xyz987" not in raw and b"key456" not in raw


def test_order_and_fill_events_are_append_only_and_deduplicated():
    with tempfile.TemporaryDirectory() as td:
        ledger = LiveTradeLedger(Path(td) / "ledger.db", clock=lambda: 200.0)
        ledger.create_intent(intent())
        ledger.mark_submission_started("client-1")
        ledger.mark_submitted("client-1", "order-1")
        order = {
            "order_id": "order-1", "client_order_id": "client-1", "status": "FILLED",
            "filled_size": "0.005", "filled_value": "9.00", "total_fees": "0.09",
            "average_filled_price": "1788.57", "attached_order_id": "child-1",
        }
        ledger.record_order("client-1", order)
        ledger.record_order("client-1", order)
        fill = {
            "entry_id": "fill-1", "order_id": "order-1", "price": "1788.57",
            "size": "0.005", "commission": "0.09",
        }
        assert ledger.record_fill("client-1", fill)
        assert not ledger.record_fill("client-1", fill)
        ledger.mark_position_open("client-1", "child-1")
        status = ledger.status()
        assert status["ok"] and status["events"] == 2 and status["open_positions"] == 1


class FakeCoinbase:
    def __init__(self, include_order=True):
        self.include_order = include_order
        self.posts = 0
        self.parent = {
            "order_id": "order-1", "client_order_id": "client-1", "product_id": "ETH-GBP",
            "status": "FILLED", "filled_size": "0.005", "filled_value": "9.00",
            "total_fees": "0.09", "average_filled_price": "1788.57",
            "attached_order_id": "child-1",
        }
        self.child = {
            "order_id": "child-1", "status": "OPEN",
            "order_configuration": {
                "trigger_bracket_gtc": {"limit_price": "1903.61", "stop_trigger_price": "1732.24"}
            },
        }

    def get(self, path, params=None):
        if path == "/api/v3/brokerage/orders/historical/batch":
            return {"orders": [self.parent] if self.include_order else []}
        if path.startswith("/api/v3/brokerage/orders/historical/fills"):
            return {"fills": [{
                "entry_id": "fill-1", "order_id": "order-1", "price": "1788.57",
                "size": "0.005", "commission": "0.09",
            }]}
        if path.endswith("/order-1"):
            return {"order": self.parent}
        if path.endswith("/child-1"):
            return {"order": self.child}
        raise AssertionError("unexpected GET " + path)

    def post(self, *args, **kwargs):
        self.posts += 1
        raise AssertionError("reconciliation must never submit an order")


def test_restart_recovers_exact_client_order_id_without_resubmission():
    with tempfile.TemporaryDirectory() as td:
        ledger = LiveTradeLedger(Path(td) / "ledger.db", clock=lambda: 200.0)
        ledger.create_intent(intent())
        ledger.mark_submission_started("client-1")
        ledger.mark_submission_unknown("client-1", "connection reset")
        service = coinbase_live_canary.LiveCanaryService(ledger=ledger)
        state = coinbase_live_canary._blank_state()
        state["pending_order"] = intent()
        state["pending_order"]["restored_from_ledger"] = True
        client = FakeCoinbase(include_order=True)
        service._reconcile_pending(client, state)
        assert client.posts == 0
        assert state["pending_order"] is None and "ETH" in state["positions"]
        assert state["positions"]["ETH"]["attached_order_id"] == "child-1"
        assert ledger.status()["state"] == "VERIFIED"


def test_unmatched_unknown_result_stays_blocked_without_retry():
    with tempfile.TemporaryDirectory() as td:
        ledger = LiveTradeLedger(Path(td) / "ledger.db", clock=lambda: 200.0)
        ledger.create_intent(intent())
        ledger.mark_submission_started("client-1")
        ledger.mark_submission_unknown("client-1", "timeout")
        service = coinbase_live_canary.LiveCanaryService(ledger=ledger)
        state = coinbase_live_canary._blank_state()
        state["pending_order"] = intent()
        client = FakeCoinbase(include_order=False)
        service._reconcile_pending(client, state)
        assert client.posts == 0 and state["pending_order"] is not None
        assert state["ledger_reconciling"]
        ok, reason = service._limits_ok(state, {})
        assert not ok and "history" in reason.lower()


def test_r5_6_release_dashboard_and_preservation_contract():
    package = json.loads((ROOT / "UPDATE_PACKAGE.json").read_text(encoding="utf-8"))
    build = json.loads((ROOT / "BUILD_INFO.json").read_text(encoding="utf-8"))
    html = (ROOT / "dashboard.html").read_text(encoding="utf-8")
    manager = (ROOT / "update_manager.py").read_text(encoding="utf-8")
    ledger_source = (ROOT / "coinbase_live_ledger.py").read_text(encoding="utf-8")
    assert package["version"] == "5.13.5" and package["migration_script"] == "migrate_r5_6.py"
    assert build["patch"] == "R5.6" and "Authoritative Trade Ledger" in build["release"]
    assert "coinbase_live_ledger.py" in package["required_files"]
    assert "andys_bot_live_ledger.db" in package["preserves"] and "andys_bot_live_ledger.db" in manager
    assert "LIVE LEDGER VERIFIED" in html and "LIVE LEDGER RECONCILING" in html
    assert "£10/order" in html and "£20 total exposure" in html and "manual PC approval required" in html
    assert ".post(" not in ledger_source and "CREATE TABLE" in ledger_source


if __name__ == "__main__":
    tests = sorted((name, fn) for name, fn in globals().items() if name.startswith("test_") and callable(fn))
    for name, function in tests:
        function()
        print("PASS", name)
    print(f"RESULT {len(tests)}/{len(tests)} passed")
