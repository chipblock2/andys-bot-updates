#!/usr/bin/env python3
"""Durable, credential-free ledger for supervised Coinbase live orders.

The ledger records an approved client_order_id *before* the network submission.
If the process or connection fails after that point, the same identifier can be
reconciled against Coinbase without creating a second order.  This module never
creates, edits, cancels, or transfers anything and never stores credentials.
"""
from __future__ import annotations

import hashlib
import re
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent
DB_FILE = BASE_DIR / "andys_bot_live_ledger.db"
SCHEMA_VERSION = 1

UNKNOWN_STATES = {"INTENT_RECORDED", "SUBMISSION_STARTED", "UNKNOWN_SUBMISSION"}
PENDING_STATES = {"SUBMITTED", "ACKNOWLEDGED", "PARTIALLY_FILLED"}
FINAL_STATES = {"POSITION_OPEN", "POSITION_CLOSED", "RESOLVED_NO_FILL"}


def _number(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _clean_error(value: Any) -> str:
    """Keep diagnostics useful without persisting a credential-bearing exception."""
    text = str(value or "unknown error")[:1000]
    patterns = (
        r"(?i)(authorization\s*[:=]\s*)([^\s,;]+)",
        r"(?i)(bearer\s+)([^\s,;]+)",
        r"(?i)((?:api[_ -]?key|private[_ -]?key|secret|passphrase)\s*[:=]\s*)([^\s,;]+)",
    )
    for pattern in patterns:
        text = re.sub(pattern, lambda match: match.group(1) + "[REDACTED]", text)
    return text[:500]


class LiveTradeLedger:
    """SQLite order-intent/event ledger with idempotent writes and integrity checks."""

    def __init__(self, path: Path | str = DB_FILE, clock=time.time):
        self.path = Path(path)
        self.clock = clock
        self._lock = threading.RLock()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialise()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=10.0)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=10000")
        return connection

    def _initialise(self) -> None:
        with self._lock, self._connect() as connection:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("PRAGMA synchronous=FULL")
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS ledger_meta(
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS order_intents(
                    client_order_id TEXT PRIMARY KEY,
                    created_ts REAL NOT NULL,
                    updated_ts REAL NOT NULL,
                    product_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    side TEXT NOT NULL CHECK(side IN ('BUY','SELL')),
                    quote_size_gbp REAL NOT NULL CHECK(quote_size_gbp > 0),
                    stop_price REAL NOT NULL CHECK(stop_price > 0),
                    target_price REAL NOT NULL CHECK(target_price > 0),
                    manual_approval_id TEXT,
                    state TEXT NOT NULL,
                    exchange_order_id TEXT UNIQUE,
                    attached_order_id TEXT,
                    last_exchange_status TEXT,
                    last_error TEXT
                );
                CREATE TABLE IF NOT EXISTS order_events(
                    event_key TEXT PRIMARY KEY,
                    client_order_id TEXT NOT NULL,
                    exchange_order_id TEXT,
                    event_type TEXT NOT NULL,
                    exchange_status TEXT,
                    filled_size REAL NOT NULL DEFAULT 0,
                    filled_value REAL NOT NULL DEFAULT 0,
                    fees REAL NOT NULL DEFAULT 0,
                    price REAL NOT NULL DEFAULT 0,
                    source TEXT NOT NULL,
                    seen_ts REAL NOT NULL,
                    FOREIGN KEY(client_order_id) REFERENCES order_intents(client_order_id)
                );
                CREATE TABLE IF NOT EXISTS reconciliation_runs(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    started_ts REAL NOT NULL,
                    completed_ts REAL NOT NULL,
                    ok INTEGER NOT NULL,
                    unknown_count INTEGER NOT NULL,
                    message TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_intent_state ON order_intents(state);
                CREATE INDEX IF NOT EXISTS idx_event_order ON order_events(exchange_order_id);
                """
            )
            connection.execute(
                "INSERT OR REPLACE INTO ledger_meta(key,value) VALUES('schema_version',?)",
                (str(SCHEMA_VERSION),),
            )

    @staticmethod
    def _dict(row: sqlite3.Row | None) -> dict:
        return dict(row) if row is not None else {}

    @staticmethod
    def _intent_values(intent: dict) -> tuple:
        side = str(intent.get("side") or "BUY").upper()
        if side not in {"BUY", "SELL"}:
            raise ValueError("Live ledger side must be BUY or SELL")
        values = (
            str(intent.get("client_order_id") or "").strip(),
            str(intent.get("product_id") or "").strip().upper(),
            str(intent.get("symbol") or "").strip().upper(),
            side,
            _number(intent.get("quote_size"), _number(intent.get("quote_size_gbp"))),
            _number(intent.get("stop_price")),
            _number(intent.get("target_price")),
            str(intent.get("manual_approval_id") or "")[:160],
        )
        if not values[0] or not values[1] or not values[2]:
            raise ValueError("Live ledger intent is missing its client ID, product, or symbol")
        if min(values[4], values[5], values[6]) <= 0:
            raise ValueError("Live ledger intent has an invalid size, stop, or target")
        return values

    def create_intent(self, intent: dict) -> dict:
        """Atomically record an approved order; identical retries are idempotent."""
        client_id, product, symbol, side, quote, stop, target, approval = self._intent_values(intent)
        now = float(self.clock())
        with self._lock, self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT * FROM order_intents WHERE client_order_id=?", (client_id,)
            ).fetchone()
            if existing is not None:
                row = dict(existing)
                expected = (product, symbol, side, round(quote, 8), round(stop, 12), round(target, 12))
                actual = (
                    row["product_id"], row["symbol"], row["side"],
                    round(float(row["quote_size_gbp"]), 8), round(float(row["stop_price"]), 12),
                    round(float(row["target_price"]), 12),
                )
                if actual != expected:
                    raise RuntimeError("client_order_id already belongs to a different live intent")
                return row
            connection.execute(
                """INSERT INTO order_intents(
                       client_order_id,created_ts,updated_ts,product_id,symbol,side,
                       quote_size_gbp,stop_price,target_price,manual_approval_id,state
                   ) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (client_id, now, now, product, symbol, side, quote, stop, target, approval, "INTENT_RECORDED"),
            )
            return self._dict(connection.execute(
                "SELECT * FROM order_intents WHERE client_order_id=?", (client_id,)
            ).fetchone())

    def register_existing_position(self, position: dict) -> dict:
        """Backfill a pre-R5.6 protected position without changing it on Coinbase."""
        order_id = str(position.get("order_id") or "").strip()
        if not order_id:
            raise ValueError("Existing position has no Coinbase parent order ID")
        with self._lock, self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM order_intents WHERE exchange_order_id=?", (order_id,)
            ).fetchone()
            if row is not None:
                return dict(row)
        symbol = str(position.get("symbol") or str(position.get("product_id") or "").split("-")[0]).upper()
        client_id = "legacy:" + order_id
        now = float(self.clock())
        quote = max(0.00000001, _number(position.get("entry_cost_gbp"), 0.00000001))
        stop = max(0.00000001, _number(position.get("stop_price"), 0.00000001))
        target = max(0.00000001, _number(position.get("target_price"), 0.00000001))
        with self._lock, self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """INSERT OR IGNORE INTO order_intents(
                       client_order_id,created_ts,updated_ts,product_id,symbol,side,
                       quote_size_gbp,stop_price,target_price,manual_approval_id,state,
                       exchange_order_id,attached_order_id,last_exchange_status
                   ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    client_id, _number(position.get("opened_ts"), now), now,
                    str(position.get("product_id") or f"{symbol}-GBP").upper(), symbol, "BUY",
                    quote, stop, target, "IMPORTED_PRE_R5_6", "POSITION_OPEN", order_id,
                    str(position.get("attached_order_id") or ""), "FILLED",
                ),
            )
            return self._dict(connection.execute(
                "SELECT * FROM order_intents WHERE exchange_order_id=?", (order_id,)
            ).fetchone())

    def _update(self, client_order_id: str, state: str, **fields) -> dict:
        allowed = {"exchange_order_id", "attached_order_id", "last_exchange_status", "last_error"}
        bad = set(fields) - allowed
        if bad:
            raise ValueError("Unsupported live ledger field: " + ", ".join(sorted(bad)))
        values = {key: fields[key] for key in fields}
        values["state"] = state
        values["updated_ts"] = float(self.clock())
        columns = ",".join(f"{key}=?" for key in values)
        with self._lock, self._connect() as connection:
            cursor = connection.execute(
                f"UPDATE order_intents SET {columns} WHERE client_order_id=?",
                tuple(values.values()) + (str(client_order_id),),
            )
            if cursor.rowcount != 1:
                raise RuntimeError("Live ledger intent was not found")
            return self._dict(connection.execute(
                "SELECT * FROM order_intents WHERE client_order_id=?", (str(client_order_id),)
            ).fetchone())

    def mark_submission_started(self, client_order_id: str) -> dict:
        return self._update(client_order_id, "SUBMISSION_STARTED", last_error=None)

    def mark_submission_unknown(self, client_order_id: str, error: Any) -> dict:
        return self._update(client_order_id, "UNKNOWN_SUBMISSION", last_error=_clean_error(error))

    def mark_submitted(self, client_order_id: str, exchange_order_id: str) -> dict:
        order_id = str(exchange_order_id or "").strip()
        if not order_id:
            raise ValueError("Coinbase order ID is required")
        return self._update(
            client_order_id, "SUBMITTED", exchange_order_id=order_id,
            last_exchange_status="SUBMITTED", last_error=None,
        )

    def mark_resolved_no_fill(self, client_order_id: str, status: str, error: Any = None) -> dict:
        return self._update(
            client_order_id, "RESOLVED_NO_FILL",
            last_exchange_status=str(status or "NO_FILL").upper(),
            last_error=_clean_error(error) if error else None,
        )

    def record_order(self, client_order_id: str, order: dict, source: str = "COINBASE_REST") -> dict:
        order_id = str(order.get("order_id") or "").strip()
        status = str(order.get("status") or "UNKNOWN").upper()
        filled_size = _number(order.get("filled_size"))
        filled_value = _number(order.get("filled_value"))
        fees = _number(order.get("total_fees"))
        price = _number(order.get("average_filled_price"))
        attached = str(order.get("attached_order_id") or "").strip()
        if not order_id:
            raise ValueError("Coinbase order response has no order_id")
        supplied_client_id = str(order.get("client_order_id") or "").strip()
        if supplied_client_id and supplied_client_id != str(client_order_id):
            raise RuntimeError("Coinbase order client ID does not match the durable live intent")
        if status == "FILLED" or filled_size > 0:
            state = "PARTIALLY_FILLED" if status != "FILLED" else "FILLED"
        elif status in {"CANCELLED", "CANCELED", "FAILED", "REJECTED", "EXPIRED"}:
            state = "RESOLVED_NO_FILL"
        elif status in {"OPEN", "PENDING", "QUEUED", "CANCEL_QUEUED", "EDIT_QUEUED"}:
            state = "ACKNOWLEDGED"
        else:
            state = "SUBMITTED"
        key_material = "|".join((order_id, status, str(filled_size), str(filled_value), str(fees), attached))
        event_key = "order:" + hashlib.sha256(key_material.encode("utf-8")).hexdigest()
        with self._lock, self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT exchange_order_id FROM order_intents WHERE client_order_id=?", (str(client_order_id),)
            ).fetchone()
            if existing is None:
                raise RuntimeError("Live ledger intent was not found")
            if existing[0] and str(existing[0]) != order_id:
                raise RuntimeError("Coinbase order ID conflicts with the durable live intent")
            connection.execute(
                """UPDATE order_intents SET updated_ts=?,state=?,exchange_order_id=?,attached_order_id=?,
                       last_exchange_status=?,last_error=NULL WHERE client_order_id=?""",
                (float(self.clock()), state, order_id, attached or None, status, str(client_order_id)),
            )
            connection.execute(
                """INSERT OR IGNORE INTO order_events(
                       event_key,client_order_id,exchange_order_id,event_type,exchange_status,
                       filled_size,filled_value,fees,price,source,seen_ts
                   ) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    event_key, str(client_order_id), order_id, "ORDER_SNAPSHOT", status,
                    filled_size, filled_value, fees, price, str(source)[:80], float(self.clock()),
                ),
            )
            return self._dict(connection.execute(
                "SELECT * FROM order_intents WHERE client_order_id=?", (str(client_order_id),)
            ).fetchone())

    def record_fill(self, client_order_id: str, fill: dict, source: str = "COINBASE_REST_FILLS") -> bool:
        order_id = str(fill.get("order_id") or "").strip()
        entry_id = str(fill.get("entry_id") or fill.get("trade_id") or "").strip()
        if not order_id:
            return False
        material = entry_id or "|".join(
            str(fill.get(key) or "") for key in ("order_id", "trade_time", "price", "size", "commission")
        )
        event_key = "fill:" + hashlib.sha256(material.encode("utf-8")).hexdigest()
        with self._lock, self._connect() as connection:
            cursor = connection.execute(
                """INSERT OR IGNORE INTO order_events(
                       event_key,client_order_id,exchange_order_id,event_type,exchange_status,
                       filled_size,filled_value,fees,price,source,seen_ts
                   ) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    event_key, str(client_order_id), order_id, "FILL", "FILLED",
                    _number(fill.get("size")), 0.0, _number(fill.get("commission")),
                    _number(fill.get("price")), str(source)[:80], float(self.clock()),
                ),
            )
            return cursor.rowcount == 1

    def mark_position_open(self, client_order_id: str, attached_order_id: str) -> dict:
        return self._update(
            client_order_id, "POSITION_OPEN", attached_order_id=str(attached_order_id),
            last_exchange_status="FILLED", last_error=None,
        )

    def mark_position_closed(self, parent_order_id: str, child_order: dict) -> dict:
        with self._lock, self._connect() as connection:
            row = connection.execute(
                "SELECT client_order_id FROM order_intents WHERE exchange_order_id=?", (str(parent_order_id),)
            ).fetchone()
        if row is None:
            return {}
        client_id = str(row[0])
        child_id = str(child_order.get("order_id") or "").strip()
        status = str(child_order.get("status") or "UNKNOWN").upper()
        material = "|".join((str(parent_order_id), child_id, status, str(child_order.get("filled_value") or "")))
        event_key = "exit:" + hashlib.sha256(material.encode("utf-8")).hexdigest()
        with self._lock, self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """INSERT OR IGNORE INTO order_events(
                       event_key,client_order_id,exchange_order_id,event_type,exchange_status,
                       filled_size,filled_value,fees,price,source,seen_ts
                   ) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    event_key, client_id, child_id or str(parent_order_id), "POSITION_EXIT", status,
                    _number(child_order.get("filled_size")), _number(child_order.get("filled_value")),
                    _number(child_order.get("total_fees")), _number(child_order.get("average_filled_price")),
                    "COINBASE_EXIT_RECONCILIATION", float(self.clock()),
                ),
            )
            connection.execute(
                """UPDATE order_intents SET updated_ts=?,state='POSITION_CLOSED',
                       last_exchange_status='POSITION_CLOSED',last_error=NULL WHERE client_order_id=?""",
                (float(self.clock()), client_id),
            )
            return self._dict(connection.execute(
                "SELECT * FROM order_intents WHERE client_order_id=?", (client_id,)
            ).fetchone())

    def intent(self, client_order_id: str) -> dict:
        with self._lock, self._connect() as connection:
            return self._dict(connection.execute(
                "SELECT * FROM order_intents WHERE client_order_id=?", (str(client_order_id),)
            ).fetchone())

    def unresolved_intents(self) -> list[dict]:
        states = sorted(UNKNOWN_STATES | PENDING_STATES | {"FILLED"})
        marks = ",".join("?" for _ in states)
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                f"SELECT * FROM order_intents WHERE state IN ({marks}) ORDER BY created_ts", states
            ).fetchall()
            return [dict(row) for row in rows]

    def unknown_intents(self) -> list[dict]:
        states = sorted(UNKNOWN_STATES)
        marks = ",".join("?" for _ in states)
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                f"SELECT * FROM order_intents WHERE state IN ({marks}) ORDER BY created_ts", states
            ).fetchall()
            return [dict(row) for row in rows]

    def submitted_today(self) -> int:
        now = float(self.clock())
        day_start = now - (now % 86400.0)
        ignored = ("INTENT_RECORDED", "RESOLVED_NO_FILL")
        with self._lock, self._connect() as connection:
            return int(connection.execute(
                """SELECT COUNT(*) FROM order_intents
                   WHERE created_ts>=? AND state NOT IN (?,?)""",
                (day_start, *ignored),
            ).fetchone()[0])

    def record_reconciliation(self, ok: bool, message: str) -> None:
        now = float(self.clock())
        unknown = len(self.unknown_intents())
        with self._lock, self._connect() as connection:
            connection.execute(
                """INSERT INTO reconciliation_runs(started_ts,completed_ts,ok,unknown_count,message)
                   VALUES(?,?,?,?,?)""",
                (now, now, 1 if ok else 0, unknown, _clean_error(message)),
            )

    def integrity_report(self) -> dict:
        issues: list[str] = []
        with self._lock, self._connect() as connection:
            check = connection.execute("PRAGMA integrity_check").fetchone()
            if not check or str(check[0]).lower() != "ok":
                issues.append("SQLite integrity check failed")
            conflicts = connection.execute(
                """SELECT exchange_order_id,COUNT(*) FROM order_intents
                   WHERE exchange_order_id IS NOT NULL GROUP BY exchange_order_id HAVING COUNT(*)>1"""
            ).fetchall()
            if conflicts:
                issues.append("duplicate Coinbase order IDs detected")
        return {"ok": not issues, "issues": issues}

    def status(self) -> dict:
        integrity = self.integrity_report()
        with self._lock, self._connect() as connection:
            counts = {
                str(row[0]): int(row[1])
                for row in connection.execute("SELECT state,COUNT(*) FROM order_intents GROUP BY state")
            }
            intents = int(connection.execute("SELECT COUNT(*) FROM order_intents").fetchone()[0])
            events = int(connection.execute("SELECT COUNT(*) FROM order_events").fetchone()[0])
            last = connection.execute(
                "SELECT completed_ts,ok,unknown_count,message FROM reconciliation_runs ORDER BY id DESC LIMIT 1"
            ).fetchone()
        unknown = sum(counts.get(state, 0) for state in UNKNOWN_STATES)
        pending = sum(counts.get(state, 0) for state in PENDING_STATES)
        ok = bool(integrity.get("ok")) and unknown == 0
        return {
            "ok": ok,
            "state": "VERIFIED" if ok else "RECONCILING",
            "schema_version": SCHEMA_VERSION,
            "database": self.path.name,
            "intents": intents,
            "events": events,
            "unknown_submissions": unknown,
            "known_pending_orders": pending,
            "open_positions": counts.get("POSITION_OPEN", 0),
            "last_reconciled_ts": float(last[0]) if last else None,
            "last_reconciliation_ok": bool(last[1]) if last else None,
            "last_message": str(last[3]) if last else "Ledger initialised; no unresolved submission.",
            "integrity": integrity,
            "credentials_stored": False,
            "submits_orders": False,
            "edits_orders": False,
            "cancels_orders": False,
            "transfers": False,
        }
