#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import engine
import monitoring
import kraken_orderbook
import coinbase_orderbook
import coinbase_readonly
import coinbase_live_canary
import kraken_private
import market_scanner
import market_radar
import meme_intelligence
import strategy_lab
import memory_store
import bot_supervisor
import order_flow
import executor_engine
import adaptive_supervisor
import fast_paper
import review_engine
import review_export
import review_journal
import counterfactual_lab
import market_maker_lab
import shadow_gate_lab
import execution_core
import edge_profiles
import okx_intelligence
import news_social
import catalyst_intelligence
import update_manager
import evidence_quality
import coinbase_order_monitor
import chart_data
import market_recorder
import market_replay
import liquidity_reversal_lab
import multi_exchange_reference
import historical_robustness
import regime_lab
import capabilities
import mobile_access
import remote_monitor

BASE_DIR = Path(__file__).resolve().parent
HTML_FILE = BASE_DIR / "dashboard.html"
PORT = 8765
VERSION = "5.13.5-supervised-live"
UPGRADE_LABEL = "Authoritative Trade Ledger R5.6 — durable intent, idempotent recovery and fail-closed reconciliation — 2026-08-22"
BUILD_INFO_FILE = BASE_DIR / "BUILD_INFO.json"

def build_info():
    default={
        "product":"Andy\'s Bot — Crypto AI Autopilot",
        "compatibility_version":VERSION,
        "semantic_version":"5.13.2",
        "release":"Multi-Venue Edge R5.1",
        "patch":"R5.1",
        "sidebar_label":"v5.13.2 • Multi-Venue Edge R5.1",
        "topbar_label":"v5.13.2 • R5.1",
        "full_label":"Andy\'s Bot v5.13.2 — Multi-Venue Edge R5",
    }
    try:
        raw=json.loads(BUILD_INFO_FILE.read_text(encoding="utf-8"))
        if isinstance(raw,dict): default.update(raw)
    except Exception:
        pass
    return default

ENGINE_CYCLE_SECONDS = max(5, int(engine.CFG.get("engine_cycle_seconds", 15)))

STOP = threading.Event()
WAKE = threading.Event()
CACHE = {"payload": None, "error": None, "heartbeat": None, "cycle_seconds": None, "supervisor": None, "model_completed_ts": None, "cycle_started_ts": None, "cycle_in_progress": False}
CONTROL_LOCK = threading.Lock()
CONTROL = {"pending_paper_balance": None, "requested_at": None, "last_applied_balance": None, "last_applied_at": None, "last_error": None}

def queue_paper_balance(value) -> dict:
    try: amount=round(float(value),2)
    except Exception: return {"ok":False,"error":"Enter a valid paper balance."}
    if amount<=0 or amount>1_000_000_000:
        return {"ok":False,"error":"Paper balance must be greater than £0 and within the paper-test limit."}
    with CONTROL_LOCK:
        CONTROL["pending_paper_balance"]=amount; CONTROL["requested_at"]=time.time(); CONTROL["last_error"]=None
    WAKE.set()
    return {"ok":True,"accepted":True,"pending":True,"requested_balance":amount,
            "message":f"Applying paper balance £{amount:,.2f} safely at the next engine boundary…"}

def apply_control_requests():
    with CONTROL_LOCK:
        amount=CONTROL.get("pending_paper_balance")
        if amount is None: return
        CONTROL["pending_paper_balance"]=None
    try:
        result=engine.set_paper_balance(amount)
        with CONTROL_LOCK:
            if result.get("ok"):
                CONTROL["last_applied_balance"]=amount; CONTROL["last_applied_at"]=time.time(); CONTROL["last_error"]=None
                try: fast_paper.SERVICE.reset(amount)
                except Exception: pass
                try: market_maker_lab.SERVICE.reset(amount)
                except Exception: pass
                try: shadow_gate_lab.SERVICE.reset(amount)
                except Exception: pass
            else: CONTROL["last_error"]=result.get("error") or "Balance update failed"
    except Exception as exc:
        with CONTROL_LOCK: CONTROL["last_error"]=str(exc)


def startup_audit() -> dict:
    """Fail-closed audit of PAPER state and the durable supervised-live ledger."""
    try:
        reconciliation=execution_core.reconcile_stale_orders(
            max_age_seconds=float(engine.CFG.get("execution_intent_ttl_seconds",300.0))
        )
        integrity=execution_core.integrity_report()
        st = engine.load_state()
        issues=[]
        if not reconciliation.get("ok"):
            issues.append("paper order reconciliation failed: "+str(reconciliation.get("error") or "unknown error"))
        if not integrity.get("ok"):
            issues.extend("paper order ledger: "+str(x) for x in integrity.get("issues",[])[:10])
        if float(st.get("cash_gbp", 0.0)) < -0.01:
            issues.append("negative paper cash")
        positions=st.get("positions") or {}
        open_count=0
        for sym,p in positions.items():
            if float((p or {}).get("qty",0.0))>0:
                open_count+=1
                if (p or {}).get("venue") not in (None,"Coinbase"):
                    issues.append(f"{sym} paper position is not Coinbase-bound")
        if open_count>int(engine.CFG.get("max_total_open_positions",1)):
            issues.append("paper position count exceeds configured maximum")
        live_ledger=coinbase_live_canary.SERVICE.ledger.status()
        if not (live_ledger.get("integrity") or {}).get("ok"):
            issues.extend("live order ledger: "+str(x) for x in (live_ledger.get("integrity") or {}).get("issues",[])[:10])
        if int(live_ledger.get("unknown_submissions") or 0)>0:
            issues.append("live order ledger has an unresolved Coinbase submission; new approvals remain blocked")
        return {"ok":not issues,"issues":issues,"paper_state_checked":True,
                "paper_order_reconciliation":reconciliation,"paper_order_integrity":integrity,
                "live_order_reconciliation":live_ledger}
    except Exception as exc:
        return {"ok":False,"issues":[str(exc)],"paper_state_checked":False,
                "live_order_reconciliation":{"ok":False,"state":"RECONCILING","last_message":str(exc)}}


STARTUP_AUDIT = startup_audit()


def _feed_health(last_success_ts: float | int | None, last_error: str | None, stale_after: float, now: float | None = None) -> dict:
    now = time.time() if now is None else float(now)
    ts = float(last_success_ts or 0.0)
    age = None if ts <= 0 else max(0.0, now - ts)
    if ts <= 0:
        state = "ERROR" if last_error else "WARMING"
    elif age is not None and age > float(stale_after):
        state = "STALE"
    elif last_error:
        state = "DEGRADED"
    else:
        state = "DATA OK"
    return {"state": state, "last_success_ts": ts or None, "age_seconds": age, "last_error": last_error}




def _coinbase_health(status: dict, now: float | None = None) -> dict:
    """Report Coinbase transport modes without conflating safe REST with failure.

    Coinbase documents level2 as the synchronised order-book stream and recommends
    heartbeats to keep subscriptions open. The bot therefore distinguishes fresh L2,
    mixed realtime coverage, fresh REST safety snapshots, and genuinely stale data.
    Authentication is reported separately from transport health.
    """
    now = time.time() if now is None else float(now)
    book_ts=float(status.get("last_book_ts") or 0.0); book_age=None if book_ts<=0 else max(0.0,now-book_ts)
    msg_ts=float(status.get("last_message_ts") or 0.0); msg_age=None if msg_ts<=0 else max(0.0,now-msg_ts)
    trade_ts=float(status.get("last_trade_ts") or 0.0); trade_age=None if trade_ts<=0 else max(0.0,now-trade_ts)
    hb_ts=float(status.get("last_heartbeat_ts") or 0.0); hb_age=None if hb_ts<=0 else max(0.0,now-hb_ts)
    rest_ts=float(status.get("last_rest_ts") or 0.0); rest_age=None if rest_ts<=0 else max(0.0,now-rest_ts)
    source=str(status.get("book_source") or "")
    ages=status.get("l2_age_by_product") or {}
    if not ages:
        l2_ts=float(status.get("last_l2_ts") or 0.0)
        ages={"ALL":None if l2_ts<=0 else max(0.0,now-l2_ts)}
    vals=list(ages.values())
    fresh=[v is not None and float(v)<=20.0 for v in vals]
    all_l2_fresh=bool(fresh) and all(fresh)
    any_l2_fresh=any(fresh)
    rest_fresh=(rest_age is not None and rest_age<=45.0) or ("REST" in source.upper() and book_age is not None and book_age<=45.0)
    trade_fresh=trade_age is not None and trade_age<=20.0
    heartbeat_fresh=hb_age is not None and hb_age<=10.0
    ws_auth=bool(status.get("ws_authenticated"))

    if book_ts<=0:
        state="ERROR" if status.get("last_error") else "WARMING"
        detail=status.get("last_error") or "Waiting for first Coinbase book."
    elif book_age is not None and book_age>45.0:
        state="STALE"; detail=f"Coinbase book is {book_age:.0f}s old."
    elif all_l2_fresh:
        state="DATA OK"
        detail="Fresh Coinbase Advanced Trade L2 is primary for every monitored product."
        if trade_age is not None and trade_age>120.0:
            state="DEGRADED"; detail="L2 is fresh but market-trade updates are stale."
    elif any_l2_fresh:
        state="DEGRADED"; detail="Realtime L2 is fresh for only part of the monitored set; fresh REST snapshots cover the gap."
    elif rest_fresh:
        state="REST SAFE"
        if trade_fresh or heartbeat_fresh:
            detail="Fresh Coinbase REST order book is the safety source while the WebSocket remains alive/recovering."
        else:
            detail="Fresh Coinbase REST order book is available; realtime L2 is currently unavailable."
    elif heartbeat_fresh:
        state="DEGRADED"; detail="Coinbase heartbeat is alive but neither L2 nor a fresh REST book is available."
    else:
        state="DEGRADED"; detail=status.get("last_error") or "Coinbase realtime sub-feeds are not current."

    l2_age=max([float(v) for v in vals if v is not None], default=None)
    return {
        "state":state,"last_success_ts":book_ts or None,"age_seconds":book_age,"last_error":status.get("last_error"),
        "detail":detail,"source":source,"l2_age_seconds":l2_age,"l2_age_by_product":ages,"message_age_seconds":msg_age,
        "trade_age_seconds":trade_age,"heartbeat_age_seconds":hb_age,"rest_age_seconds":rest_age,"ws_authenticated":ws_auth,
        "subfeeds":{
            "l2_socket":"CONNECTED" if status.get("l2_connected") else "RECONNECTING",
            "l2":"DATA OK" if all_l2_fresh else ("DEGRADED" if any_l2_fresh else "OFF/STALE"),
            "trades_socket":"CONNECTED" if status.get("flow_connected") else "RECONNECTING",
            "market_trades":"DATA OK" if trade_fresh else "STALE",
            "heartbeat":"DATA OK" if heartbeat_fresh else "STALE",
            "rest":"DATA OK" if rest_fresh else "STALE",
            "auth":"READ-ONLY" if ws_auth else "PUBLIC",
        },
    }

def _payload_with_model_age() -> dict:
    d=dict(CACHE.get("payload") or {})
    done=float(CACHE.get("model_completed_ts") or 0.0)
    age=None if done<=0 else max(0.0,time.time()-done)
    d["model_age_seconds"]=age
    d["model_state"]="WARMING" if age is None else ("STALE" if age>float(engine.CFG.get("fast_paper_max_model_age_seconds",180.0)) else "FRESH")
    d["model_cycle_in_progress"]=bool(CACHE.get("cycle_in_progress"))
    d["last_model_cycle_seconds"]=CACHE.get("cycle_seconds")
    return d


def worker():
    """Full model worker.

    v5.12.3 targets a start-to-start cadence. Expensive model work no longer blocks
    recorder/journal sampling, which run in a separate evidence worker below.
    """
    while not STOP.is_set():
        t0=time.time();CACHE["cycle_started_ts"]=t0;CACHE["cycle_in_progress"]=True
        try:
            apply_control_requests();data=engine.cycle();data["version"]=VERSION;data["upgrade_label"]=UPGRADE_LABEL
            live=coinbase_live_canary.SERVICE.process(data,engine.CFG)
            data["live_canary"]=live
            data["live_trading_enabled"]=bool(live.get("armed"))
            data["paper_only"]=not bool(live.get("armed"))
            data["live_locked"]=not bool(live.get("ready"))
            CACHE["payload"]=data;CACHE["error"]=None;CACHE["model_completed_ts"]=time.time()
            try: remote_monitor.maybe_publish(data, engine.CFG, build_info())
            except Exception as exc: monitoring.log(f"remote monitor heartbeat skipped: {exc}")
            try:memory_store.sync_engine_payload(data)
            except Exception as exc:monitoring.log(f"v5.12.3 memory sync error: {exc}")
            try:
                data["monitoring"]=monitoring.process_cycle(data,data.get("messages",[]));data["monitoring"].update(monitoring.status())
            except Exception as exc:
                data["monitoring"]=monitoring.status();data["monitoring"]["last_email_error"]=str(exc);monitoring.log(f"v5.12.3 monitoring error: {exc}")
        except Exception as exc:
            CACHE["error"]=str(exc)
            try:monitoring.process_error(str(exc))
            except Exception:pass
            CACHE["payload"]={"ok":False,"paper_only":True,"live_locked":True,"version":VERSION,"error":str(exc),"heartbeat":CACHE["heartbeat"],"monitoring":monitoring.status()}
        finally:
            CACHE["cycle_in_progress"]=False;CACHE["heartbeat"]=engine.now_iso();CACHE["cycle_seconds"]=round(time.time()-t0,3)
        # Maintain configured start-to-start cadence instead of sleeping another full
        # interval after the model has already spent time computing.
        wait=max(0.5,ENGINE_CYCLE_SECONDS-(time.time()-t0));WAKE.wait(timeout=wait);WAKE.clear()


def evidence_worker():
    """Independent 15s market recorder + journal sampler.

    Market microstructure keeps being recorded even while a model retrain is busy. AI
    fields are tagged with model age so replay can distinguish fresh from stale advice.
    """
    while not STOP.is_set():
        try:
            data=_payload_with_model_age()
            if data.get("ok"):
                try:market_recorder.record(data,engine.CFG)
                except Exception as exc:monitoring.log(f"v5.12.3 market recorder error: {exc}")
                try:review_journal.record_cycle(data,data_sources(),engine.CFG)
                except Exception as exc:monitoring.log(f"v5.12.3 review journal error: {exc}")
                try: coinbase_live_canary.SERVICE.refresh_fee_only(force=False)
                except Exception as exc: monitoring.log(f"canary fee refresh skipped: {exc}")
        except Exception as exc:
            try:monitoring.log(f"v5.12.3 evidence worker error: {exc}")
            except Exception:pass
        interval=max(2.0,min(float(engine.CFG.get("market_recorder_interval_seconds",15.0)),float(engine.CFG.get("review_journal_interval_seconds",60.0))))
        STOP.wait(interval)


def _fast_source() -> dict:
    # Avoid recursion: Fast Paper consumes only the most recent full engine payload,
    # explicitly tagged with model age so stale AI cannot authorize a new Fast entry.
    return _payload_with_model_age()

def _mm_source() -> dict:
    """Market-maker research needs the scanner's freshest 30s snapshot.

    The full AI payload can take materially longer than the 2s MM research cadence.
    Using only CACHE could miss a brief but genuine scanner candidate before the next
    full model cycle. Keep all risk/autopilot state from CACHE, but overlay the live
    scanner snapshot directly.
    """
    d=dict(CACHE.get("payload") or {})
    try:
        d["market_scanner"]=market_scanner.SERVICE.snapshot()
    except Exception:
        pass
    return d

def _okx_symbols() -> list[str]:
    d=dict(CACHE.get("payload") or {})
    syms=[]
    for s in ((d.get("trade_universe") or {}).get("active_symbols") or []):
        if s not in syms: syms.append(s)
    try:
        sc=market_scanner.SERVICE.snapshot()
        for x in (sc.get("opportunities") or []):
            b=str(x.get("base") or "").upper()
            if b and b not in syms: syms.append(b)
    except Exception: pass
    return syms[:max(2,int(engine.CFG.get("okx_intelligence_max_symbols",8)))]

def _strategy_snapshot() -> dict:
    try:return strategy_lab.SERVICE.snapshot()
    except Exception:return {}

def _review_source() -> dict:
    d=dict(CACHE.get("payload") or {})
    try: d["fast_paper"]=fast_paper.SERVICE.snapshot()
    except Exception: d["fast_paper"]={}
    try: d["strategy_lab"]=strategy_lab.SERVICE.snapshot()
    except Exception: d["strategy_lab"]={}
    try: d["bot_supervisor"]=bot_supervisor.snapshot(d.get("strategy_lab") or {}, engine.CFG)
    except Exception: d["bot_supervisor"]={}
    return d


def data_sources() -> dict:
    radar=market_radar.SERVICE.status(); lab=strategy_lab.SERVICE.status()
    cb=coinbase_orderbook.SERVICE.status(); kr=kraken_orderbook.SERVICE.status()
    cb_health=_coinbase_health(cb)
    cmc_health=_feed_health(radar.get("last_success_ts"), radar.get("last_error"), max(180.0, float(engine.CFG.get("market_radar_interval_seconds",60))*3.0))
    lab_health=_feed_health(lab.get("last_run_ts"), lab.get("last_error"), max(7200.0, float(engine.CFG.get("strategy_lab_interval_seconds",21600))*2.0))
    kr_health=_feed_health(kr.get("last_book_ts") or kr.get("last_connect_ts"), kr.get("last_error"), 60.0)
    sc=market_scanner.SERVICE.snapshot(); ofs=order_flow.SERVICE.status(); ro=coinbase_readonly.SERVICE.status()
    opportunity_state="EDGE FOUND" if int(sc.get("viable_count") or 0)>0 else "NO EDGE"
    of_health=_feed_health(ofs.get("last_update_ts"), ofs.get("last_error"), 20.0)
    if ro.get("verified_read_only"):
        ro_health={"state":"DATA OK","last_success_ts":ro.get("last_success_ts"),"age_seconds":None if not ro.get("last_success_ts") else max(0.0,time.time()-float(ro.get("last_success_ts"))),"last_error":None}
    elif ro.get("configured"):
        ro_health={"state":"ERROR" if ro.get("last_error") else "WARMING","last_success_ts":ro.get("last_success_ts"),"age_seconds":None,"last_error":ro.get("last_error")}
    else:
        ro_health={"state":"OFF","last_success_ts":None,"age_seconds":None,"last_error":None}
    return {
        "coinbase": {"enabled":True,"role":"execution truth + L2 + market trades + candles","status":cb,"health":cb_health,"opportunity_state":opportunity_state},
        "coinbase_readonly": {"enabled":bool(ro.get("configured")),"role":"VIEW-only fee tier + permission verification","status":("VIEW-only verified" if ro.get("verified_read_only") else (ro.get("last_error") or "not configured")),"health":ro_health},
        "order_flow": {"enabled":bool(engine.CFG.get("order_flow_enabled",True)),"role":"deterministic L2 + trade-pressure confirmation","status":ofs,"health":of_health},
        "liquidity_reference_engine": {"enabled":bool(engine.CFG.get("coin_flow_core_enabled",True)),"role":"multi-exchange fair price + dislocation + inventory skew","status":"Coinbase execution + Kraken/Binance/OKX/Bybit/KuCoin/Gate.io public references","health":cb_health},
        "kraken": {"enabled":bool(engine.CFG.get("kraken_reference_enabled",True)),"role":"read-only GBP reference component","status":kr,"health":kr_health},
        "multi_exchange_reference": {"enabled":bool(engine.CFG.get("multi_exchange_reference_enabled",True)),"role":"6-venue read-only consensus + lead/lag; Coinbase remains execution; CMC is enrichment","status":multi_exchange_reference.SERVICE.snapshot()},
        "historical_robustness": {"enabled":bool(engine.CFG.get("historical_robustness_enabled",True)),"role":"research-only cross-venue history consistency","status":historical_robustness.SERVICE.snapshot()},
        "coinmarketcap": {"enabled":bool(engine.CFG.get("market_radar_enabled",True)),"role":"broad market discovery/trending enrichment; not a timing trigger","status":radar,"health":cmc_health},
        "strategy_lab": {"enabled":bool(engine.CFG.get("strategy_lab_enabled",True)),"role":"backtest + stability + out-of-sample + incubation","status":lab,"health":lab_health},
        "fast_paper": {"enabled":bool(engine.CFG.get("fast_paper_enabled",True)),"role":"2-second realtime PAPER timing comparator; never bypasses full-model gates","status":fast_paper.SERVICE.snapshot(),"health":{"state":"DATA OK" if fast_paper.SERVICE.last_update_ts else "WARMING","last_error":fast_paper.SERVICE.last_error}},
        "review_engine": {"enabled":bool(engine.CFG.get("review_engine_enabled",True)),"role":"daily/weekly evidence reports; no automatic code edits","status":review_engine.SERVICE.snapshot()},
        "review_journal": {"enabled":bool(engine.CFG.get("review_journal_enabled",True)),"role":"dense forward outcomes + independent signal episodes","status":review_journal.snapshot()},
        "counterfactual_lab": {"enabled":True,"role":"evidence-only gate studies; never loosens a gate automatically","status":counterfactual_lab.snapshot()},
        "market_maker_lab": {"enabled":bool(engine.CFG.get("market_maker_paper_lab_enabled",True)),"role":"queue-aware Coinbase spread-capture PAPER research","status":market_maker_lab.SERVICE.snapshot(),"health":{"state":"DATA OK" if market_maker_lab.SERVICE.last_update_ts else "WARMING","last_error":market_maker_lab.SERVICE.last_error}},
        "shadow_gate_lab": {"enabled":bool(engine.CFG.get("shadow_gate_lab_enabled",True)),"role":"separate PAPER challenger for selected blocked high-quality setups","status":shadow_gate_lab.SERVICE.snapshot(),"health":{"state":"DATA OK" if shadow_gate_lab.SERVICE.last_update_ts else "WARMING","last_error":shadow_gate_lab.SERVICE.last_error}},
        "okx_public_intelligence": {"enabled":bool(engine.CFG.get("okx_public_intelligence_enabled",True)),"role":"PUBLIC read-only derivatives context: OI, funding and volume; never execution","status":okx_intelligence.SERVICE.snapshot(),"health":{"state":"DATA OK" if okx_intelligence.SERVICE.last_update_ts and not okx_intelligence.SERVICE.last_error else ("DEGRADED" if okx_intelligence.SERVICE.last_update_ts else "WARMING"),"last_error":okx_intelligence.SERVICE.last_error}},
        "edge_profiles": {"enabled":bool(engine.CFG.get("edge_profiles_enabled",True)),"role":"per-coin expectancy evidence; may reduce capital but never raise risk ceiling","status":edge_profiles.SERVICE.snapshot(),"health":{"state":"DATA OK" if edge_profiles.SERVICE.last_update_ts else "WARMING","last_error":edge_profiles.SERVICE.last_error}},
        "regime_lab": {"enabled":bool(engine.CFG.get("regime_lab_enabled",True)),"role":"bull/bear/crash/range/high-vol/quiet stress testing","status":regime_lab.SERVICE.snapshot(),"health":{"state":"DATA OK" if regime_lab.SERVICE.last_update_ts else "WARMING","last_error":regime_lab.SERVICE.last_error}},
        "execution_core": {"enabled":True,"role":"unified PAPER order intents, lifecycle and audit reconciliation","status":execution_core.snapshot(20),"health":{"state":"DATA OK","last_error":None}},
        "news_social": {"enabled":bool(engine.CFG.get("social_news_radar_enabled",True)),"role":"live public RSS/social + Fear & Greed secondary evidence; never creates a trade","status":news_social.SERVICE.snapshot(),"health":{"state":"DATA OK" if news_social.SERVICE.last_update_ts and not news_social.SERVICE.last_error else ("DEGRADED" if news_social.SERVICE.last_update_ts else "WARMING"),"last_error":news_social.SERVICE.last_error}},
        "catalyst_intelligence": {"enabled":bool(engine.CFG.get("catalyst_intelligence_enabled",True)),"role":"official SEC/CFTC/Fed event context + asset resolution; read-only, never creates a trade","status":catalyst_intelligence.SERVICE.snapshot(),"health":{"state":"DATA OK" if catalyst_intelligence.SERVICE.last_update_ts and not catalyst_intelligence.SERVICE.last_error else ("DEGRADED" if catalyst_intelligence.SERVICE.last_update_ts else "WARMING"),"last_error":catalyst_intelligence.SERVICE.last_error}},
        "onchain_liquidations": {"enabled":False,"role":"no unverified liquidation feed; squeeze radar is explicitly a public-data proxy","status":"actual liquidation totals not connected"},
    }


def live_payload():
    data = _payload_with_model_age()
    if not data:
        data={"ok":False,"paper_only":True,"live_locked":True,"version":VERSION,"error":"v5.13.2 is warming up."}
    data["version"] = VERSION
    data["build_info"] = build_info()
    data["fee_profile"] = engine.fee_profile_snapshot()
    data["bot_name"] = engine.CFG.get("bot_name", "Andy's Bot")
    data["primary_exchange"] = engine.CFG.get("primary_exchange", "Coinbase")
    data["coinbase_only_execution"] = bool(engine.CFG.get("coinbase_only_execution", True))
    data["server_heartbeat"] = CACHE.get("heartbeat")
    data["server_cycle_seconds"] = CACHE.get("cycle_seconds")
    data["market_scanner"] = market_scanner.SERVICE.snapshot()
    data["market_radar"] = market_radar.SERVICE.snapshot()
    try: data["meme_radar"] = meme_intelligence.dashboard(data.get("assets") or {}, data["market_radar"], engine.CFG)
    except Exception as exc: data["meme_radar"] = {"enabled":True,"rows":[],"error":str(exc)}
    data["strategy_lab"] = strategy_lab.SERVICE.snapshot()
    try: data["memory"] = memory_store.snapshot()
    except Exception as exc: data["memory"] = {"ok":False,"error":str(exc),"lessons":[],"incubation":[]}
    try: data["bot_supervisor"] = bot_supervisor.snapshot(data["strategy_lab"], engine.CFG)
    except Exception as exc: data["bot_supervisor"] = {"ok":False,"error":str(exc),"rows":[],"counts":{}}
    try: data["order_flow"] = order_flow.SERVICE.snapshot()
    except Exception as exc: data["order_flow"] = {"ok":False,"error":str(exc),"assets":{}}
    try: data["executors"] = executor_engine.snapshot(engine.CFG, (data.get("portfolio") or {}).get("value_gbp"))
    except Exception as exc: data["executors"] = {"ok":False,"error":str(exc),"executors":[],"inventory":[]}
    data["liquidity_reference_engine"] = {sym:(row or {}).get("coin_flow") or {} for sym,row in (data.get("assets") or {}).items()}
    try: data["adaptive_supervisor"] = adaptive_supervisor.snapshot(data, data["strategy_lab"], data["order_flow"], data["bot_supervisor"], engine.CFG)
    except Exception as exc: data["adaptive_supervisor"] = {"ok":False,"error":str(exc),"why_not_trading":[]}
    try: data["fast_paper"] = fast_paper.SERVICE.snapshot()
    except Exception as exc: data["fast_paper"] = {"ok":False,"error":str(exc),"paper_only":True,"live_locked":True}
    try: data["reviews"] = review_engine.SERVICE.snapshot()
    except Exception as exc: data["reviews"] = {"ok":False,"error":str(exc),"reports":[]}
    try: data["review_export"] = review_export.status()
    except Exception as exc: data["review_export"] = {"ok":False,"error":str(exc),"secrets_included":False}
    try: data["review_journal"] = review_journal.snapshot()
    except Exception as exc: data["review_journal"] = {"ok":False,"error":str(exc),"observations":0,"signal_episodes":0}
    try: data["counterfactual_lab"] = counterfactual_lab.snapshot()
    except Exception as exc: data["counterfactual_lab"] = {"ok":False,"error":str(exc),"gates":{}}
    try: data["market_maker_lab"] = market_maker_lab.SERVICE.snapshot()
    except Exception as exc: data["market_maker_lab"] = {"ok":False,"error":str(exc),"paper_only":True,"live_locked":True}
    try: data["shadow_gate_lab"] = shadow_gate_lab.SERVICE.snapshot()
    except Exception as exc: data["shadow_gate_lab"] = {"ok":False,"error":str(exc),"paper_only":True,"live_locked":True}
    try: data["okx_intelligence"] = okx_intelligence.SERVICE.snapshot()
    except Exception as exc: data["okx_intelligence"] = {"ok":False,"error":str(exc),"read_only":True}
    try: data["news_social"] = news_social.SERVICE.snapshot()
    except Exception as exc: data["news_social"] = {"ok":False,"error":str(exc),"read_only":True}
    try: data["catalyst_intelligence"] = catalyst_intelligence.SERVICE.snapshot()
    except Exception as exc: data["catalyst_intelligence"] = {"ok":False,"error":str(exc),"read_only":True}
    try: data["software_update"] = update_manager.check(VERSION,engine.CFG,force=False)
    except Exception as exc: data["software_update"] = {"ok":False,"error":str(exc),"current_version":VERSION}
    data["evidence_quality"] = evidence_quality.snapshot()
    data["coinbase_order_events"] = coinbase_order_monitor.SERVICE.status()
    try: data["remote_monitor"] = remote_monitor.status()
    except Exception as exc: data["remote_monitor"] = {"ok":False,"error":str(exc)}
    data["market_recorder"] = market_recorder.status(engine.CFG)
    data["multi_exchange_reference"] = multi_exchange_reference.SERVICE.snapshot()
    data["historical_robustness"] = historical_robustness.SERVICE.snapshot()
    data["performance"] = {"model_age_seconds":_payload_with_model_age().get("model_age_seconds"),"model_state":_payload_with_model_age().get("model_state"),"last_model_cycle_seconds":CACHE.get("cycle_seconds"),"cycle_in_progress":bool(CACHE.get("cycle_in_progress")),"numpy_acceleration":bool(getattr(engine,"NUMPY_ACCELERATION",False))}
    try: data["liquidity_reversal_lab"] = liquidity_reversal_lab.SERVICE.snapshot()
    except Exception as exc: data["liquidity_reversal_lab"] = {"ok":False,"error":str(exc),"paper_only":True,"live_locked":True}
    data["phone_access"] = mobile_access.public_status(PORT, engine.CFG)
    # Live approval/preview state is a fast control-plane state and can change between
    # slow model cycles. Always overlay the fresh canary status so /api/live never
    # serves a stale candidate after a successful Coinbase preview.
    try: data["live_canary"] = coinbase_live_canary.SERVICE.status(engine.CFG)
    except Exception:
        data["live_canary"] = data.get("live_canary") or {}
    try: data["edge_profiles"] = edge_profiles.SERVICE.snapshot()
    except Exception as exc: data["edge_profiles"] = {"ok":False,"error":str(exc),"profiles":{}}
    try: data["regime_lab"] = regime_lab.SERVICE.snapshot()
    except Exception as exc: data["regime_lab"] = {"ok":False,"error":str(exc),"rows":[]}
    try: data["execution_core"] = execution_core.snapshot()
    except Exception as exc: data["execution_core"] = {"ok":False,"error":str(exc),"paper_only":True,"live_locked":True}
    try: data["capability_matrix"] = capabilities.snapshot(coinbase_readonly.SERVICE.status(),data.get("live_canary") or coinbase_live_canary.SERVICE.status())
    except Exception as exc: data["capability_matrix"] = {"ok":False,"error":str(exc),"live_order_submission":False}
    data["startup_audit"] = STARTUP_AUDIT
    data["data_sources"] = data_sources()
    data["coinbase_readonly"] = coinbase_readonly.SERVICE.status()
    data["kraken_market_data"] = kraken_orderbook.SERVICE.status()
    data["coinbase_market_data"] = coinbase_orderbook.SERVICE.status()
    with CONTROL_LOCK:
        data["control_status"] = dict(CONTROL)
    data["realtime"] = {
        "dashboard_poll_ms": int(engine.CFG.get("dashboard_refresh_ms",2000)),
        "engine_cycle_seconds": ENGINE_CYCLE_SECONDS,
        "scanner_interval_seconds": float(engine.CFG.get("scanner_interval_seconds", 30)),
        "market_radar_interval_seconds": float(engine.CFG.get("market_radar_interval_seconds",60)),
        "strategy_lab_interval_seconds": float(engine.CFG.get("strategy_lab_interval_seconds",21600)),
        "order_flow_interval_seconds": float(engine.CFG.get("order_flow_interval_seconds",1.0)),
        "fast_paper_interval_seconds": float(engine.CFG.get("fast_paper_interval_seconds",2.0)),
        "market_maker_lab_interval_seconds": float(engine.CFG.get("market_maker_lab_interval_seconds",2.0)),
        "normal_execution_cadence_note": "Full model refresh stays slow/candle-aware; qualified normal paper execution may react each engine cycle.",
        "no_click_required": True,
    }
    return data



# Regression contract: path in ("/api/live", "/api/status")
class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args): pass

    def send_json(self, obj, status=200):
        raw=json.dumps(obj).encode("utf-8")
        self.send_response(status); self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store"); self.send_header("Content-Length",str(len(raw)))
        self.end_headers(); self.wfile.write(raw)

    def read_json(self):
        n=int(self.headers.get("Content-Length") or 0)
        if n<=0: return {}
        if n>65536: raise ValueError("Request too large")
        raw=self.rfile.read(n)
        return json.loads(raw.decode("utf-8")) if raw else {}

    def _provided_token(self):
        q=parse_qs(urlparse(self.path).query)
        return self.headers.get("X-Andys-Token") or ((q.get("token") or [None])[0])

    def _api_authorized(self):
        return mobile_access.authorized(self.client_address[0],self._provided_token(),engine.CFG)

    def _require_api_auth(self):
        if self._api_authorized(): return True
        self.send_json({"ok":False,"error":"Phone/LAN authentication required. Open the Phone dashboard URL printed by Andy's Bot."},401)
        return False

    def _send_static(self,filename,content_type,cache="no-store"):
        fp=(BASE_DIR/filename).resolve()
        if fp.parent!=BASE_DIR.resolve() or not fp.is_file(): self.send_error(404);return
        raw=fp.read_bytes();self.send_response(200);self.send_header("Content-Type",content_type);self.send_header("Cache-Control",cache);self.send_header("X-Content-Type-Options","nosniff");self.send_header("X-Frame-Options","DENY");self.send_header("Referrer-Policy","no-referrer");self.send_header("Content-Length",str(len(raw)));self.end_headers();self.wfile.write(raw)

    def do_GET(self):
        path=self.path.split("?",1)[0]
        if path in ("/","/index.html","/phone"):
            self._send_static("dashboard.html","text/html; charset=utf-8"); return
        if path=="/manifest.webmanifest": self._send_static("manifest.webmanifest","application/manifest+json; charset=utf-8","max-age=3600"); return
        if path=="/icon-192.png": self._send_static("icon-192.png","image/png","max-age=86400"); return
        if path=="/icon-512.png": self._send_static("icon-512.png","image/png","max-age=86400"); return
        if path=="/sw.js": self._send_static("sw.js","application/javascript; charset=utf-8","no-cache"); return
        if path.startswith("/api/") and not self._require_api_auth(): return
        if path in ("/api/live","/api/status"):
            d=live_payload(); self.send_json(d,200 if d.get("ok") else 503); return
        if path=="/api/radar": self.send_json(market_radar.SERVICE.snapshot()); return
        if path=="/api/strategy-lab": self.send_json(strategy_lab.SERVICE.snapshot()); return
        if path=="/api/memory": self.send_json(memory_store.snapshot()); return
        if path=="/api/order-flow": self.send_json(order_flow.SERVICE.snapshot()); return
        if path=="/api/fast-paper": self.send_json(fast_paper.SERVICE.snapshot()); return
        if path=="/api/reviews": self.send_json(review_engine.SERVICE.snapshot()); return
        if path=="/api/counterfactual-lab": self.send_json(counterfactual_lab.snapshot()); return
        if path=="/api/market-maker-lab": self.send_json(market_maker_lab.SERVICE.snapshot()); return
        if path=="/api/shadow-gate-lab": self.send_json(shadow_gate_lab.SERVICE.snapshot()); return
        if path=="/api/okx-intelligence": self.send_json(okx_intelligence.SERVICE.snapshot()); return
        if path=="/api/news-social": self.send_json(news_social.SERVICE.snapshot()); return
        if path=="/api/catalysts": self.send_json(catalyst_intelligence.SERVICE.snapshot()); return
        if path=="/api/market-recorder": self.send_json(market_recorder.status(engine.CFG)); return
        if path=="/api/multi-exchange-reference": self.send_json(multi_exchange_reference.SERVICE.snapshot()); return
        if path=="/api/historical-robustness": self.send_json(historical_robustness.SERVICE.snapshot()); return
        if path=="/api/liquidity-reversal-lab": self.send_json(liquidity_reversal_lab.SERVICE.snapshot()); return
        if path=="/api/candles":
            q=parse_qs(urlparse(self.path).query); sym=str((q.get("symbol") or ["BTC"])[0]).upper(); tf=str((q.get("timeframe") or ["15m"])[0]).lower()
            if sym not in engine.COINBASE_PRODUCTS: self.send_json({"ok":False,"error":"Symbol is not in the current Coinbase GBP model universe"},400); return
            d=chart_data.get(sym,tf,engine.COINBASE_PRODUCTS.get(sym)); live=live_payload(); a=(live.get("assets") or {}).get(sym) or {}; pos=next((x for x in (live.get("positions") or []) if x.get("symbol")==sym),None)
            d["decision"]={k:a.get(k) for k in ("action","strategy","brain_score","ensemble_probability","calibrated_probability","reason","market_quality","market_opportunity","decision_council")};d["position"]=pos
            self.send_json(d); return
        if path=="/api/phone-access": self.send_json(mobile_access.public_status(PORT,engine.CFG)); return
        if path=="/api/update-status": self.send_json(update_manager.public_status(VERSION,engine.CFG)); return
        if path=="/api/remote-monitor-status": self.send_json(remote_monitor.status()); return
        if path=="/api/phone-link":
            if self.client_address[0] not in ("127.0.0.1","::1"):
                self.send_json({"ok":False,"error":"Full phone link is only shown on the PC running Andy's Bot."},403); return
            self.send_json({"ok":True,"url":mobile_access.startup_url(PORT,engine.CFG),"status":mobile_access.public_status(PORT,engine.CFG)}); return
        if path=="/api/edge-profiles": self.send_json(edge_profiles.SERVICE.snapshot()); return
        if path=="/api/regime-lab": self.send_json(regime_lab.SERVICE.snapshot()); return
        if path=="/api/execution-core": self.send_json(execution_core.snapshot()); return
        if path=="/api/capabilities": self.send_json(capabilities.snapshot(coinbase_readonly.SERVICE.status(),coinbase_live_canary.SERVICE.status())); return
        if path=="/api/live-canary": self.send_json(coinbase_live_canary.SERVICE.status()); return
        if path=="/api/reference-engine": self.send_json((live_payload().get("liquidity_reference_engine") or {})); return
        if path=="/api/coin-flow": self.send_json((live_payload().get("liquidity_reference_engine") or {})); return
        if path=="/api/executors": self.send_json(executor_engine.snapshot(engine.CFG, (live_payload().get("portfolio") or {}).get("value_gbp"))); return
        if path=="/api/kraken-account": self.send_json(kraken_private.safe_account_snapshot()); return
        if path=="/api/health":
            live=coinbase_live_canary.SERVICE.status()
            self.send_json({
                "ok":True,"autonomous":False,"autonomous_live":False,"paper_only":not bool(live.get("armed")),"live_locked":not bool(live.get("ready")),"live_canary":live,"version":VERSION,
                "heartbeat":CACHE["heartbeat"],"last_error":CACHE["error"],"cycle_seconds":CACHE["cycle_seconds"],
                "startup_audit":STARTUP_AUDIT,"market_radar":market_radar.SERVICE.status(),"strategy_lab":strategy_lab.SERVICE.status(),
                "market_scanner":market_scanner.SERVICE.status(),"coinbase_market_data":coinbase_orderbook.SERVICE.status(),
                "order_flow":order_flow.SERVICE.status(),"fast_paper":fast_paper.SERVICE.snapshot(),"reviews":review_engine.SERVICE.snapshot(),"review_export":review_export.status(),"review_journal":review_journal.snapshot(),"counterfactual_lab":counterfactual_lab.snapshot(),"market_maker_lab":market_maker_lab.SERVICE.snapshot(),"shadow_gate_lab":shadow_gate_lab.SERVICE.snapshot(),"okx_intelligence":okx_intelligence.SERVICE.snapshot(),"news_social":news_social.SERVICE.snapshot(),"catalyst_intelligence":catalyst_intelligence.SERVICE.snapshot(),"edge_profiles":edge_profiles.SERVICE.snapshot(),"regime_lab":regime_lab.SERVICE.snapshot(),"execution_core":execution_core.snapshot(30),"kraken_market_data":kraken_orderbook.SERVICE.status(),"coinbase_readonly":coinbase_readonly.SERVICE.status(),"fee_profile":engine.fee_profile_snapshot(),"monitoring":monitoring.status(),"market_recorder":market_recorder.status(engine.CFG),"liquidity_reversal_lab":liquidity_reversal_lab.SERVICE.snapshot(),
            }); return
        if path=="/api/review-export-status": self.send_json(review_export.status()); return
        if path=="/api/replay-data-download":
            q=parse_qs(urlparse(self.path).query); name=Path((q.get("name") or [""])[0]).name
            if not name or name != (q.get("name") or [""])[0] or not name.startswith("Andys_Bot_Replay_Data_") or not name.endswith(".zip"):
                self.send_error(400,"Invalid replay-pack name"); return
            fp=(market_recorder.EXPORTS/name).resolve()
            if fp.parent != market_recorder.EXPORTS.resolve() or not fp.is_file(): self.send_error(404,"Replay pack not found"); return
            raw=fp.read_bytes(); self.send_response(200); self.send_header("Content-Type","application/zip"); self.send_header("Content-Disposition",f'attachment; filename="{name}"'); self.send_header("Cache-Control","no-store"); self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        if path=="/api/review-pack-download":
            q=parse_qs(urlparse(self.path).query); name=Path((q.get("name") or [""])[0]).name
            if not name or name != (q.get("name") or [""])[0] or not name.startswith("Andys_Bot_Review_") or not name.endswith(".zip"):
                self.send_error(400,"Invalid review-pack name"); return
            fp=(review_export.EXPORT_DIR/name).resolve()
            try:
                if fp.parent != review_export.EXPORT_DIR.resolve() or not fp.is_file(): raise FileNotFoundError(name)
                raw=fp.read_bytes(); self.send_response(200); self.send_header("Content-Type","application/zip")
                self.send_header("Content-Disposition",f'attachment; filename="{name}"'); self.send_header("Cache-Control","no-store")
                self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw); return
            except FileNotFoundError:
                self.send_error(404,"Review pack not found"); return
        self.send_error(404)

    def do_POST(self):
        path=self.path.split("?",1)[0]
        if path.startswith("/api/") and not self._require_api_auth(): return
        try:
            if path=="/api/configure-update-channel":
                if self.client_address[0] not in ("127.0.0.1","::1"):
                    self.send_json({"ok":False,"error":"Update channel can only be linked from the PC running Andy's Bot."},403); return
                body=self.read_json(); url=str(body.get("manifest_url") or '').strip()
                try:
                    update_manager.configure_channel(url,engine.CFG,engine.SETTINGS_FILE)
                    self.send_json(update_manager.check(VERSION,engine.CFG,force=True)); return
                except Exception as exc:
                    self.send_json({"ok":False,"error":str(exc)},400); return
            if path=="/api/check-update":
                self.send_json(update_manager.check(VERSION,engine.CFG,force=True)); return
            if path=="/api/stage-update":
                self.send_json(update_manager.stage(VERSION,engine.CFG)); return
            if path=="/api/install-update":
                status=update_manager.public_status(VERSION,engine.CFG); staged=status.get("staged") or {}; pkg=staged.get("package") or {}
                if not staged: self.send_json({"ok":False,"error":"No verified staged update"},400); return
                body=self.read_json(); target=str(pkg.get("version") or '')
                if str(body.get("confirm_version") or '')!=target: self.send_json({"ok":False,"error":"Confirm the exact staged version before install"},400); return
                if str(pkg.get("kind") or '').lower()!='ui' and self.client_address[0] not in ("127.0.0.1","::1"):
                    self.send_json({"ok":False,"error":"Full trading-engine/risk updates must be installed from the PC dashboard. Phone can check and stage them."},403); return
                if os.name!='nt': self.send_json({"ok":False,"error":"One-click apply is enabled on the Windows bot host; this environment can only stage/verify."},400); return
                req=update_manager.staged_install_request(VERSION); helper=BASE_DIR/'apply_staged_update.py'
                if not helper.is_file():
                    self.send_json({"ok":False,"error":"Updater worker is missing. Run Andy's Bot Updater Repair v2 once, then try again."},500); return
                preflight=subprocess.run(
                    [sys.executable,str(helper),'--preflight','--root',str(BASE_DIR),'--zip',req['staged_zip']],
                    cwd=BASE_DIR,text=True,capture_output=True,timeout=25
                )
                if preflight.returncode!=0:
                    detail=(preflight.stderr or preflight.stdout or 'Updater preflight failed').strip().splitlines()[-1]
                    self.send_json({"ok":False,"error":detail},500); return
                ready=BASE_DIR/'.updates'/'update_worker_ready.json'; ready.unlink(missing_ok=True)
                log_path=BASE_DIR/'.updates'/'update_apply.log'; log_path.parent.mkdir(parents=True,exist_ok=True)
                with log_path.open('a',encoding='utf-8') as update_log:
                    subprocess.Popen(
                        [sys.executable,str(helper),'--root',str(BASE_DIR),'--zip',req['staged_zip'],'--pid',str(os.getpid())],
                        cwd=BASE_DIR,stdout=update_log,stderr=subprocess.STDOUT,
                        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)
                    )
                self.send_json({"ok":True,"message":f"Installing {target}. The updater worker passed preflight; Andy's Bot will validate, migrate and restart automatically."})
                def _exit_for_update():
                    time.sleep(1.2); STOP.set(); WAKE.set(); os._exit(0)
                threading.Thread(target=_exit_for_update,daemon=True).start(); return
            if path=="/api/export-replay-data":
                body=self.read_json(); result=market_recorder.export_pack(float(body.get("hours") or 24)); result["download_url"]="/api/replay-data-download?name="+result["name"]; self.send_json(result); return
            if path=="/api/run-replay-lab":
                body=self.read_json(); self.send_json(market_replay.analyse(float(body.get("hours") or 24))); return
            if path=="/api/run-liquidity-reversal-lab":
                threading.Thread(target=liquidity_reversal_lab.SERVICE.refresh,daemon=True).start(); self.send_json({"ok":True,"message":"Liquidity Reversal Paper Lab refresh queued."}); return
            if path=="/api/refresh":
                WAKE.set(); market_scanner.SERVICE.refresh(); market_radar.SERVICE.refresh();
                try: okx_intelligence.SERVICE.refresh()
                except Exception: pass
                try: news_social.SERVICE.refresh()
                except Exception: pass
                try: catalyst_intelligence.SERVICE.refresh()
                except Exception: pass
                try: edge_profiles.SERVICE.refresh()
                except Exception: pass
                self.send_json({"ok":True}); return
            if path=="/api/run-lab":
                strategy_lab.SERVICE.refresh(); self.send_json({"ok":True,"message":"Strategy Lab run queued; v5.12 Edge/Regime/Calibration research will refresh from the new evidence."}); return
            if path=="/api/run-regime-lab":
                threading.Thread(target=regime_lab.SERVICE.refresh,daemon=True).start(); self.send_json({"ok":True,"message":"Regime stress run queued."}); return
            if path=="/api/reset-fast-paper":
                start=float(((CACHE.get("payload") or {}).get("portfolio") or {}).get("starting_balance") or engine.CFG.get("starting_cash_gbp",100.0)); self.send_json(fast_paper.SERVICE.reset(start)); return
            if path=="/api/reset-market-maker-lab":
                start=float(((CACHE.get("payload") or {}).get("portfolio") or {}).get("starting_balance") or engine.CFG.get("starting_cash_gbp",100.0)); self.send_json(market_maker_lab.SERVICE.reset(start)); return
            if path=="/api/reset-shadow-gate-lab":
                start=float(((CACHE.get("payload") or {}).get("portfolio") or {}).get("starting_balance") or engine.CFG.get("starting_cash_gbp",100.0)); self.send_json(shadow_gate_lab.SERVICE.reset(start)); return
            if path=="/api/run-review":
                body=self.read_json(); self.send_json(review_engine.SERVICE.generate(body.get("kind") or "daily")); return
            if path=="/api/export-review-pack":
                result=review_export.create_review_pack(live_payload(), max_file_mb=float(engine.CFG.get("review_export_max_file_mb",150.0)))
                result["download_url"]="/api/review-pack-download?name="+result["name"]; self.send_json(result); return
            if path=="/api/live-preview":
                if self.client_address[0] not in ("127.0.0.1","::1"):
                    self.send_json({"ok":False,"error":"Live trade preview is PC-only."},403); return
                self.read_json()
                self.send_json(coinbase_live_canary.SERVICE.preview_candidate(live_payload(),engine.CFG)); return
            if path=="/api/live-approve":
                if self.client_address[0] not in ("127.0.0.1","::1"):
                    self.send_json({"ok":False,"error":"Live trade approval is PC-only."},403); return
                body=self.read_json()
                self.send_json(coinbase_live_canary.SERVICE.approve_preview(body.get("approval_id") or "",body.get("confirmation") or "",live_payload(),engine.CFG)); return
            if path=="/api/live-cancel-preview":
                if self.client_address[0] not in ("127.0.0.1","::1"):
                    self.send_json({"ok":False,"error":"Live trade controls are PC-only."},403); return
                self.read_json(); self.send_json(coinbase_live_canary.SERVICE.cancel_preview(engine.CFG)); return
            if path=="/api/toggle": self.send_json(engine.toggle_autopilot()); WAKE.set(); return
            if path=="/api/set-paper-balance":
                body=self.read_json(); result=queue_paper_balance(body.get("amount")); self.send_json(result,202 if result.get("ok") else 400); return
            if path=="/api/reset": self.send_json(engine.reset_account()); WAKE.set(); return
            if path=="/api/backtest": self.send_json(engine.backtest()); return
            self.send_error(404)
        except Exception as exc:self.send_json({"ok":False,"error":str(exc)},500)


def open_browser():
    time.sleep(1.2); webbrowser.open(f"http://127.0.0.1:{PORT}")


def main():
    coinbase_readonly.SERVICE.refresh(force=True)
    try: coinbase_live_canary.SERVICE.refresh_fee_only(force=True)
    except Exception: pass
    print("="*82)
    print("ANDY'S BOT — v5.13.2 FAST SIGNAL R4.1 £100 SUPERVISED LIVE")
    print("="*82)
    live_status=coinbase_live_canary.SERVICE.status()
    print("LIVE £100 SUPERVISED ARMED — MANUAL APPROVAL REQUIRED" if live_status.get("armed") else "PAPER / SHADOW — SUPERVISED LIVE DISARMED")
    print("Live limits:           £100 bankroll, £10/order, £20 exposure, up to 8 positions, 4 new entries/day; manual approval; no transfers")
    print("Coinbase:             execution truth, L2, GBP spot and model candles")
    print("CoinMarketCap:        broad-market discovery radar (keyless supported)")
    print("Kraken/Binance/OKX:    read-only multi-exchange reference consensus")
    print("Strategy Lab:         5 strategy families + parameter stability + 70/30 OOS")
    print("Order flow:           Coinbase L2 + market trades + walls/churn/absorption")
    print("Reference engine:      Kraken/Binance/OKX consensus fair price + Coinbase dislocation")
    fp=engine.fee_profile_snapshot(); print(f"Coinbase fees:         {fp['source']} | maker {fp['maker_fee_pct']:.3f}% / taker {fp['taker_fee_pct']:.3f}% | paper gate {fp['paper_cost_gate_pct']:.2f}%")
    ro=coinbase_readonly.SERVICE.status(); print(f"Coinbase read-only:    {'VERIFIED' if ro.get('verified_read_only') else ('configured / checking' if ro.get('configured') else 'not configured')}")
    print("Executors:            per-tranche paper ledger + break-even inventory governor")
    print("Unified execution:     idempotent partial fills + restart reconciliation in one PAPER audit ledger")
    print("Edge profiles:         coin-by-coin expectancy may reduce capital; never raises 1% risk ceiling")
    print("Regime Lab:            bull/bear/crash/range/high-vol/quiet stress tests before promotion")
    print("OKX intelligence:      PUBLIC/READ-ONLY OI + funding + volume; never an execution venue")
    print("v5.12 context:         15m / 1h / 4h / 1d + per-coin expectancy + public derivatives context")
    print("v5.12 realtime:        Coinbase Level2/heartbeat recovery retained + OKX public OI/funding context")
    print(f"Fast Paper Lab:        {float(engine.CFG.get('fast_paper_interval_seconds',2.0)):.1f}s checks, separate comparator account, full gates preserved")
    print("Evidence reviews:      daily + weekly reports; no unattended code/parameter rewrites")
    print("Review Pack:           one-click sanitized evidence ZIP; credentials explicitly excluded")
    print("Outcome journal:       exact-time historical backfill for overdue 15m/1h/4h/24h outcomes")
    print("Counterfactual Lab:     evidence-only gate studies; no automatic gate loosening")
    print("Market Maker Lab:      queue-aware Coinbase spread-capture PAPER simulator + blocker diagnostics")
    print("Shadow Gate Lab:       separate PAPER challenger for selected blocked setups")
    print("Incubation:           persistent SQLite memory + bot-death quarantine")
    print(f"Risk:                 smart stake 5/10/15/20%, dynamic floor {engine.CFG.get('paper_equity_floor_pct',0.85)*100:.0f}% of selected paper balance")
    print("Live bridge:          read-only sanitized status on separate port")
    print("News/social:          CoinDesk RSS + Reddit public RSS + Fear & Greed; secondary/read-only")
    print("Catalyst Fusion:      official SEC/CFTC/Fed feeds + asset/event classification + no-chase veto")
    print("Squeeze radar:        public OKX OI/funding proxy only; no invented liquidation totals")
    print("Candles:              responsive 1m/5m/15m/1h/4h/1d desktop + phone chart")
    print("Market recorder:       independent 15s gzip replay stream; continues during model retraining")
    print("Liquidity reversal:    ATR-normalised UTC/London/New York PAPER research lab")
    print(f"Model acceleration:    {'NumPy vectorized' if getattr(engine,'NUMPY_ACCELERATION',False) else 'pure-Python fallback'} + indicator precompute")
    print("Historical research:   Coinbase GBP primary + Binance/OKX cross-venue robustness checks")
    print("Updater:               HTTPS channel + allow-list + SHA-256 + rollback; full updates PC approval only")
    print(f"Dashboard:            http://127.0.0.1:{PORT}")
    print("="*82)
    if not STARTUP_AUDIT.get("ok"):
        audit_reason = "; ".join(STARTUP_AUDIT.get("issues") or []) or "unknown startup-audit failure"
        print("STARTUP AUDIT FAIL-CLOSED:", audit_reason)
        try:
            st = engine.load_state()
            st["safety_lock"] = True
            st["safety_lock_reason"] = "Startup audit failed: " + audit_reason
            st["autopilot_enabled"] = False
            engine.save_state(st)
        except Exception as exc:
            print("Could not persist startup safety lock:", exc)

    coinbase_readonly.SERVICE.start(); coinbase_order_monitor.SERVICE.start(); kraken_orderbook.SERVICE.start(); coinbase_orderbook.SERVICE.start(); order_flow.SERVICE.start(engine.CFG); market_scanner.SERVICE.start(engine.CFG)
    market_radar.SERVICE.start(engine.CFG); strategy_lab.SERVICE.start(engine.CFG)
    okx_intelligence.SERVICE.start(_okx_symbols,engine.CFG); news_social.SERVICE.start(_okx_symbols,engine.CFG); catalyst_intelligence.SERVICE.start(_okx_symbols,engine.CFG); edge_profiles.SERVICE.start(_strategy_snapshot,engine.CFG); regime_lab.SERVICE.start(_strategy_snapshot,engine.CFG)
    multi_exchange_reference.SERVICE.start(_okx_symbols,engine.CFG); historical_robustness.SERVICE.start(_okx_symbols,engine.CFG)
    threading.Thread(target=worker,name='full-model-worker',daemon=True).start(); threading.Thread(target=evidence_worker,name='independent-evidence-worker',daemon=True).start()
    fast_paper.SERVICE.start(_fast_source,engine.CFG); market_maker_lab.SERVICE.start(_mm_source,engine.CFG); shadow_gate_lab.SERVICE.start(_fast_source,engine.CFG); review_engine.SERVICE.start(_review_source,engine.CFG)
    liquidity_reversal_lab.SERVICE.start(_okx_symbols,engine.CFG)
    bind_host="0.0.0.0" if bool(engine.CFG.get("phone_access_enabled",True)) else "127.0.0.1"
    server=ThreadingHTTPServer((bind_host,PORT),Handler)
    phone_url=mobile_access.startup_url(PORT,engine.CFG) if bind_host=="0.0.0.0" else None
    if phone_url:
        print("Phone dashboard:       "+phone_url)
        print("Phone security:        authenticated private-LAN token; use trusted Wi-Fi only")
        try:(BASE_DIR/"PHONE_ACCESS_URL.txt").write_text(phone_url+"\n",encoding="utf-8")
        except Exception:pass
    if os.getenv("CRYPTO_BOT_OPEN_BROWSER","1")!="0": threading.Thread(target=open_browser,daemon=True).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:
        STOP.set();WAKE.set();fast_paper.SERVICE.stop();market_maker_lab.SERVICE.stop();shadow_gate_lab.SERVICE.stop();review_engine.SERVICE.stop();liquidity_reversal_lab.SERVICE.stop();okx_intelligence.SERVICE.stop();news_social.SERVICE.stop();catalyst_intelligence.SERVICE.stop();edge_profiles.SERVICE.stop();regime_lab.SERVICE.stop();multi_exchange_reference.SERVICE.stop();historical_robustness.SERVICE.stop();coinbase_readonly.SERVICE.stop();kraken_orderbook.SERVICE.stop();coinbase_orderbook.SERVICE.stop();order_flow.SERVICE.stop();market_scanner.SERVICE.stop();market_radar.SERVICE.stop();strategy_lab.SERVICE.stop();server.server_close()


if __name__=="__main__":main()
