#!/usr/bin/env python3
"""Fail-closed Coinbase Advanced Trade £100 supervised-live adapter.

The autonomous model can discover and rank candidates, but it can never submit a
real-money order on its own.  A real order requires two explicit PC-local actions:
(1) Preview Live Trade, then (2) Approve Live Trade with an exact confirmation phrase.

Every approved entry is re-previewed immediately before submission and includes a
Coinbase-hosted stop/target bracket.  Transfer permission is forbidden.
"""
from __future__ import annotations

import json
import math
import threading
import time
import urllib.parse
import uuid
from datetime import datetime, timezone
from decimal import Decimal, ROUND_DOWN
from pathlib import Path
from typing import Any

import coinbase_readonly
import meme_intelligence
import allocation_engine
import coinbase_live_ledger

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "coinbase_live_config.json"
STATE_FILE = BASE_DIR / "live_canary_state.json"
FEE_OVERRIDE_FILE = BASE_DIR / "coinbase_fee_override.json"

HARD_BANKROLL_CAP_GBP = 100.0
HARD_ORDER_CAP_GBP = 10.0
HARD_EXPOSURE_CAP_GBP = 20.0
HARD_MAX_POSITIONS = 8
HARD_MAX_ORDERS_PER_DAY = 4
HARD_DAILY_LOSS_GBP = 2.0
HARD_LIFETIME_LOSS_GBP = 10.0
PREVIEW_TTL_SECONDS = 90.0
CANDIDATE_TTL_SECONDS = 120.0


def _as_dict(value: Any) -> dict:
    if isinstance(value, dict):
        return value
    fn = getattr(value, "to_dict", None)
    if callable(fn):
        out = fn()
        return out if isinstance(out, dict) else {}
    try:
        return dict(value)
    except Exception:
        return {}


def _load(path: Path) -> dict:
    try:
        out = json.loads(path.read_text(encoding="utf-8"))
        return out if isinstance(out, dict) else {}
    except Exception:
        return {}


def _save(path: Path, data: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(path)


def _flag(perms: dict, key: str):
    value = perms.get(key)
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)) and value in (0, 1):
        return bool(value)
    if isinstance(value, str):
        if value.strip().lower() in ("true", "1", "yes"):
            return True
        if value.strip().lower() in ("false", "0", "no"):
            return False
    return None


def permission_check(perms: dict) -> tuple[bool, str]:
    view, trade, transfer = (_flag(perms, x) for x in ("can_view", "can_trade", "can_transfer"))
    if view is not True or trade is not True:
        return False, "Key must explicitly have Coinbase View and Trade permissions."
    if transfer is not False:
        return False, "Key must explicitly have Transfer permission disabled."
    if not str(perms.get("portfolio_uuid") or "").strip():
        return False, "Key response did not identify a scoped Coinbase portfolio."
    return True, "Verified scoped Coinbase key: View + Trade, Transfer disabled."


def _make_client(key_file: Path):
    from coinbase.rest import RESTClient
    return RESTClient(key_file=str(key_file), timeout=10)


def _available_balances(accounts: dict) -> tuple[float, list[dict]]:
    gbp = 0.0
    non_gbp: list[dict] = []
    for row in accounts.get("accounts") or []:
        row = _as_dict(row)
        currency = str(row.get("currency") or "").upper()
        available = _finite((_as_dict(row.get("available_balance"))).get("value"))
        hold = _finite((_as_dict(row.get("hold"))).get("value"))
        total = max(0.0, available + hold)
        if currency == "GBP":
            gbp += available
        elif total > 1e-12:
            non_gbp.append({"currency": currency, "balance": total})
    return gbp, non_gbp


def validate_key_file(key_file: Path) -> dict:
    path = Path(key_file).expanduser().resolve()
    if not path.is_file():
        return {"ok": False, "error": "Coinbase key JSON file was not found."}
    try:
        client = _make_client(path)
        perms = _as_dict(client.get("/api/v3/brokerage/key_permissions"))
        ok, detail = permission_check(perms)
        if not ok:
            return {"ok": False, "error": detail, "permissions": perms}
        accounts = _as_dict(client.get("/api/v3/brokerage/accounts"))
        gbp, non_gbp = _available_balances(accounts)
        return {
            "ok": True,
            "detail": detail,
            "permissions": perms,
            "portfolio_uuid": str(perms.get("portfolio_uuid")),
            "available_gbp": round(gbp, 8),
            "non_gbp_balances": non_gbp,
            "key_file_name": path.name,
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc), "key_file_name": path.name}


def _blank_state() -> dict:
    return {
        "version": "5.13.5-live-ledger",
        "safety_lock": False,
        "safety_lock_reason": None,
        "ledger_reconciling": False,
        "ledger_reconciliation_reason": None,
        "verified_ts": 0.0,
        "approval_candidate": None,
        "approval_preview": None,
        "pending_order": None,
        "positions": {},
        "trades": [],
        "day_key": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        "day_realized_pnl_gbp": 0.0,
        "lifetime_realized_pnl_gbp": 0.0,
        "orders_today": 0,
        "last_action": "SUPERVISED LIVE DISARMED",
        "last_error": None,
        "last_fee_sync_ts": 0.0,
        "last_fee_sync_error": None,
        "fee_pricing_tier": None,
    }


def _quantize(value: float, increment: str) -> str:
    inc = Decimal(str(increment or "0.01"))
    if inc <= 0:
        inc = Decimal("0.01")
    return format((Decimal(str(value)) / inc).to_integral_value(rounding=ROUND_DOWN) * inc, "f")


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except Exception:
        return default


class LiveCanaryService:
    """Compatibility name retained; behaviour is supervised-live only."""

    def __init__(self, ledger: coinbase_live_ledger.LiveTradeLedger | None = None):
        self._lock = threading.RLock()
        self.ledger = ledger or coinbase_live_ledger.LiveTradeLedger()
        self._client_obj = None
        self._client_key = None
        self._products: dict[str, tuple[float, dict]] = {}
        self._orders: dict[str, tuple[float, dict]] = {}

    def _state(self) -> dict:
        state = _blank_state()
        state.update(_load(STATE_FILE))
        if state.get("day_key") != datetime.now(timezone.utc).strftime("%Y-%m-%d"):
            state["day_key"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")
            state["day_realized_pnl_gbp"] = 0.0
            state["orders_today"] = 0
        preview = state.get("approval_preview") or {}
        if preview and time.time() > _finite(preview.get("expires_ts")):
            state["approval_preview"] = None
        candidate = state.get("approval_candidate") or {}
        if candidate and time.time() - _finite(candidate.get("created_ts")) > CANDIDATE_TTL_SECONDS:
            state["approval_candidate"] = None
        try:
            self._backfill_ledger_positions(state)
            self._restore_pending_from_ledger(state)
            state["orders_today"] = max(int(state.get("orders_today", 0)), self.ledger.submitted_today())
        except Exception as exc:
            state["ledger_reconciling"] = True
            state["ledger_reconciliation_reason"] = "Live ledger startup check failed: " + str(exc)
        return state

    def _backfill_ledger_positions(self, state: dict) -> None:
        for position in (state.get("positions") or {}).values():
            if (position or {}).get("order_id"):
                self.ledger.register_existing_position(position)

    def _restore_pending_from_ledger(self, state: dict) -> None:
        if state.get("pending_order"):
            return
        unresolved = self.ledger.unresolved_intents()
        if not unresolved:
            return
        if len(unresolved) > 1:
            state["ledger_reconciling"] = True
            state["ledger_reconciliation_reason"] = "Multiple unresolved live intents require a manual Coinbase check"
            return
        row = unresolved[0]
        state["pending_order"] = {
            "symbol": row["symbol"],
            "product_id": row["product_id"],
            "quote_size": row["quote_size_gbp"],
            "stop_price": row["stop_price"],
            "target_price": row["target_price"],
            "client_order_id": row["client_order_id"],
            "order_id": row.get("exchange_order_id"),
            "created_ts": row["created_ts"],
            "manual_approval_id": row.get("manual_approval_id"),
            "restored_from_ledger": True,
        }

    def _client(self, cfg: dict):
        path = Path(str(cfg.get("key_file") or "")).expanduser().resolve()
        if not path.is_file():
            raise RuntimeError("Configured Coinbase live key file was not found.")
        if self._client_obj is None or self._client_key != str(path):
            self._client_obj = _make_client(path)
            self._client_key = str(path)
        return self._client_obj

    def _armed(self, cfg: dict, settings: dict) -> bool:
        return bool(settings.get("live_trading_enabled")) and str(settings.get("execution_mode") or "").lower() == "live_supervised" and cfg.get("armed") is True and cfg.get("enabled") is True

    def _sync_fee_profile(self, client, state: dict) -> dict:
        summary = _as_dict(client.get("/api/v3/brokerage/transaction_summary"))
        fee = coinbase_readonly._parse_fee_tier(summary)
        payload = {
            "maker_fee_rate": fee["maker_fee_rate"],
            "taker_fee_rate": fee["taker_fee_rate"],
            "source": "COINBASE AUTHENTICATED SCOPED SUPERVISED LIVE",
            "note": "Fetched from Coinbase transaction_summary after View+Trade / Transfer-OFF verification.",
            "pricing_tier": fee.get("pricing_tier"),
            "fetched_at": time.time(),
            "verified_read_only": False,
            "verified_scoped_live_key": True,
        }
        _save(FEE_OVERRIDE_FILE, payload)
        state["last_fee_sync_ts"] = payload["fetched_at"]
        state["last_fee_sync_error"] = None
        state["fee_pricing_tier"] = fee.get("pricing_tier")
        return fee

    def refresh_fee_only(self, force: bool = False) -> dict:
        with self._lock:
            cfg = _load(CONFIG_FILE)
            state = self._state()
            if not cfg.get("enabled"):
                return {"ok": False, "configured": False, "reason": "supervised live not configured"}
            if not force and time.time() - _finite(state.get("last_fee_sync_ts")) < 3600:
                return {"ok": True, "cached": True, "last_fee_sync_ts": state.get("last_fee_sync_ts"), "pricing_tier": state.get("fee_pricing_tier")}
            try:
                client = self._client(cfg)
                perms = _as_dict(client.get("/api/v3/brokerage/key_permissions"))
                ok, detail = permission_check(perms)
                if not ok:
                    raise RuntimeError(detail)
                if str(perms.get("portfolio_uuid")) != str(cfg.get("portfolio_uuid")):
                    raise RuntimeError("Coinbase portfolio scope changed; fee refresh refused")
                fee = self._sync_fee_profile(client, state)
                _save(STATE_FILE, state)
                return {"ok": True, "cached": False, "last_fee_sync_ts": state.get("last_fee_sync_ts"), "pricing_tier": fee.get("pricing_tier"), "maker_fee_rate": fee.get("maker_fee_rate"), "taker_fee_rate": fee.get("taker_fee_rate")}
            except Exception as exc:
                state["last_fee_sync_error"] = str(exc)
                _save(STATE_FILE, state)
                return {"ok": False, "error": str(exc), "configured": True}

    def _product(self, client, product_id: str) -> dict:
        cached = self._products.get(product_id)
        if cached and time.time() - cached[0] < 3600:
            return cached[1]
        raw = _as_dict(client.get(f"/api/v3/brokerage/products/{product_id}"))
        product = _as_dict(raw.get("product") or raw)
        if not product:
            raise RuntimeError(f"Coinbase product metadata unavailable for {product_id}")
        self._products[product_id] = (time.time(), product)
        return product

    def _order(self, client, order_id: str, force: bool = False) -> dict:
        cached = self._orders.get(order_id)
        if cached and not force and time.time() - cached[0] < 15:
            return cached[1]
        raw = _as_dict(client.get(f"/api/v3/brokerage/orders/historical/{order_id}"))
        order = _as_dict(raw.get("order") or raw)
        self._orders[order_id] = (time.time(), order)
        return order

    @staticmethod
    def _get_with_params(client, path: str, params: dict) -> dict:
        """Support both current Coinbase SDK params and older generic clients."""
        try:
            return _as_dict(client.get(path, params=params))
        except TypeError:
            query = urllib.parse.urlencode(params, doseq=True)
            return _as_dict(client.get(path + ("?" + query if query else "")))

    def _find_order_by_client_id(self, client, client_order_id: str) -> dict:
        """Read recent Coinbase history and match the exact idempotency identifier."""
        raw = _as_dict(client.get("/api/v3/brokerage/orders/historical/batch"))
        for value in raw.get("orders") or []:
            order = _as_dict(value)
            if str(order.get("client_order_id") or "") == str(client_order_id):
                return order
        return {}

    def _record_order_fills(self, client, client_order_id: str, order_id: str) -> int:
        raw = self._get_with_params(
            client, "/api/v3/brokerage/orders/historical/fills", {"order_ids": [str(order_id)]}
        )
        inserted = 0
        for value in raw.get("fills") or []:
            fill = _as_dict(value)
            if str(fill.get("order_id") or "") == str(order_id):
                inserted += int(self.ledger.record_fill(client_order_id, fill))
        return inserted

    @staticmethod
    def _set_ledger_reconciling(state: dict, reason: str) -> None:
        state["ledger_reconciling"] = True
        state["ledger_reconciliation_reason"] = reason
        state["last_error"] = reason
        state["last_action"] = "LIVE LEDGER RECONCILING — no new approval permitted"
        state["approval_candidate"] = None
        state["approval_preview"] = None

    @staticmethod
    def _clear_ledger_reconciling(state: dict) -> None:
        state["ledger_reconciling"] = False
        state["ledger_reconciliation_reason"] = None

    @staticmethod
    def _order_prices(order: dict) -> tuple[float, float]:
        """Extract Coinbase-accepted bracket prices from nested REST responses."""
        stops, targets = [], []
        def walk(value, parent=""):
            if isinstance(value, dict):
                for key, child in value.items():
                    name = str(key).lower()
                    if name in {"stop_trigger_price", "stop_price"}:
                        stops.append(_finite(child))
                    elif name == "limit_price" and ("limit" in parent or "take" in parent or "bracket" in parent):
                        targets.append(_finite(child))
                    walk(child, name)
            elif isinstance(value, list):
                for child in value: walk(child, parent)
        walk(order)
        return next((x for x in stops if x > 0), 0.0), next((x for x in targets if x > 0), 0.0)

    def _verify_position_orders(self, client, pos: dict) -> None:
        parent_id = str(pos.get("order_id") or "")
        if parent_id:
            parent = self._order(client, parent_id)
            entry = _finite(parent.get("average_filled_price"))
            size = _finite(parent.get("filled_size"))
            value = _finite(parent.get("filled_value"))
            fees = _finite(parent.get("total_fees"))
            if entry > 0: pos["entry_price"] = entry
            if size > 0: pos["filled_size"] = size
            if value > 0: pos["entry_cost_gbp"] = value + fees
            if entry > 0 or size > 0:
                pos["entry_verified_ts"] = time.time()
                pos["entry_source"] = "Coinbase filled parent order"
        child_id = str(pos.get("attached_order_id") or "")
        if child_id:
            child = self._order(client, child_id)
            stop, target = self._order_prices(child)
            pos.setdefault("model_stop_price", pos.get("stop_price"))
            pos.setdefault("model_target_price", pos.get("target_price"))
            if stop > 0: pos["stop_price"] = stop
            if target > 0: pos["target_price"] = target
            pos["protection_status"] = str(child.get("status") or "UNKNOWN").upper()
            if stop > 0 and target > 0:
                pos["protection_verified_ts"] = time.time()
                pos["protection_source"] = "Coinbase attached bracket order"
            else:
                pos["protection_source"] = "Awaiting Coinbase bracket-price verification"

    def _trip_lock(self, state: dict, reason: str) -> None:
        state["safety_lock"] = True
        state["safety_lock_reason"] = reason
        state["last_error"] = reason
        state["last_action"] = "LIVE SAFETY LOCK"
        state["approval_candidate"] = None
        state["approval_preview"] = None

    def _sync_positions(self, client, state: dict) -> None:
        for symbol, pos in list((state.get("positions") or {}).items()):
            child = str((pos or {}).get("attached_order_id") or "")
            if not child:
                self._trip_lock(state, f"{symbol} has no confirmed exchange stop/target order")
                continue
            self._verify_position_orders(client, pos)
            ledger_row = self.ledger.register_existing_position(pos)
            parent = self._order(client, str(pos.get("order_id") or ""), force=True)
            self.ledger.record_order(ledger_row["client_order_id"], parent)
            self.ledger.mark_position_open(ledger_row["client_order_id"], child)
            order = self._order(client, child)
            status = str(order.get("status") or "").upper()
            if status == "FILLED":
                proceeds = _finite(order.get("filled_value"))
                fees = _finite(order.get("total_fees"))
                pnl = proceeds - fees - _finite(pos.get("entry_cost_gbp"))
                state["day_realized_pnl_gbp"] = _finite(state.get("day_realized_pnl_gbp")) + pnl
                state["lifetime_realized_pnl_gbp"] = _finite(state.get("lifetime_realized_pnl_gbp")) + pnl
                state.setdefault("trades", []).append({"ts": time.time(), "symbol": symbol, "side": "SELL", "order_id": child, "pnl_gbp": pnl})
                self.ledger.mark_position_closed(str(pos.get("order_id") or ""), order)
                del state["positions"][symbol]
                state["last_action"] = f"LIVE CLOSED {symbol} P/L £{pnl:+.2f}"
            elif status in {"CANCELLED", "CANCELED", "FAILED", "REJECTED", "EXPIRED"}:
                self._trip_lock(state, f"Exchange protection for {symbol} is {status}; manual Coinbase check required")

    def _reconcile_pending(self, client, state: dict) -> None:
        pending = state.get("pending_order") or {}
        if not pending:
            return
        client_order_id = str(pending.get("client_order_id") or "").strip()
        if not client_order_id:
            self._set_ledger_reconciling(state, "Pending live order has no client_order_id; manual Coinbase check required")
            return
        existing = self.ledger.intent(client_order_id)
        if not existing:
            self.ledger.create_intent(pending)
            if not pending.get("ledger_recorded"):
                self.ledger.mark_submission_unknown(client_order_id, "Imported pre-R5.6 pending result")
        ledger_row = self.ledger.intent(client_order_id)
        order_id = str(pending.get("order_id") or "")
        if not order_id:
            recovered = self._find_order_by_client_id(client, client_order_id)
            if recovered:
                order_id = str(recovered.get("order_id") or "")
                if order_id:
                    pending["order_id"] = order_id
                    state["pending_order"] = pending
                    self.ledger.mark_submitted(client_order_id, order_id)
            if not order_id:
                if ledger_row.get("state") == "INTENT_RECORDED" and pending.get("ledger_recorded"):
                    self.ledger.mark_resolved_no_fill(client_order_id, "NOT_SUBMITTED")
                    state["pending_order"] = None
                    self._clear_ledger_reconciling(state)
                    state["last_action"] = "Recovered pre-submit restart — Coinbase order was never sent"
                    self.ledger.record_reconciliation(True, "No network submission began; intent closed without a fill")
                    return
                self.ledger.mark_submission_unknown(client_order_id, "Coinbase history has not confirmed this approved order yet")
                self._set_ledger_reconciling(
                    state,
                    "Approved order result is not yet visible in Coinbase history; refusing any duplicate order",
                )
                self.ledger.record_reconciliation(False, "Unknown submission remains unmatched")
                return
        order = self._order(client, order_id, force=True)
        self.ledger.record_order(client_order_id, order)
        try:
            self._record_order_fills(client, client_order_id, order_id)
        except Exception:
            # Get Order remains authoritative for state; fill-level history is retried later.
            pass
        status = str(order.get("status") or "").upper()
        self._clear_ledger_reconciling(state)
        if status in {"OPEN", "PENDING", "QUEUED", "UNKNOWN", "CANCEL_QUEUED", "EDIT_QUEUED"}:
            state["last_action"] = f"Waiting for Coinbase order {order_id[-8:]}"
            self.ledger.record_reconciliation(True, f"Known Coinbase order is {status or 'PENDING'}")
            return
        filled_size = _finite(order.get("filled_size"))
        if status != "FILLED" and filled_size <= 0:
            state["pending_order"] = None
            state["last_action"] = f"Coinbase approved entry ended {status or 'without fill'}"
            self.ledger.mark_resolved_no_fill(client_order_id, status or "NO_FILL")
            self.ledger.record_reconciliation(True, f"Coinbase order ended {status or 'without fill'}")
            return
        child = str(order.get("attached_order_id") or "")
        if not child:
            self._trip_lock(state, "Entry filled but Coinbase did not confirm the attached stop/target order")
            return
        symbol = str(pending["symbol"])
        filled_value = _finite(order.get("filled_value"), _finite(pending.get("quote_size")))
        fees = _finite(order.get("total_fees"))
        position = {
            "symbol": symbol,
            "product_id": pending["product_id"],
            "order_id": order_id,
            "attached_order_id": child,
            "filled_size": filled_size,
            "entry_price": _finite(order.get("average_filled_price")),
            "entry_cost_gbp": filled_value + fees,
            "stop_price": pending["stop_price"],
            "target_price": pending["target_price"],
            "model_stop_price": pending["stop_price"],
            "model_target_price": pending["target_price"],
            "opened_ts": time.time(),
        }
        self._verify_position_orders(client, position)
        state.setdefault("positions", {})[symbol] = position
        state.setdefault("trades", []).append({"ts": time.time(), "symbol": symbol, "side": "BUY", "order_id": order_id, "cost_gbp": filled_value + fees, "manual_approval": True})
        self.ledger.mark_position_open(client_order_id, child)
        state["pending_order"] = None
        state["last_action"] = f"LIVE BOUGHT {symbol} £{filled_value:.2f} after manual approval"
        self.ledger.record_reconciliation(True, "Filled parent and attached Coinbase protection verified")

    def _qualified(self, symbol: str, row: dict, settings: dict) -> bool:
        probe = row.get("paper_probe") or {}
        council = row.get("decision_council") or {}
        activity = row.get("market_opportunity") or {}
        quality = row.get("market_quality") or {}
        meme = row.get("meme_intelligence") or {}
        is_meme = bool(meme.get("is_meme")) or meme_intelligence.is_meme(symbol, settings)
        min_prob = _finite(settings.get("live_min_probability"), .60)
        if is_meme:
            min_prob = max(min_prob, _finite(settings.get("meme_live_min_probability"), .63))
            meme_ok = all((
                not bool(meme.get("pump_risk")),
                _finite(meme.get("score")) >= _finite(settings.get("meme_live_min_score"), 58.0),
                _finite(activity.get("activity_score")) >= _finite(settings.get("meme_min_activity_score"), 55.0),
                _finite(quality.get("score")) >= _finite(settings.get("meme_min_market_quality_score"), 50.0),
                bool(meme.get("safe_reclaim")) or not bool(activity.get("chase_risk")),
            ))
        else:
            meme_ok = True
        return all((
            str(row.get("action") or "").upper() == "BUY",
            str(row.get("base_action") or "").upper() == "BUY",
            not (row.get("base_blockers") or []),
            not bool(probe.get("active")),
            not bool(row.get("stale")),
            str(row.get("execution_buy_venue") or "Coinbase") == "Coinbase",
            _finite(row.get("calibrated_probability", row.get("ensemble_probability"))) >= min_prob,
            _finite(council.get("score")) >= _finite(settings.get("live_min_council_score"), 60.0),
            _finite(activity.get("activity_score")) >= _finite(settings.get("live_min_activity_score"), 50.0),
            quality.get("pass") is True,
            meme_ok,
        ))

    def _limits_ok(self, state: dict, settings: dict) -> tuple[bool, str]:
        if state.get("safety_lock"):
            return False, str(state.get("safety_lock_reason") or "live safety lock active")
        ledger_status = self.ledger.status()
        if not ledger_status.get("ok") or state.get("ledger_reconciling"):
            return False, str(
                state.get("ledger_reconciliation_reason")
                or ledger_status.get("last_message")
                or "Live order ledger is reconciling"
            )
        if state.get("pending_order"):
            return False, "A previously approved Coinbase order is still unresolved"
        if _finite(state.get("day_realized_pnl_gbp")) <= -min(_finite(settings.get("live_daily_loss_limit_gbp"), HARD_DAILY_LOSS_GBP), HARD_DAILY_LOSS_GBP):
            return False, "Daily live loss limit reached"
        if _finite(state.get("lifetime_realized_pnl_gbp")) <= -min(_finite(settings.get("live_lifetime_loss_limit_gbp"), HARD_LIFETIME_LOSS_GBP), HARD_LIFETIME_LOSS_GBP):
            return False, "Lifetime supervised-live loss limit reached"
        if int(state.get("orders_today", 0)) >= min(int(settings.get("live_max_orders_per_day", HARD_MAX_ORDERS_PER_DAY)), HARD_MAX_ORDERS_PER_DAY):
            return False, "Daily live order limit reached"
        if len(state.get("positions") or {}) >= min(int(settings.get("live_max_positions", HARD_MAX_POSITIONS)), HARD_MAX_POSITIONS):
            return False, "Maximum live positions already open"
        exposure = sum(_finite(x.get("entry_cost_gbp")) for x in (state.get("positions") or {}).values())
        order_cap = min(_finite(settings.get("live_order_cap_gbp"), HARD_ORDER_CAP_GBP), HARD_ORDER_CAP_GBP)
        exposure_cap = min(_finite(settings.get("live_max_total_exposure_gbp"), HARD_EXPOSURE_CAP_GBP), HARD_EXPOSURE_CAP_GBP)
        minimum = min(order_cap, max(1.0, _finite(settings.get("live_dynamic_min_order_gbp"), 4.0)))
        if exposure + minimum > exposure_cap + 1e-9:
            return False, "Maximum live exposure leaves no room for the minimum supervised order"
        return True, "OK"

    def _candidate_from_row(self, symbol: str, row: dict, settings: dict, state: dict | None = None) -> dict:
        product_id = str(row.get("product_id") or row.get("pair") or f"{symbol}-GBP")
        price = _finite(row.get("coinbase_price") or row.get("price"))
        plan = row.get("trade_plan") or {}
        stop = _finite(plan.get("stop_price"), price * (1.0 - max(.015, _finite(plan.get("stop_pct"), .02))))
        target = _finite(plan.get("target_price"), price * (1.0 + max(.025, _finite(plan.get("target_pct"), .04))))
        alloc = allocation_engine.plan(
            symbol, row, state or {}, settings,
            hard_bankroll=HARD_BANKROLL_CAP_GBP,
            hard_order_cap=HARD_ORDER_CAP_GBP,
            hard_exposure_cap=HARD_EXPOSURE_CAP_GBP,
        ) if settings.get("live_dynamic_sizing_enabled", True) else {
            "quote_size_gbp": min(_finite(settings.get("live_order_cap_gbp"), HARD_ORDER_CAP_GBP), HARD_ORDER_CAP_GBP),
            "allocation_score": 50.0, "risk_at_stop_gbp": 0.0, "risk_budget_gbp": 0.0,
            "allocation_pct_bankroll": 0.0, "edge_multiple": 0.0, "concentration_multiplier": 1.0,
            "reason": "fixed supervised-live order size",
        }
        return {
            "candidate_id": str(uuid.uuid4()),
            "symbol": symbol,
            "product_id": product_id,
            "quote_size": _finite(alloc.get("quote_size_gbp")),
            "price": price,
            "stop_price": stop,
            "target_price": target,
            "expected_return": _finite(row.get("expected_return")),
            "probability": _finite(row.get("calibrated_probability", row.get("ensemble_probability"))),
            "council_score": _finite((row.get("decision_council") or {}).get("score")),
            "activity_score": _finite((row.get("market_opportunity") or {}).get("activity_score")),
            "is_meme": bool((row.get("meme_intelligence") or {}).get("is_meme")),
            "meme_state": str((row.get("meme_intelligence") or {}).get("state") or ""),
            "meme_score": _finite((row.get("meme_intelligence") or {}).get("score")),
            "allocation_score": _finite(alloc.get("allocation_score")),
            "risk_at_stop_gbp": _finite(alloc.get("risk_at_stop_gbp")),
            "risk_budget_gbp": _finite(alloc.get("risk_budget_gbp")),
            "allocation_pct_bankroll": _finite(alloc.get("allocation_pct_bankroll")),
            "edge_multiple": _finite(alloc.get("edge_multiple")),
            "concentration_multiplier": _finite(alloc.get("concentration_multiplier"), 1.0),
            "allocation_reason": str(alloc.get("reason") or ""),
            "created_ts": time.time(),
        }

    def _best_candidate(self, payload: dict, state: dict, settings: dict) -> tuple[str | None, dict | None]:
        candidates = []
        for symbol, row in (payload.get("assets") or {}).items():
            row = row or {}
            if symbol in (state.get("positions") or {}):
                continue
            if self._qualified(symbol, row, settings):
                alloc = allocation_engine.plan(
                    symbol, row, state, settings,
                    hard_bankroll=HARD_BANKROLL_CAP_GBP,
                    hard_order_cap=HARD_ORDER_CAP_GBP,
                    hard_exposure_cap=HARD_EXPOSURE_CAP_GBP,
                )
                if _finite(alloc.get("quote_size_gbp")) <= 0:
                    continue
                prob=_finite(row.get("calibrated_probability", row.get("ensemble_probability")))
                expected=_finite(row.get("expected_return"))
                allocation_score=_finite(alloc.get("allocation_score"))
                meme=row.get("meme_intelligence") or {}
                # R4 ranks already-qualified trades by risk-adjusted allocation quality
                # plus remaining expected edge.  Meme status never creates eligibility.
                priority=(allocation_score/100.0)*0.65 + min(.12,max(0.0,expected))*1.8 + prob*0.18
                if meme.get("is_meme") and meme.get("safe_reclaim"):
                    priority += min(0.03,_finite(meme.get("score"))/3000.0)
                candidates.append((priority, allocation_score, prob, expected, symbol, row))
        if not candidates:
            return None, None
        _, _, _, _, symbol, row = sorted(candidates, reverse=True)[0]
        return symbol, row

    def _preview_payload(self, client, symbol: str, row: dict, settings: dict, state: dict | None = None) -> tuple[dict, dict]:
        candidate = self._candidate_from_row(symbol, row, settings, state)
        product = self._product(client, candidate["product_id"])
        quote_size = candidate["quote_size"]
        quote_min = _finite(product.get("quote_min_size"), 999999.0)
        if quote_size + 1e-9 < quote_min:
            raise RuntimeError(f"{candidate['product_id']} requires at least £{quote_min:g}; £{quote_size:g} supervised order skipped")
        increment = str(product.get("quote_increment") or "0.01")
        configuration = {"market_market_ioc": {"quote_size": f"{quote_size:.2f}"}}
        attached = {"trigger_bracket_gtc": {"limit_price": _quantize(candidate["target_price"], increment), "stop_trigger_price": _quantize(candidate["stop_price"], increment)}}
        order_payload = {"product_id": candidate["product_id"], "side": "BUY", "order_configuration": configuration, "attached_order_configuration": attached}
        preview = _as_dict(client.post("/api/v3/brokerage/orders/preview", data=order_payload))
        errs = preview.get("errs") or []
        if errs:
            raise RuntimeError("Coinbase preview rejected entry: " + ", ".join(str(x) for x in errs[:3]))
        preview_id = str(preview.get("preview_id") or "")
        if not preview_id:
            raise RuntimeError("Coinbase preview did not return a preview_id")
        commission = _finite(preview.get("commission_total"))
        fee_rate = commission / quote_size if quote_size else 1.0
        required = 2.0 * fee_rate + _finite(settings.get("live_min_edge_after_preview"), .003)
        if candidate["expected_return"] < required:
            raise RuntimeError(f"{symbol} expected edge {candidate['expected_return']:.2%} is below previewed round-trip cost plus buffer {required:.2%}")
        candidate.update({
            "coinbase_preview_id": preview_id,
            "commission_gbp": commission,
            "preview_fee_rate": fee_rate,
            "required_return": required,
            "estimated_fill_price": _finite(preview.get("est_average_filled_price"), candidate["price"]),
            "order_payload": order_payload,
        })
        return candidate, preview

    def process(self, payload: dict, settings: dict) -> dict:
        """Autonomous loop: reconcile/safety/check candidates only. NEVER submits an order."""
        with self._lock:
            cfg = _load(CONFIG_FILE)
            state = self._state()
            armed = self._armed(cfg, settings)
            if not armed:
                state["last_action"] = "SUPERVISED LIVE DISARMED — PAPER continues"
                state["approval_candidate"] = None
                state["approval_preview"] = None
                _save(STATE_FILE, state)
                return self._public(state, False, False, cfg, settings)
            if state.get("safety_lock"):
                return self._public(state, True, False, cfg, settings)
            try:
                client = self._client(cfg)
                if time.time() - _finite(state.get("verified_ts")) > 900:
                    perms = _as_dict(client.get("/api/v3/brokerage/key_permissions"))
                    ok, detail = permission_check(perms)
                    if not ok or str(perms.get("portfolio_uuid")) != str(cfg.get("portfolio_uuid")):
                        raise RuntimeError(detail if not ok else "Coinbase portfolio scope changed")
                    state["verified_ts"] = time.time()
                if time.time() - _finite(state.get("last_fee_sync_ts")) > 3600:
                    try:
                        self._sync_fee_profile(client, state)
                    except Exception as fee_exc:
                        state["last_fee_sync_error"] = str(fee_exc)
                self._reconcile_pending(client, state)
                if state.get("safety_lock") or state.get("pending_order"):
                    _save(STATE_FILE, state)
                    return self._public(state, True, not state.get("safety_lock"), cfg, settings)
                self._sync_positions(client, state)
                ok_limits, reason = self._limits_ok(state, settings)
                if not ok_limits:
                    if "loss limit" in reason.lower():
                        self._trip_lock(state, reason)
                    else:
                        state["last_action"] = reason
                    state["approval_candidate"] = None
                    state["approval_preview"] = None
                else:
                    symbol, row = self._best_candidate(payload, state, settings)
                    if not symbol:
                        state["approval_candidate"] = None
                        state["approval_preview"] = None
                        state["last_action"] = "LIVE SUPERVISOR WAITING — no qualified candidate"
                    else:
                        current = state.get("approval_candidate") or {}
                        if str(current.get("symbol")) != symbol or time.time() - _finite(current.get("created_ts")) > CANDIDATE_TTL_SECONDS:
                            state["approval_candidate"] = self._candidate_from_row(symbol, row, settings, state)
                            state["approval_preview"] = None
                        elif state.get("approval_preview"):
                            # Keep preview only while the same candidate remains fully qualified.
                            pass
                        state["last_action"] = f"AWAITING MANUAL APPROVAL — {symbol} qualifies"
                _save(STATE_FILE, state)
                return self._public(state, True, not state.get("safety_lock"), cfg, settings)
            except Exception as exc:
                state["last_error"] = str(exc)
                state["last_action"] = "LIVE SUPERVISOR PAUSED — " + str(exc)
                _save(STATE_FILE, state)
                return self._public(state, True, False, cfg, settings)

    def preview_candidate(self, payload: dict, settings: dict) -> dict:
        """PC-local user action: preview only. Coinbase Preview Order is not an execution."""
        with self._lock:
            cfg = _load(CONFIG_FILE)
            state = self._state()
            if not self._armed(cfg, settings):
                raise RuntimeError("Supervised live is not armed. Run SETUP_COINBASE_LIVE_100_SUPERVISED.bat on the PC first.")
            ok_limits, reason = self._limits_ok(state, settings)
            if not ok_limits:
                raise RuntimeError(reason)
            symbol, row = self._best_candidate(payload, state, settings)
            if not symbol:
                state["approval_candidate"] = None
                state["approval_preview"] = None
                _save(STATE_FILE, state)
                raise RuntimeError("No fully qualified live candidate is available now.")
            client = self._client(cfg)
            candidate, _preview = self._preview_payload(client, symbol, row, settings, state)
            approval_id = str(uuid.uuid4())
            phrase = f"BUY {symbol} £{candidate['quote_size']:.2f}"
            approval = {
                "approval_id": approval_id,
                "symbol": symbol,
                "product_id": candidate["product_id"],
                "quote_size": candidate["quote_size"],
                "stop_price": candidate["stop_price"],
                "target_price": candidate["target_price"],
                "expected_return": candidate["expected_return"],
                "probability": candidate["probability"],
                "commission_gbp": candidate["commission_gbp"],
                "required_return": candidate["required_return"],
                "estimated_fill_price": candidate["estimated_fill_price"],
                "coinbase_preview_id": candidate["coinbase_preview_id"],
                "allocation_score": candidate.get("allocation_score"),
                "risk_at_stop_gbp": candidate.get("risk_at_stop_gbp"),
                "risk_budget_gbp": candidate.get("risk_budget_gbp"),
                "allocation_pct_bankroll": candidate.get("allocation_pct_bankroll"),
                "edge_multiple": candidate.get("edge_multiple"),
                "allocation_reason": candidate.get("allocation_reason"),
                "confirmation_phrase": phrase,
                "created_ts": time.time(),
                "expires_ts": time.time() + PREVIEW_TTL_SECONDS,
            }
            state["approval_candidate"] = candidate
            state["approval_preview"] = approval
            state["last_action"] = f"PREVIEW READY — click {phrase} on this PC to submit"
            _save(STATE_FILE, state)
            return {"ok": True, "preview": self._public_preview(approval), "live": self._public(state, True, True, cfg, settings)}

    def approve_preview(self, approval_id: str, confirmation: str, payload: dict, settings: dict) -> dict:
        """PC-local user action: the BUY button is the approval; a fresh re-preview is required before POST /orders.

        ``confirmation`` is retained for backward compatibility with older dashboards but is no longer
        required. The server endpoint remains PC-local, and the approval_id can only come from an
        explicit Coinbase preview requested on this PC.
        """
        with self._lock:
            cfg = _load(CONFIG_FILE)
            state = self._state()
            if not self._armed(cfg, settings):
                raise RuntimeError("Supervised live is not armed.")
            approval = state.get("approval_preview") or {}
            if not approval or str(approval.get("approval_id")) != str(approval_id or ""):
                raise RuntimeError("That live preview is missing or no longer current. Preview again.")
            if time.time() > _finite(approval.get("expires_ts")):
                state["approval_preview"] = None
                _save(STATE_FILE, state)
                raise RuntimeError("That live preview expired. Preview again.")
            # The PC-local BUY button itself is the explicit manual approval. No typed phrase is
            # required; the order still cannot be submitted by the autonomous engine.
            ok_limits, reason = self._limits_ok(state, settings)
            if not ok_limits:
                raise RuntimeError(reason)
            symbol, row = self._best_candidate(payload, state, settings)
            if symbol != str(approval.get("symbol")) or not row:
                state["approval_preview"] = None
                _save(STATE_FILE, state)
                raise RuntimeError("The candidate changed or no longer qualifies. Preview again.")
            client = self._client(cfg)
            fresh, _preview = self._preview_payload(client, symbol, row, settings, state)
            approved_cap = _finite(approval.get("quote_size"))
            fresh_size = _finite(fresh.get("quote_size"))
            # Treat the amount shown on the BUY button as an "up to" cap. A smaller fresh size is
            # safer and can proceed; any increase requires a new preview and another click.
            if fresh_size > approved_cap + 0.005:
                state["approval_preview"] = None
                _save(STATE_FILE, state)
                raise RuntimeError(f"Fresh order size increased from £{approved_cap:.2f} to £{fresh_size:.2f}; review the trade again.")
            old_est = _finite(approval.get("estimated_fill_price"))
            new_est = _finite(fresh.get("estimated_fill_price"))
            if old_est > 0 and new_est > 0:
                drift = abs(new_est / old_est - 1.0)
                max_drift = min(max(_finite(settings.get("live_approval_max_price_drift_pct"), .005), .001), .01)
                if drift > max_drift:
                    state["approval_preview"] = None
                    _save(STATE_FILE, state)
                    raise RuntimeError(f"Estimated fill moved {drift:.2%} since your preview; review the trade again.")
            intent = {
                "symbol": symbol,
                "product_id": fresh["product_id"],
                "side": "BUY",
                "quote_size": fresh["quote_size"],
                "stop_price": fresh["stop_price"],
                "target_price": fresh["target_price"],
                "client_order_id": str(uuid.uuid4()),
                "order_id": None,
                "created_ts": time.time(),
                "manual_approval_id": approval_id,
                "ledger_recorded": True,
            }
            # FULL-synchronous SQLite commit happens before the network call. If the
            # process exits later, recovery uses this exact Coinbase idempotency key.
            self.ledger.create_intent(intent)
            state["pending_order"] = intent
            _save(STATE_FILE, state)
            create_payload = dict(fresh["order_payload"])
            create_payload.update({"client_order_id": intent["client_order_id"], "preview_id": fresh["coinbase_preview_id"]})
            self.ledger.mark_submission_started(intent["client_order_id"])
            try:
                created = _as_dict(client.post("/api/v3/brokerage/orders", data=create_payload))
            except Exception as exc:
                self.ledger.mark_submission_unknown(intent["client_order_id"], exc)
                self._set_ledger_reconciling(
                    state,
                    "Coinbase submission response was interrupted; checking order history before any further approval",
                )
                _save(STATE_FILE, state)
                raise RuntimeError(
                    "Coinbase result is temporarily unknown. No retry or duplicate order was sent; the live ledger is reconciling."
                ) from exc
            success = bool(created.get("success"))
            response = _as_dict(created.get("success_response"))
            order_id = str(response.get("order_id") or created.get("order_id") or "")
            if not success:
                state["pending_order"] = None
                err = _as_dict(created.get("error_response"))
                self.ledger.mark_resolved_no_fill(
                    intent["client_order_id"],
                    str(err.get("error") or "REJECTED"),
                    str(err.get("message") or err.get("error") or "Coinbase rejected the order"),
                )
                _save(STATE_FILE, state)
                raise RuntimeError("Coinbase create order failed: " + str(err.get("message") or err.get("error") or "unknown response"))
            if not order_id:
                self.ledger.mark_submission_unknown(intent["client_order_id"], "Successful Coinbase response omitted order_id")
                self._set_ledger_reconciling(
                    state,
                    "Coinbase accepted the request but did not return an order ID; checking history before any further approval",
                )
                _save(STATE_FILE, state)
                raise RuntimeError("Coinbase accepted the request without an order ID. The live ledger is reconciling and will not retry it.")
            self.ledger.mark_submitted(intent["client_order_id"], order_id)
            state["pending_order"]["order_id"] = order_id
            state["orders_today"] = max(int(state.get("orders_today", 0)) + 1, self.ledger.submitted_today())
            state["approval_preview"] = None
            state["approval_candidate"] = None
            self._clear_ledger_reconciling(state)
            state["last_action"] = f"MANUALLY APPROVED {symbol} — Coinbase order sent"
            _save(STATE_FILE, state)
            self._reconcile_pending(client, state)
            _save(STATE_FILE, state)
            return {"ok": True, "submitted": True, "order_id": order_id, "live": self._public(state, True, not state.get("safety_lock"), cfg, settings)}

    def cancel_preview(self, settings: dict) -> dict:
        with self._lock:
            cfg = _load(CONFIG_FILE)
            state = self._state()
            state["approval_preview"] = None
            state["approval_candidate"] = None
            state["last_action"] = "Live preview cancelled — no order sent"
            _save(STATE_FILE, state)
            return self._public(state, self._armed(cfg, settings), not state.get("safety_lock"), cfg, settings)

    def _public_preview(self, approval: dict) -> dict:
        if not approval:
            return {}
        return {k: approval.get(k) for k in (
            "approval_id", "symbol", "product_id", "quote_size", "stop_price", "target_price",
            "expected_return", "probability", "commission_gbp", "required_return",
            "estimated_fill_price", "allocation_score", "risk_at_stop_gbp", "risk_budget_gbp",
            "allocation_pct_bankroll", "edge_multiple", "allocation_reason", "confirmation_phrase", "created_ts", "expires_ts",
        )}

    def _public_candidate(self, candidate: dict) -> dict:
        if not candidate:
            return {}
        return {k: candidate.get(k) for k in (
            "candidate_id", "symbol", "product_id", "quote_size", "price", "stop_price",
            "target_price", "expected_return", "probability", "council_score", "activity_score", "allocation_score",
            "risk_at_stop_gbp", "risk_budget_gbp", "allocation_pct_bankroll", "edge_multiple",
            "concentration_multiplier", "allocation_reason", "created_ts",
        )}

    def _public(self, state: dict, armed: bool, ready: bool, cfg: dict | None = None, settings: dict | None = None) -> dict:
        cfg = cfg or _load(CONFIG_FILE)
        settings = settings or {}
        ledger_status = self.ledger.status()
        ledger_ready = bool(ledger_status.get("ok")) and not bool(state.get("ledger_reconciling"))
        safe_ready = bool(ready) and ledger_ready and not bool(state.get("pending_order"))
        bankroll = min(_finite(cfg.get("bankroll_cap_gbp"), HARD_BANKROLL_CAP_GBP), HARD_BANKROLL_CAP_GBP)
        order_cap = min(_finite(settings.get("live_order_cap_gbp"), HARD_ORDER_CAP_GBP), HARD_ORDER_CAP_GBP)
        exposure_cap = min(_finite(settings.get("live_max_total_exposure_gbp"), HARD_EXPOSURE_CAP_GBP), HARD_EXPOSURE_CAP_GBP)
        return {
            "ok": not bool(state.get("safety_lock")) and ledger_ready,
            "mode": "LIVE £100 SUPERVISED" if armed else "DISARMED",
            "armed": armed,
            "ready": safe_ready,
            "manual_approval_required": True,
            "autonomous_order_submission": False,
            "approval_pc_only": True,
            "transfer_permission": False,
            "bankroll_cap_gbp": bankroll,
            "order_cap_gbp": order_cap,
            "max_exposure_gbp": exposure_cap,
            "dynamic_sizing_enabled": bool(settings.get("live_dynamic_sizing_enabled", True)),
            "suggested_order_range_gbp": [max(1.0, _finite(settings.get("live_dynamic_min_order_gbp"), 4.0)), order_cap],
            "open_positions": len(state.get("positions") or {}),
            "max_positions": min(int(settings.get("live_max_positions", HARD_MAX_POSITIONS)), HARD_MAX_POSITIONS),
            "remaining_position_slots": max(0, min(int(settings.get("live_max_positions", HARD_MAX_POSITIONS)), HARD_MAX_POSITIONS) - len(state.get("positions") or {})),
            "exposure_gbp": round(sum(_finite(x.get("entry_cost_gbp")) for x in (state.get("positions") or {}).values()), 4),
            "remaining_exposure_gbp": round(max(0.0, exposure_cap - sum(_finite(x.get("entry_cost_gbp")) for x in (state.get("positions") or {}).values())), 4),
            "positions": state.get("positions") or {},
            "orders_today": int(state.get("orders_today", 0)),
            "day_realized_pnl_gbp": _finite(state.get("day_realized_pnl_gbp")),
            "lifetime_realized_pnl_gbp": _finite(state.get("lifetime_realized_pnl_gbp")),
            "candidate": self._public_candidate(state.get("approval_candidate") or {}),
            "approval_preview": self._public_preview(state.get("approval_preview") or {}),
            "pending": bool(state.get("pending_order")),
            "live_ledger": ledger_status,
            "ledger_reconciling": bool(state.get("ledger_reconciling")),
            "ledger_reconciliation_reason": state.get("ledger_reconciliation_reason"),
            "safety_lock": bool(state.get("safety_lock")),
            "safety_lock_reason": state.get("safety_lock_reason"),
            "last_action": state.get("last_action"),
            "last_error": state.get("last_error"),
            "last_fee_sync_ts": state.get("last_fee_sync_ts") or None,
            "last_fee_sync_error": state.get("last_fee_sync_error"),
            "fee_pricing_tier": state.get("fee_pricing_tier"),
            "warning": "Discovery, ranking and sizing are automatic; real-money submission still requires a fresh PC-local preview and one explicit BUY click on this PC.",
        }

    def status(self, settings: dict | None = None) -> dict:
        cfg = _load(CONFIG_FILE)
        state = self._state()
        if settings is None:
            try:
                settings = _load(BASE_DIR / "settings.json")
            except Exception:
                settings = {}
        armed = self._armed(cfg, settings or {})
        return self._public(state, armed, armed and not state.get("safety_lock"), cfg, settings or {})


SERVICE = LiveCanaryService()
