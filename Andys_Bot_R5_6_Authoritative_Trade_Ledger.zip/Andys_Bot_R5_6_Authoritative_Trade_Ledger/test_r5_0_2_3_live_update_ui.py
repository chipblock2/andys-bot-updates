from pathlib import Path
import json, py_compile
ROOT=Path(__file__).resolve().parent
h=(ROOT/'dashboard.html').read_text(encoding='utf-8')
s=(ROOT/'server.py').read_text(encoding='utf-8')
b=json.loads((ROOT/'BUILD_INFO.json').read_text(encoding='utf-8'))
checks={
 'old Paper Probe label removed':'v5.13.1 Paper Probe' not in h,
 'dynamic brand build id':'id="brandBuild"' in h and 'bi.sidebar_label' in h,
 'sidebar Live Update button':'id="liveUpdateNowBtn"' in h and 'LIVE UPDATE' in h,
 'one-click secure update flow':'async function liveUpdateNow()' in h and '/api/check-update' in h and '/api/stage-update' in h and '/api/install-update' in h,
 'full update still asks confirm':'confirm(`LIVE UPDATE: install ${v} now?' in h,
 'build info exposed by server':'data["build_info"] = build_info()' in s,
 'build info central file':(str(b.get('release','')).startswith('Multi-Venue Edge R5') or str(b.get('release','')).startswith('Safety & Evidence R5') or str(b.get('release','')).startswith('Live Order Watch R5') or str(b.get('release','')).startswith('Updater Reliability R5') or str(b.get('release','')).startswith('Authoritative Trade Ledger R5')) and str(b.get('patch','')).startswith('R5'),
 'live updater setup alias':(ROOT/'SETUP_LIVE_UPDATES.bat').exists(),
 'preview state fix preserved':'Live approval/preview state is a fast control-plane state' in s and 'approval_preview' in h,
 'manual live approval preserved':'/api/live-approve' in h and 'Approve live trade' in h,
}
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL'),name)
 if not ok: raise SystemExit(1)
py_compile.compile(str(ROOT/'server.py'),doraise=True)
print(f'RESULT {len(checks)}/{len(checks)} passed')
