#!/usr/bin/env python3
"""Create the R5.6 live ledger and backfill existing protected positions.

This migration is local-only. It performs no Coinbase requests and does not alter
credentials, live_canary_state.json, positions, orders, brackets, or risk settings.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from coinbase_live_ledger import LiveTradeLedger

ROOT = Path(__file__).resolve().parent
STATE_FILE = ROOT / "live_canary_state.json"


def load_state() -> dict:
    try:
        value = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except FileNotFoundError:
        return {}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--in-place-update", action="store_true")
    parser.parse_args()
    ledger = LiveTradeLedger(ROOT / "andys_bot_live_ledger.db")
    state = load_state()
    positions = state.get("positions") or {}
    imported = 0
    for position in positions.values():
        ledger.register_existing_position(position)
        imported += 1
    report = ledger.integrity_report()
    if not report.get("ok"):
        raise RuntimeError("Live ledger integrity failed: " + "; ".join(report.get("issues") or []))
    print(f"R5.6 live ledger ready; {imported} existing protected position(s) recorded without modification.")
    print("Risk limits, credentials, Coinbase orders, brackets, journals and evidence are unchanged.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
