#!/usr/bin/env python3
"""Verified external updater for Andy's Bot.

The running server launches this file only after the release ZIP has been staged and
verified.  The worker validates the hand-off, waits for the server to exit, backs up
program files, applies the release, runs its migration and isolated release tests, and
then restarts the bot.  Runtime credentials, Coinbase positions/orders and evidence are
never copied into the release and are explicitly preserved during apply and rollback.
"""
from __future__ import annotations

import argparse
import ctypes
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile
from pathlib import Path

from update_manager import PRESERVE_NAMES, _find_package_manifest, _sha256


def runtime_preserve(name: str) -> bool:
    return (
        name in PRESERVE_NAMES
        or name.startswith("history_")
        or name.startswith("Andys_Bot_Review_")
        or name in ("review_exports", ".updates", "__pycache__")
        or name.endswith((".db-wal", ".db-shm"))
    )


def _json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _save_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = Path(str(path) + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


class UpdateLog:
    def __init__(self, root: Path):
        self.path = root / ".updates" / "update_apply.log"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def write(self, message: str) -> None:
        line = f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {message}"
        print(line, flush=True)
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")


def _pid_alive(pid: int) -> bool:
    if int(pid or 0) <= 0:
        return False
    if os.name == "nt":
        # SYNCHRONIZE is sufficient to test whether the process still exists.
        handle = ctypes.windll.kernel32.OpenProcess(0x00100000, False, int(pid))
        if not handle:
            return False
        try:
            return ctypes.windll.kernel32.WaitForSingleObject(handle, 0) == 0x00000102
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    try:
        os.kill(int(pid), 0)
        return True
    except OSError:
        return False


def wait_pid(pid: int, seconds: float = 45.0) -> None:
    deadline = time.time() + float(seconds)
    while _pid_alive(pid):
        if time.time() >= deadline:
            raise RuntimeError("Running Andy's Bot process did not exit within 45 seconds")
        time.sleep(0.35)


def preflight(root: Path, zip_path: Path):
    root = root.resolve()
    zip_path = zip_path.resolve()
    if not root.is_dir() or not (root / "server.py").is_file():
        raise RuntimeError("Main Andy's Bot folder is invalid")
    if not zip_path.is_file():
        raise RuntimeError("Verified staged update ZIP is missing")
    meta_path = root / ".updates" / "staged_update.json"
    if not meta_path.is_file():
        raise RuntimeError("Verified staged update metadata is missing")
    meta = _json(meta_path, None)
    if not isinstance(meta, dict):
        raise RuntimeError("Staged update metadata is unreadable")
    wanted = str(meta.get("sha256") or "").lower()
    if len(wanted) != 64 or _sha256(zip_path) != wanted:
        raise RuntimeError("Staged update SHA-256 changed; installation blocked")
    package, archive_root = _find_package_manifest(zip_path)
    staged_package = meta.get("package") or {}
    if str(package.get("version") or "") != str(staged_package.get("version") or ""):
        raise RuntimeError("Staged version does not match the verified package")
    if str(package.get("kind") or "") != str(staged_package.get("kind") or ""):
        raise RuntimeError("Staged package kind does not match the verified metadata")
    required = {str(name) for name in package.get("required_files") or []}
    if str(package.get("kind") or "").lower() == "full":
        for essential in ("server.py", "update_manager.py", "apply_staged_update.py", "run_isolated_tests.py"):
            if essential not in required:
                raise RuntimeError(f"Full release does not declare required updater file: {essential}")
        if not package.get("tests"):
            raise RuntimeError("Full release does not declare isolated safety tests")
    migration = str(package.get("migration_script") or "").strip()
    with zipfile.ZipFile(zip_path) as archive:
        prefix = archive_root + "/" if archive_root not in ("", ".") else ""
        names = set(archive.namelist())
        missing = [name for name in sorted(required) if prefix + name.replace("\\", "/") not in names]
        if missing:
            raise RuntimeError("Release ZIP is missing required files: " + ", ".join(missing))
        missing_tests = [name for name in package.get("tests") or [] if prefix + str(name).replace("\\", "/") not in names]
        if missing_tests:
            raise RuntimeError("Release ZIP is missing declared tests: " + ", ".join(missing_tests))
        if migration and prefix + migration not in archive.namelist():
            raise RuntimeError("Declared migration script is missing from the release")
    free_bytes = shutil.disk_usage(root).free
    required_free = max(50 * 1024 * 1024, zip_path.stat().st_size * 6)
    if free_bytes < required_free:
        raise RuntimeError("Not enough free disk space to back up and validate this update")
    probe = root / ".updates" / "write_probe.tmp"
    probe.write_text("ok", encoding="utf-8")
    probe.unlink(missing_ok=True)
    return meta, package, archive_root


def code_backup(root: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in root.iterdir():
            if runtime_preserve(path.name):
                continue
            if path.is_file():
                archive.write(path, path.name)
            elif path.is_dir():
                for item in path.rglob("*"):
                    if item.is_file():
                        archive.write(item, item.relative_to(root))


def restore(root: Path, backup: Path) -> None:
    for path in list(root.iterdir()):
        if runtime_preserve(path.name):
            continue
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        else:
            path.unlink(missing_ok=True)
    with zipfile.ZipFile(backup) as archive:
        archive.extractall(root)


def copy_release(source: Path, root: Path) -> None:
    for path in source.iterdir():
        if runtime_preserve(path.name):
            continue
        destination = root / path.name
        if path.is_dir():
            if destination.exists() and destination.is_dir():
                shutil.rmtree(destination)
            shutil.copytree(path, destination)
        else:
            shutil.copy2(path, destination)


def run_command(command, cwd: Path, log: UpdateLog) -> bool:
    log.write("RUN " + " ".join(str(part) for part in command))
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    for text in (result.stdout, result.stderr):
        if text:
            for line in text.rstrip().splitlines():
                log.write("  " + line)
    log.write(f"EXIT {result.returncode}")
    return result.returncode == 0


def restart_bot(root: Path, package: dict, log: UpdateLog) -> None:
    start_script = str(package.get("start_script") or "").strip()
    if not start_script or not (root / start_script).is_file():
        log.write("Restart script is unavailable; start Andy's Bot from the desktop shortcut")
        return
    if os.name != "nt":
        log.write("Restart skipped outside Windows test environment")
        return
    subprocess.Popen(
        ["cmd", "/c", start_script],
        cwd=root,
        creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0),
    )
    log.write("Restart command launched")


def apply_update(root: Path, zip_path: Path, pid: int) -> int:
    log = UpdateLog(root)
    backup = None
    old_package = _json(root / "UPDATE_PACKAGE.json", {})
    old_settings_text = (root / "settings.json").read_text(encoding="utf-8") if (root / "settings.json").exists() else "{}"
    try:
        meta, package, archive_root = preflight(root, zip_path)
        log.write(f"PREFLIGHT PASS {old_package.get('version', 'unknown')} -> {package.get('version')}")
        _save_json(root / ".updates" / "update_worker_ready.json", {
            "pid": os.getpid(), "target": package.get("version"), "ts": time.time()
        })
        wait_pid(pid)
        log.write("Running bot has stopped; creating program backup")
        stamp = time.strftime("%Y%m%d_%H%M%S")
        backup = root / ".updates" / "backups" / f"program_{old_package.get('version', 'unknown')}_{stamp}.zip"
        code_backup(root, backup)
        log.write(f"Program backup created: {backup.name}")
        with tempfile.TemporaryDirectory(prefix="andys_bot_apply_") as temp_dir:
            with zipfile.ZipFile(zip_path) as archive:
                archive.extractall(temp_dir)
            source = Path(temp_dir) / archive_root if archive_root not in ("", ".") else Path(temp_dir)
            new_defaults = _json(source / "settings.json", {})
            copy_release(source, root)
            if isinstance(new_defaults, dict) and new_defaults:
                old_settings = _json(Path(temp_dir) / "old_settings.json", {})
                try:
                    old_settings = json.loads(old_settings_text)
                except Exception:
                    old_settings = {}
                merged = dict(new_defaults)
                for key, value in old_settings.items():
                    if key not in ("version_label", "live_trading_enabled", "engine_auto_update_enabled"):
                        merged[key] = value
                merged["version_label"] = new_defaults.get("version_label", package.get("version"))
                merged["live_trading_enabled"] = False
                merged["engine_auto_update_enabled"] = False
                _save_json(root / "settings.json", merged)
        migration = str(package.get("migration_script") or "").strip()
        if migration and not run_command([sys.executable, migration, "--in-place-update"], root, log):
            raise RuntimeError("Migration failed")
        if not run_command([sys.executable, "run_isolated_tests.py", "--all"], root, log):
            raise RuntimeError("Isolated regression tests failed")
        result = {
            "ok": True,
            "from": old_package.get("version"),
            "to": package.get("version"),
            "ts": time.time(),
            "backup": str(backup),
            "message": "Update installed, safety checks passed and restart was requested.",
        }
        _save_json(root / ".updates" / "last_successful_update.json", result)
        (root / ".updates" / "last_failed_update.json").unlink(missing_ok=True)
        (root / ".updates" / "staged_update.zip").unlink(missing_ok=True)
        (root / ".updates" / "staged_update.json").unlink(missing_ok=True)
        log.write(f"UPDATE PASS {package.get('version')}")
        restart_bot(root, package, log)
        return 0
    except Exception as exc:
        log.write("UPDATE FAILED: " + str(exc))
        for line in traceback.format_exc().rstrip().splitlines():
            log.write("  " + line)
        if backup and backup.is_file():
            log.write("Restoring backed-up program files")
            restore(root, backup)
            try:
                (root / "settings.json").write_text(old_settings_text, encoding="utf-8")
            except Exception as settings_exc:
                log.write("Settings restore warning: " + str(settings_exc))
            log.write("Rollback complete")
        failure = {
            "ok": False,
            "ts": time.time(),
            "error": str(exc),
            "rolled_back": bool(backup and backup.is_file()),
            "message": "Update failed. Program files were rolled back; live Coinbase data was not changed.",
        }
        _save_json(root / ".updates" / "last_failed_update.json", failure)
        # The old server exits shortly after launching us. Give it time to stop and
        # restore the previous bot even when failure happened during early preflight.
        try:
            wait_pid(pid, seconds=12.0)
        except Exception:
            pass
        restart_bot(root, old_package, log)
        return 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--zip", required=True)
    parser.add_argument("--pid", type=int, default=0)
    parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    zip_path = Path(args.zip).resolve()
    if args.preflight:
        log = UpdateLog(root)
        try:
            _, package, _ = preflight(root, zip_path)
            log.write(f"PREFLIGHT ONLY PASS {package.get('version')}")
            return 0
        except Exception as exc:
            log.write("PREFLIGHT ONLY FAILED: " + str(exc))
            return 2
    return apply_update(root, zip_path, args.pid)


if __name__ == "__main__":
    raise SystemExit(main())
