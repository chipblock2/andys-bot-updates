#!/usr/bin/env python3
import json
import tempfile
import zipfile
from pathlib import Path

import apply_staged_update as updater
import update_manager

ROOT = Path(__file__).resolve().parent


def make_release(path: Path) -> dict:
    package = {
        "package_type": "andys-bot-update-package",
        "contract_version": 2,
        "version": "9.9.9",
        "kind": "full",
        "required_files": [
            "server.py", "update_manager.py", "apply_staged_update.py",
            "run_isolated_tests.py", "test_release.py",
        ],
        "tests": ["test_release.py"],
        "start_script": "00_START_HERE_V5_13_2.bat",
    }
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("release/UPDATE_PACKAGE.json", json.dumps(package))
        for name in package["required_files"]:
            archive.writestr("release/" + name, "# verified test file\n")
    return package


def test_verified_preflight_and_tamper_block():
    with tempfile.TemporaryDirectory() as temp_dir:
        root = Path(temp_dir) / "bot"
        root.mkdir()
        (root / "server.py").write_text("# running bot\n", encoding="utf-8")
        (root / "00_START_HERE_V5_13_2.bat").write_text("@echo off\n", encoding="utf-8")
        updates = root / ".updates"
        updates.mkdir()
        release_zip = updates / "staged_update.zip"
        package = make_release(release_zip)
        metadata = {
            "sha256": update_manager._sha256(release_zip),
            "package": package,
        }
        (updates / "staged_update.json").write_text(json.dumps(metadata), encoding="utf-8")
        _, checked, archive_root = updater.preflight(root, release_zip)
        assert checked["version"] == "9.9.9" and archive_root == "release"
        metadata["sha256"] = "0" * 64
        (updates / "staged_update.json").write_text(json.dumps(metadata), encoding="utf-8")
        try:
            updater.preflight(root, release_zip)
        except RuntimeError as exc:
            assert "SHA-256" in str(exc)
        else:
            raise AssertionError("tampered release was not blocked")


def test_backup_rollback_preserves_runtime_evidence():
    with tempfile.TemporaryDirectory() as temp_dir:
        base = Path(temp_dir)
        root = base / "bot"
        source = base / "release"
        root.mkdir()
        source.mkdir()
        (root / "old_code.py").write_text("old", encoding="utf-8")
        (root / "review_journal.db").write_bytes(b"live evidence")
        (root / "market_recordings").mkdir()
        (root / "market_recordings" / "keep.gz").write_bytes(b"prices")
        (source / "new_code.py").write_text("new", encoding="utf-8")
        backup = base / "backup.zip"
        updater.code_backup(root, backup)
        updater.copy_release(source, root)
        assert (root / "new_code.py").read_text(encoding="utf-8") == "new"
        updater.restore(root, backup)
        assert (root / "old_code.py").read_text(encoding="utf-8") == "old"
        assert (root / "review_journal.db").read_bytes() == b"live evidence"
        assert (root / "market_recordings" / "keep.gz").read_bytes() == b"prices"


def test_release_and_server_install_contract():
    package = json.loads((ROOT / "UPDATE_PACKAGE.json").read_text(encoding="utf-8"))
    server = (ROOT / "server.py").read_text(encoding="utf-8")
    manager = (ROOT / "update_manager.py").read_text(encoding="utf-8")
    assert package["version"] == "5.13.5"
    assert "apply_staged_update.py" in package["required_files"]
    assert "test_r5_5_1_updater_reliability.py" in package["tests"]
    assert "test_r5_6_authoritative_trade_ledger.py" in package["tests"]
    assert "--preflight" in server
    assert "Updater worker is missing" in server
    assert "CREATE_NO_WINDOW" in server
    assert "installer_worker_ready" in manager and "last_apply" in manager
    assert updater.runtime_preserve("review_journal.db")
    assert updater.runtime_preserve("andys_bot_live_ledger.db")
    assert updater.runtime_preserve("market_recordings")
    assert not updater.runtime_preserve("server.py")


if __name__ == "__main__":
    tests = sorted((name, fn) for name, fn in globals().items() if name.startswith("test_") and callable(fn))
    for name, function in tests:
        function()
        print("PASS", name)
    print(f"RESULT {len(tests)}/{len(tests)} passed")
