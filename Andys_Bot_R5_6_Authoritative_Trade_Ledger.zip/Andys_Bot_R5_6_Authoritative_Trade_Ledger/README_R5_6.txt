ANDY'S BOT — AUTHORITATIVE TRADE LEDGER R5.6
================================================

Install through the existing LIVE UPDATE panel.

What changes
------------
- Every PC-approved live order receives a durable SQLite intent before Coinbase is called.
- Coinbase client_order_id is retained for safe, idempotent restart/timeout recovery.
- Explicit Coinbase rejection closes the intent with no fill.
- An interrupted or uncertain response enters LIVE LEDGER RECONCILING.
- While reconciling, no new live preview/approval can proceed and no duplicate is retried.
- Exact Coinbase order snapshots and fills are appended without credentials.
- Existing ETH/LINK positions and Coinbase bracket orders are imported into the ledger without modification.

What does not change
--------------------
- £100 bankroll scope
- £10 maximum approved order
- £20 simultaneous live exposure
- 8 maximum live positions
- 4 new live entries per UTC day
- £2 daily and £10 lifetime realised-loss breakers
- PC-local Preview -> Approve for every live entry
- Transfer permission remains forbidden
- Existing credentials, positions, orders, order history, journals and evidence

Full releases still require your Install confirmation. The updater backs up program files,
runs the migration and eight isolated release suites, rolls back automatically on failure,
and restarts disarmed so you deliberately re-enable supervised live after checking the dashboard.
