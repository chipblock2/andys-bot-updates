#!/usr/bin/env python3
from pathlib import Path
import json, tempfile
import update_manager
ROOT=Path(__file__).resolve().parent

def ok(name,v):
    if not v: raise AssertionError('FAIL '+name)
    print('PASS',name)

h=(ROOT/'dashboard.html').read_text(encoding='utf-8')
s=(ROOT/'server.py').read_text(encoding='utf-8')
ok('dashboard has link channel button','id="linkUpdateBtn"' in h)
ok('dashboard contains canonical github manifest','raw.githubusercontent.com/chipblock2/andys-bot-updates/main/manifest.json' in h)
ok('dashboard posts channel config','/api/configure-update-channel' in h)
ok('server exposes PC-local channel endpoint','/api/configure-update-channel' in s and 'Update channel can only be linked from the PC' in s)
with tempfile.TemporaryDirectory() as td:
    fp=Path(td)/'settings.json';fp.write_text(json.dumps({'live_trading_enabled':True,'execution_mode':'live_supervised'}))
    cfg={'update_allowed_hosts':['raw.githubusercontent.com'],'live_trading_enabled':True,'execution_mode':'live_supervised'}
    u='https://raw.githubusercontent.com/chipblock2/andys-bot-updates/main/manifest.json'
    update_manager.configure_channel(u,cfg,fp)
    d=json.loads(fp.read_text())
    ok('configure persists manifest',d.get('update_manifest_url')==u)
    ok('configure enables checks',d.get('update_checks_enabled') is True)
    ok('configure preserves live mode',d.get('live_trading_enabled') is True and d.get('execution_mode')=='live_supervised')
    try:
        update_manager.configure_channel('http://example.com/manifest.json',cfg,fp)
        raise AssertionError('HTTP accepted')
    except ValueError: pass
    print('PASS HTTP channel rejected')
    try:
        update_manager.configure_channel('https://evil.example/manifest.json',cfg,fp)
        raise AssertionError('unapproved host accepted')
    except ValueError: pass
    print('PASS unapproved host rejected')
print('RESULT 9/9 passed')
