#!/usr/bin/env python3
import json, tempfile, zipfile
from pathlib import Path
import allocation_engine, coinbase_live_canary, coinbase_order_monitor, evidence_quality, update_manager

ROOT=Path(__file__).resolve().parent

def test_dashboard():
    text=(ROOT/"dashboard.html").read_text(encoding="utf-8")
    for token in ("approvalAlert","Price per ${esc(r.symbol)}","Stop plan","Target plan","Live Order Watch R5.5"):
        assert token in text,token

def test_coinbase_prices():
    order={"order_configuration":{"trigger_bracket_gtc":{"stop_trigger_price":"1732.25","limit_price":"1903.61"}}}
    assert coinbase_live_canary.LiveCanaryService._order_prices(order)==(1732.25,1903.61)

def test_slot_reserve():
    row={"probability":.8,"expected_return":.05,"required_edge":.01,"coinbase_price":100,"trade_plan":{"stop_price":97},"market_quality":{"score":90},"decision_council":{"score":90},"market_opportunity":{"activity_score":90}}
    got=allocation_engine.plan("ADA",row,{"positions":{}},{"live_max_positions":8,"live_dynamic_min_order_gbp":2},hard_bankroll=100,hard_order_cap=10,hard_exposure_cap=20)
    assert 2 <= got["quote_size_gbp"] <= 2.5,got

def test_monitor_sanitises():
    rows=coinbase_order_monitor.parse_user_message({"events":[{"orders":[{"order_id":"1","status":"FILLED","filled_value":"9","api_key":"secret"}]}]})
    assert rows[0]["status"]=="FILLED" and "api_key" not in rows[0] and "filled_value" not in rows[0]

def test_update_contract():
    with tempfile.TemporaryDirectory() as td:
        bad=Path(td)/"bad.zip"
        with zipfile.ZipFile(bad,"w") as z:z.writestr("x/UPDATE_PACKAGE.json",json.dumps({"package_type":"andys-bot-update-package","kind":"full","version":"9"}))
        try:update_manager._find_package_manifest(bad)
        except ValueError as e:assert "contract v2" in str(e)
        else:raise AssertionError("bad full update accepted")

def test_evidence_gate():
    snap=evidence_quality.snapshot()
    assert snap["read_only"] and isinstance(snap["market_maker_live_locked"],bool)

if __name__=="__main__":
    for name,value in sorted(globals().items()):
        if name.startswith("test_") and callable(value):value();print("PASS",name)
