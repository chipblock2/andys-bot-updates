@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "TARGET=%~dp0START_ANDYS_BOT_DESKTOP.bat"
set "ICON=%~dp0andys_bot.ico"

if not exist "%TARGET%" (
  echo ERROR: START_ANDYS_BOT_DESKTOP.bat is missing.
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws=New-Object -ComObject WScript.Shell;" ^
  "$desktop=$ws.SpecialFolders.Item('Desktop');" ^
  "$lnk=Join-Path $desktop 'Andys Bot.lnk';" ^
  "$s=$ws.CreateShortcut($lnk);" ^
  "$s.TargetPath='%TARGET%';" ^
  "$s.WorkingDirectory='%~dp0';" ^
  "$s.WindowStyle=7;" ^
  "$s.Description='Start Andy''s Bot and open the local dashboard';" ^
  "if(Test-Path '%ICON%'){$s.IconLocation='%ICON%,0'};" ^
  "$s.Save(); Write-Host ('Desktop shortcut created: '+$lnk)"
if errorlevel 1 (
  echo.
  echo Could not create the desktop shortcut automatically.
  echo You can still double-click START_ANDYS_BOT_DESKTOP.bat in the bot folder.
  exit /b 1
)
exit /b 0
