@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "%~dp0CONFIGURE_UPDATE_CHANNEL.bat" (
  echo ERROR: CONFIGURE_UPDATE_CHANNEL.bat was not found in the main bot folder.
  pause
  exit /b 1
)
call "%~dp0CONFIGURE_UPDATE_CHANNEL.bat"
exit /b %ERRORLEVEL%
