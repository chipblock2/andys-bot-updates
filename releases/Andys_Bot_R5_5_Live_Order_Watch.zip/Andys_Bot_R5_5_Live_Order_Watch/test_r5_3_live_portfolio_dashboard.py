from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent
html=(ROOT/'dashboard.html').read_text(encoding='utf-8')
build=json.loads((ROOT/'BUILD_INFO.json').read_text(encoding='utf-8'))

def ck(name, cond, detail=''):
    if not cond:
        raise AssertionError(f'FAIL {name}: {detail}')
    print('PASS',name)

ck('build retains R5.3 portfolio or newer', build.get('patch') in {'R5.3','R5.4','R5.5'})
ck('home live portfolio card exists', 'id="livePortfolioCard"' in html)
ck('live slots KPI exists', 'id="liveSlots"' in html)
ck('live exposure KPI exists', 'id="liveExposure"' in html)
ck('live unrealised KPI exists', 'id="liveUnrealised"' in html)
ck('live realised KPI exists', 'id="liveDayRealised"' in html)
ck('live exposure room KPI exists', 'id="liveExposureRoom"' in html)
ck('live trade cards container exists', 'id="livePortfolioGrid"' in html)
ck('real Coinbase ledger exists', 'id="livePositionLedgerBody"' in html)
ck('live renderer exists', 'function renderLivePortfolio(d)' in html)
ck('live renderer runs every poll', 'renderLive(d);renderLivePortfolio(d);renderOrderWatch(d);renderHealth(d)' in html)
ck('uses Coinbase model live price', 'a.coinbase_price' in html)
ck('shows stop distance', 'toStop' in html and 'To stop' in html)
ck('shows target distance', 'toTarget' in html and 'To target' in html)
ck('explains unrealised estimate', 'before the eventual exit fee' in html)
ck('eight slot UI retained', 'up to eight positions' in html.lower())
ck('GBP20 exposure protection retained', '£20 total exposure' in html)
ck('GBP10 order protection retained', '£10/order' in html)
ck('manual approval retained', 'real order submission is never automatic' in html.lower())
ck('preview and approve controls retained', 'id="livePreviewBtn"' in html and 'id="liveApproveBtn"' in html)
ck('desktop launcher feature retained in build info', any('desktop one-click launcher' in x for x in build.get('features',[])))
print('RESULT 21/21 passed')
