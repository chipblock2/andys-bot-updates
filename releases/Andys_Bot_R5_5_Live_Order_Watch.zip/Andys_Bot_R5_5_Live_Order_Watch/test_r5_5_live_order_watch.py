#!/usr/bin/env python3
import json
import tempfile
import time
from pathlib import Path

import coinbase_order_monitor

ROOT = Path(__file__).resolve().parent


def test_raw_user_event_is_sanitised():
    raw = json.dumps({
        "channel": "user",
        "sequence_num": 9,
        "events": [{"orders": [{
            "order_id": "order-1",
            "product_id": "ETH-GBP",
            "status": "FILLED",
            "completion_percentage": "100",
            "filled_value": "9.00",
            "total_fees": "0.10",
            "api_key": "never-keep",
            "retail_portfolio_id": "never-keep",
        }]}],
    })
    rows = coinbase_order_monitor.parse_user_message(raw, seen_ts=123.0)
    assert rows == [{
        "order_id": "order-1",
        "product_id": "ETH-GBP",
        "status": "FILLED",
        "completion_percentage": "100",
        "seen_ts": 123.0,
    }]


def test_heartbeat_and_sequence_health():
    clock = [100.0]
    monitor = coinbase_order_monitor.OrderEventMonitor(clock=lambda: clock[0])
    monitor._configured = True
    monitor._connected = True
    monitor._subscribed = True
    monitor.ingest({"channel": "heartbeats", "sequence_num": 1, "events": [{"heartbeat_counter": 10}]})
    clock[0] = 102.0
    status = monitor.status()
    assert status["ok"] and status["state"] == "USER CHANNEL LIVE"
    assert status["heartbeat_age_seconds"] == 2.0
    monitor.ingest({"channel": "heartbeats", "sequence_num": 4, "events": [{"heartbeat_counter": 13}]})
    assert monitor.status()["missed_messages"] == 4
    clock[0] = 120.0
    assert not monitor.status()["ok"]


def test_sdk_connection_uses_all_products_and_heartbeats():
    clients = []

    class FakeClient:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.user_products = None
            self.heartbeat_called = False
            self.closed = False
            clients.append(self)

        def open(self):
            self.kwargs["on_open"]()

        def user(self, product_ids):
            self.user_products = product_ids

        def heartbeats(self):
            self.heartbeat_called = True
            self.kwargs["on_message"](json.dumps({
                "channel": "heartbeats",
                "sequence_num": 1,
                "events": [{"heartbeat_counter": 1}],
            }))

        def raise_background_exception(self):
            return None

        def close(self):
            self.closed = True
            self.kwargs["on_close"]()

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        key_file = root / "coinbase_key.json"
        key_file.write_text("{}", encoding="utf-8")
        config = root / "coinbase_live_config.json"
        config.write_text(json.dumps({"enabled": True, "key_file": str(key_file)}), encoding="utf-8")
        monitor = coinbase_order_monitor.OrderEventMonitor(config_file=config, client_factory=FakeClient)
        monitor.start()
        deadline = time.time() + 2.0
        while time.time() < deadline and not (clients and monitor.status()["ok"]):
            time.sleep(0.01)
        status = monitor.status()
        monitor.stop()
    assert clients and clients[0].user_products == []
    assert clients[0].heartbeat_called and clients[0].closed
    assert status["ok"] and status["rest_authoritative"]
    assert not status["submits_orders"] and not status["edits_orders"] and not status["cancels_orders"]
    assert not status["stores_credentials"]


def test_dashboard_and_server_wiring():
    html = (ROOT / "dashboard.html").read_text(encoding="utf-8")
    server = (ROOT / "server.py").read_text(encoding="utf-8")
    assert "ORDER WATCH LIVE" in html and "REST FALLBACK" in html
    assert "renderOrderWatch(d)" in html and "liveOrderWatchDetail" in html
    assert 'VERSION = "5.13.4-supervised-live"' in server
    assert "coinbase_order_monitor.SERVICE.start()" in server
    assert 'data["coinbase_order_events"] = coinbase_order_monitor.SERVICE.status()' in server


if __name__ == "__main__":
    tests = sorted((name, fn) for name, fn in globals().items() if name.startswith("test_") and callable(fn))
    for name, fn in tests:
        fn()
        print("PASS", name)
    print(f"RESULT {len(tests)}/{len(tests)} passed")
