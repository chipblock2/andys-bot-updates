#!/usr/bin/env python3
"""Fail-closed configuration invariants for Andy's Bot v5.13.

Only safety-critical and research-integrity settings are validated. Unknown keys
remain allowed so older installations can migrate without losing local preferences.
The guard never reads credentials and never enables live trading.
"""
from __future__ import annotations

import math
from typing import Any


class ConfigurationError(RuntimeError):
    pass


def _number(cfg: dict, key: str, errors: list[str], *, minimum: float | None = None,
            maximum: float | None = None, inclusive_min: bool = True) -> float | None:
    value = cfg.get(key)
    try:
        number = float(value)
    except Exception:
        errors.append(f"{key} must be numeric")
        return None
    if not math.isfinite(number):
        errors.append(f"{key} must be finite")
        return None
    if minimum is not None and (number < minimum if inclusive_min else number <= minimum):
        op = ">=" if inclusive_min else ">"
        errors.append(f"{key} must be {op} {minimum}")
    if maximum is not None and number > maximum:
        errors.append(f"{key} must be <= {maximum}")
    return number


def validate_config(cfg: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []

    if str(cfg.get("primary_exchange", "")).strip().lower() != "coinbase":
        errors.append("primary_exchange must remain Coinbase")
    if cfg.get("coinbase_only_execution") is not True:
        errors.append("coinbase_only_execution must be true")
    live = cfg.get("live_trading_enabled") is True
    mode = str(cfg.get("execution_mode", "")).lower()
    if live and mode != "live_supervised":
        errors.append("live trading requires execution_mode=live_supervised")
    if not live and mode not in {"paper", "shadow"}:
        errors.append("disarmed execution_mode must be paper or shadow")
    if live:
        _number(cfg, "live_bankroll_cap_gbp", errors, minimum=10.0, maximum=100.0)
        _number(cfg, "live_order_cap_gbp", errors, minimum=5.0, maximum=10.0)
        _number(cfg, "live_max_total_exposure_gbp", errors, minimum=5.0, maximum=20.0)
        _number(cfg, "live_daily_loss_limit_gbp", errors, minimum=0.25, maximum=2.0)
        _number(cfg, "live_lifetime_loss_limit_gbp", errors, minimum=1.0, maximum=10.0)
        _number(cfg, "live_min_probability", errors, minimum=0.58, maximum=0.90)
        _number(cfg, "live_min_council_score", errors, minimum=60.0, maximum=90.0)
        _number(cfg, "live_min_activity_score", errors, minimum=50.0, maximum=90.0)
        _number(cfg, "live_min_edge_after_preview", errors, minimum=0.003, maximum=0.03)
        _number(cfg, "live_approval_max_price_drift_pct", errors, minimum=0.001, maximum=0.01)
        _number(cfg, "live_dynamic_min_order_gbp", errors, minimum=1.0, maximum=10.0)
        min_alloc=_number(cfg, "live_dynamic_min_allocation_pct", errors, minimum=0.01, maximum=0.10)
        max_alloc=_number(cfg, "live_dynamic_max_allocation_pct", errors, minimum=0.03, maximum=0.15)
        min_risk=_number(cfg, "live_dynamic_min_risk_pct", errors, minimum=0.001, maximum=0.01)
        max_risk=_number(cfg, "live_dynamic_max_risk_pct", errors, minimum=0.002, maximum=0.015)
        _number(cfg, "live_same_bucket_multiplier", errors, minimum=0.25, maximum=1.0)
        _number(cfg, "live_slot_reserve_gbp", errors, minimum=1.0, maximum=5.0)
        try:
            if not 1 <= int(cfg.get("live_max_same_bucket_positions", 2)) <= 2: errors.append("live_max_same_bucket_positions must be 1 or 2")
        except Exception:
            errors.append("live_max_same_bucket_positions must be an integer")
        if min_alloc is not None and max_alloc is not None and min_alloc>max_alloc: errors.append("live_dynamic_min_allocation_pct must not exceed max")
        if min_risk is not None and max_risk is not None and min_risk>max_risk: errors.append("live_dynamic_min_risk_pct must not exceed max")
        try:
            if not 1 <= int(cfg.get("live_max_positions")) <= 8: errors.append("live_max_positions must be between 1 and 8")
            if not 1 <= int(cfg.get("live_max_orders_per_day")) <= 4: errors.append("live_max_orders_per_day must be between 1 and 4")
        except Exception:
            errors.append("live position/order limits must be integers")

    start = _number(cfg, "starting_cash_gbp", errors, minimum=0.0, inclusive_min=False)
    position = _number(cfg, "paper_max_position_pct", errors, minimum=0.0, maximum=0.25,
                       inclusive_min=False)
    reserve = _number(cfg, "paper_cash_reserve_pct", errors, minimum=0.10, maximum=0.95)
    exposure = _number(cfg, "paper_max_portfolio_exposure_pct", errors, minimum=0.0,
                       maximum=0.80, inclusive_min=False)
    _number(cfg, "paper_daily_loss_limit_pct", errors, minimum=0.0, maximum=0.10,
            inclusive_min=False)
    _number(cfg, "paper_equity_floor_pct", errors, minimum=0.50, maximum=1.0)
    _number(cfg, "max_risk_per_trade_pct", errors, minimum=0.0, maximum=0.01,
            inclusive_min=False)
    _number(cfg, "paper_slippage_per_side", errors, minimum=0.0, maximum=0.05)
    _number(cfg, "minimum_edge_buffer", errors, minimum=0.0, maximum=0.05)
    _number(cfg, "paper_probe_stake_pct", errors, minimum=0.0, maximum=0.05, inclusive_min=False)
    probe_max_stake = _number(cfg, "paper_probe_max_stake_gbp", errors, minimum=0.0, maximum=5.0, inclusive_min=False)
    probe_total_gbp = _number(cfg, "paper_probe_max_total_exposure_gbp", errors, minimum=5.0, maximum=20.0)
    probe_total_pct = _number(cfg, "paper_probe_max_total_exposure_pct", errors, minimum=0.05, maximum=0.20)
    _number(cfg, "paper_probe_min_expected_return", errors, minimum=0.003, maximum=0.03)
    _number(cfg, "paper_probe_min_probability", errors, minimum=0.58, maximum=0.85)
    _number(cfg, "paper_probe_min_score", errors, minimum=0.0, maximum=0.60)
    _number(cfg, "paper_probe_min_council_score", errors, minimum=45.0, maximum=75.0)
    _number(cfg, "paper_probe_min_activity_score", errors, minimum=30.0, maximum=80.0)
    _number(cfg, "paper_probe_cooldown_seconds", errors, minimum=900.0, maximum=86400.0)
    _number(cfg, "paper_probe_max_hold_hours", errors, minimum=1.0, maximum=24.0)
    _number(cfg, "paper_probe_max_hold_cap_hours", errors, minimum=24.0, maximum=72.0)
    _number(cfg, "paper_probe_hold_horizon_multiplier", errors, minimum=1.0, maximum=2.0)
    _number(cfg, "coinbase_maker_fee", errors, minimum=0.0, maximum=0.05)
    _number(cfg, "coinbase_taker_fee", errors, minimum=0.0, maximum=0.05)
    _number(cfg, "max_book_age_seconds", errors, minimum=0.0, maximum=120.0,
            inclusive_min=False)
    _number(cfg, "btc_compression_score_threshold", errors, minimum=40.0, maximum=95.0)
    _number(cfg, "btc_breakout_buffer_atr", errors, minimum=0.0, maximum=1.0)
    _number(cfg, "btc_breakout_volume_ratio", errors, minimum=1.0, maximum=10.0)
    breadth_support = _number(cfg, "altcoin_breadth_supportive_score", errors, minimum=40.0, maximum=90.0)
    breadth_weak = _number(cfg, "altcoin_breadth_weak_score", errors, minimum=5.0, maximum=60.0)
    _number(cfg, "btc_leadership_council_weight", errors, minimum=0.0, maximum=10.0)

    for key, minimum, maximum in (
        ("btc_compression_window_hours", 12, 168),
        ("btc_compression_lookback_hours", 96, 8760),
        ("btc_breakout_window_hours", 12, 168),
        ("altcoin_breadth_min_assets", 2, 25),
    ):
        try:
            value = int(cfg.get(key))
            if not minimum <= value <= maximum:
                errors.append(f"{key} must be between {minimum} and {maximum}")
        except Exception:
            errors.append(f"{key} must be an integer")
    if breadth_support is not None and breadth_weak is not None and breadth_weak >= breadth_support:
        errors.append("altcoin_breadth_weak_score must be below altcoin_breadth_supportive_score")

    try:
        max_positions = int(cfg.get("max_total_open_positions"))
        if not 1 <= max_positions <= 10:
            errors.append("max_total_open_positions must be between 1 and 10")
    except Exception:
        errors.append("max_total_open_positions must be an integer")
    try:
        probe_positions = int(cfg.get("paper_probe_max_positions"))
        if not 1 <= probe_positions <= 4:
            errors.append("paper_probe_max_positions must be between 1 and 4")
    except Exception:
        errors.append("paper_probe_max_positions must be an integer")
        probe_positions = None
    if probe_positions is not None and probe_max_stake is not None and probe_total_gbp is not None:
        if probe_positions * probe_max_stake > probe_total_gbp + 1e-9:
            errors.append("paper probe position caps exceed paper_probe_max_total_exposure_gbp")
    if probe_positions is not None:
        try:
            if probe_positions > int(cfg.get("max_total_open_positions")):
                errors.append("paper_probe_max_positions cannot exceed max_total_open_positions")
        except Exception:
            pass
    if probe_total_pct is not None and exposure is not None and probe_total_pct > exposure:
        errors.append("paper_probe_max_total_exposure_pct cannot exceed paper_max_portfolio_exposure_pct")

    horizons = cfg.get("multi_horizon_hours")
    if not isinstance(horizons, list) or not horizons:
        errors.append("multi_horizon_hours must be a non-empty list")
    else:
        clean: list[int] = []
        for item in horizons:
            try:
                value = int(item)
            except Exception:
                errors.append("multi_horizon_hours must contain integers")
                continue
            if not 1 <= value <= 72:
                errors.append("multi_horizon_hours values must be between 1 and 72")
            clean.append(value)
        if len(clean) != len(set(clean)):
            errors.append("multi_horizon_hours must not contain duplicates")

    if exposure is not None and reserve is not None and exposure > 1.0 - reserve + 1e-12:
        errors.append("portfolio exposure must leave the configured cash reserve untouched")
    if position is not None and exposure is not None and position > exposure:
        errors.append("single-position cap cannot exceed the portfolio exposure cap")
    if start is not None and start < float(cfg.get("minimum_trade_gbp", 5.0)):
        warnings.append("starting_cash_gbp is below minimum_trade_gbp; no paper entry can occur")

    if cfg.get("phone_access_enabled"):
        if cfg.get("phone_access_private_lan_only") is not True:
            errors.append("phone access must remain private-LAN only")
        if cfg.get("phone_access_require_token") is not True:
            errors.append("phone access must require a token")

    return {
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "policy": "Coinbase-only £100 supervised live; every order requires PC-local manual approval" if live else "Coinbase-only PAPER/SHADOW; live order submission locked",
    }


def enforce_config(cfg: dict[str, Any]) -> dict[str, Any]:
    report = validate_config(cfg)
    if not report["ok"]:
        raise ConfigurationError("Unsafe or invalid settings: " + "; ".join(report["errors"]))
    return cfg
