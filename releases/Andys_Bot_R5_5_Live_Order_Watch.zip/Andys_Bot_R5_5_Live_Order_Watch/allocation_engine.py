#!/usr/bin/env python3
"""Risk-adjusted live allocation planner for Andy's Bot R4.

This module never submits orders.  It converts an already-qualified supervised-live
candidate into a bounded GBP size.  The aim is not to predict the maximum-profit bet;
it is to allocate more of the £100 test bankroll to cleaner, higher-edge setups while
keeping stop-loss risk, liquidity quality and concentration inside hard limits.
"""
from __future__ import annotations

import math
from typing import Any


def _f(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        return x if math.isfinite(x) else float(default)
    except Exception:
        return float(default)


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))




MEME_ASSETS = {"DOGE","SHIB","PEPE","BONK","WIF","FLOKI","TURBO","MOG","PENGU","POPCAT","PNUT","BRETT","MEME","TRUMP","DEGEN","TOSHI","COQ","SPX","GIGA","FARTCOIN","PONKE","PUMP"}
BUCKETS = {
    "BTC":"MAJOR", "ETH":"MAJOR",
    "SOL":"L1", "ADA":"L1", "DOT":"L1", "ATOM":"L1", "ALGO":"L1", "AVAX":"L1", "NEAR":"L1", "ICP":"L1",
    "LINK":"DEFI", "UNI":"DEFI", "AAVE":"DEFI", "CRV":"DEFI",
    "BCH":"PAYMENTS", "LTC":"PAYMENTS", "ETC":"PAYMENTS",
    "FIL":"STORAGE",
}

def asset_bucket(symbol: str, row: dict | None = None) -> str:
    sym=str(symbol or '').upper()
    if bool(((row or {}).get("meme_intelligence") or {}).get("is_meme")) or sym in MEME_ASSETS:
        return "MEME"
    return BUCKETS.get(sym, "ALT")


def quality_score(row: dict, settings: dict | None = None) -> dict:
    settings = settings or {}
    prob = _f(row.get("calibrated_probability", row.get("ensemble_probability", row.get("probability", 0.5))), 0.5)
    expected = max(0.0, _f(row.get("expected_return")))
    required = max(0.001, _f(row.get("required_edge"), _f(settings.get("live_min_edge_after_preview"), 0.003) + 0.003))
    edge_multiple = expected / required
    council = _f((row.get("decision_council") or {}).get("score"), 50.0)
    activity = _f((row.get("market_opportunity") or {}).get("activity_score"), 50.0)
    market_quality = _f((row.get("market_quality") or {}).get("score"), 50.0)
    flow = row.get("order_flow") or {}
    flow_quality = str(flow.get("quality") or "LOW").upper()
    flow_score = _f(flow.get("score"), 0.0) if flow_quality in {"MEDIUM", "HIGH"} else 0.0

    p_part = _clamp((prob - 0.55) / 0.30)
    edge_part = _clamp((edge_multiple - 1.0) / 2.5)
    council_part = _clamp((council - 50.0) / 50.0)
    activity_part = _clamp((activity - 35.0) / 65.0)
    quality_part = _clamp((market_quality - 35.0) / 65.0)
    flow_part = _clamp((flow_score + 40.0) / 80.0)
    score = (
        0.29 * p_part
        + 0.27 * edge_part
        + 0.14 * council_part
        + 0.10 * activity_part
        + 0.15 * quality_part
        + 0.05 * flow_part
    )

    meme = row.get("meme_intelligence") or {}
    if meme.get("is_meme"):
        # A confirmed safe reclaim can earn normal sizing.  A meme setup that only
        # barely passes is intentionally sized down because its stop can gap/slip.
        if meme.get("safe_reclaim"):
            score *= 0.95
        else:
            score *= 0.80
    if bool((row.get("market_opportunity") or {}).get("chase_risk")):
        score *= 0.75
    score = _clamp(score)
    return {
        "score": score,
        "probability": prob,
        "expected_return": expected,
        "required_edge": required,
        "edge_multiple": edge_multiple,
        "council_score": council,
        "activity_score": activity,
        "market_quality_score": market_quality,
        "order_flow_score": flow_score,
    }


def _stop_pct(row: dict) -> float:
    plan = row.get("trade_plan") or {}
    px = _f(row.get("coinbase_price") or row.get("price"))
    stop = _f(plan.get("stop_price"))
    if px > 0 and stop > 0 and stop < px:
        return _clamp((px - stop) / px, 0.005, 0.15)
    return _clamp(_f(plan.get("stop_pct"), 0.025), 0.005, 0.15)


def plan(symbol: str, row: dict, state: dict, settings: dict, *, hard_bankroll: float, hard_order_cap: float, hard_exposure_cap: float) -> dict:
    q = quality_score(row, settings)
    bankroll = min(max(1.0, _f(settings.get("live_bankroll_cap_gbp"), hard_bankroll)), hard_bankroll)
    order_cap = min(max(1.0, _f(settings.get("live_order_cap_gbp"), hard_order_cap)), hard_order_cap)
    exposure_cap = min(max(1.0, _f(settings.get("live_max_total_exposure_gbp"), hard_exposure_cap)), hard_exposure_cap)
    exposure = sum(max(0.0, _f(x.get("entry_cost_gbp"))) for x in (state.get("positions") or {}).values())
    room = max(0.0, exposure_cap - exposure)
    stop_pct = _stop_pct(row)

    # The allocation band is deliberately narrow on a £100 canary: about £5-£10.
    # Stronger evidence earns more capital, but no model score can exceed the hard cap.
    min_alloc_pct = _clamp(_f(settings.get("live_dynamic_min_allocation_pct"), 0.05), 0.01, 0.10)
    max_alloc_pct = _clamp(_f(settings.get("live_dynamic_max_allocation_pct"), 0.10), min_alloc_pct, 0.15)
    alloc_pct = min_alloc_pct + (max_alloc_pct - min_alloc_pct) * q["score"]
    score_cap = bankroll * alloc_pct

    # At-stop risk budget grows only from 0.25% to 0.50% of the dedicated bankroll.
    min_risk_pct = _clamp(_f(settings.get("live_dynamic_min_risk_pct"), 0.0025), 0.001, 0.01)
    max_risk_pct = _clamp(_f(settings.get("live_dynamic_max_risk_pct"), 0.0050), min_risk_pct, 0.015)
    risk_pct = min_risk_pct + (max_risk_pct - min_risk_pct) * q["score"]
    risk_budget = bankroll * risk_pct
    risk_cap = risk_budget / max(stop_pct, 0.005)

    raw = min(order_cap, room, score_cap, risk_cap)

    # Portfolio diversification: up to eight slots share the same hard £20 exposure cap.
    # A second asset from the same broad risk bucket is sized down; a third is
    # rejected so extra slots cannot silently become multiple versions of one bet.
    positions = state.get("positions") or {}
    bucket = asset_bucket(symbol, row)
    held_buckets = [asset_bucket(held) for held in positions]
    same_bucket_count = sum(1 for b in held_buckets if b == bucket)
    max_same_bucket = max(1, min(2, int(_f(settings.get("live_max_same_bucket_positions"), 2))))
    concentration_multiplier = 1.0
    if same_bucket_count >= max_same_bucket:
        concentration_multiplier = 0.0
        raw = 0.0
    elif same_bucket_count == 1:
        concentration_multiplier = _clamp(_f(settings.get("live_same_bucket_multiplier"), 0.70), 0.25, 1.0)
        raw *= concentration_multiplier

    # Slot-aware reserve. With a £20 portfolio and up to eight slots the engine avoids
    # consuming all exposure on the first two entries.  It reserves a small amount
    # for each still-empty slot, while the £10 hard order cap remains unchanged.
    minimum = max(1.0, _f(settings.get("live_dynamic_min_order_gbp"), 2.0))
    max_positions = max(1, min(8, int(_f(settings.get("live_max_positions"), 8))))
    available_slots = max(1, max_positions - len(positions))
    remaining_slots_after = max(0, available_slots - 1)
    reserve_each = max(minimum, _f(settings.get("live_slot_reserve_gbp"), minimum))
    # Reserve only when the remaining exposure is large enough to keep all empty
    # slots genuinely usable. If an older/large position has already consumed most
    # of the £20 cap, do not strand the last few pounds just to preserve theoretical
    # slots that can no longer all be funded.
    can_preserve_all_slots = room >= reserve_each * (remaining_slots_after + 1) - 1e-9
    reserve_for_future = (reserve_each * remaining_slots_after) if (remaining_slots_after and can_preserve_all_slots) else 0.0
    slot_cap = max(0.0, room - reserve_for_future) if remaining_slots_after else room
    if bool(settings.get("live_slot_aware_sizing_enabled", True)):
        # Equal-share ceiling is the clearest behaviour for a tiny supervised
        # portfolio: an empty £20/eight-slot book starts at no more than £2.50.
        slot_cap = min(slot_cap, room / available_slots)
    raw = min(raw, slot_cap)

    size = round(min(raw, order_cap, room), 2)
    if size + 1e-9 < minimum:
        size = 0.0

    return {
        "quote_size_gbp": size,
        "allocation_score": round(q["score"] * 100.0, 1),
        "allocation_pct_bankroll": (size / bankroll) if bankroll else 0.0,
        "stop_pct": stop_pct,
        "risk_budget_gbp": round(risk_budget, 4),
        "risk_at_stop_gbp": round(size * stop_pct, 4),
        "edge_multiple": round(q["edge_multiple"], 3),
        "remaining_exposure_gbp": round(room, 4),
        "concentration_multiplier": concentration_multiplier,
        "bucket": bucket,
        "same_bucket_count": same_bucket_count,
        "remaining_slots_after": remaining_slots_after,
        "slot_budget_gbp": round(room / available_slots, 4),
        "reserved_for_future_slots_gbp": round(reserve_for_future, 4),
        "slot_cap_gbp": round(slot_cap, 4),
        "components": q,
        "reason": "risk-adjusted size from probability, net edge, liquidity, activity, stop distance, diversification and eight-slot exposure reserve",
    }
