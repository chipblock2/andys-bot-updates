#!/usr/bin/env python3
"""Add R5.4 settings without touching credentials, orders, positions or evidence."""
import json
from pathlib import Path

path=Path(__file__).resolve().parent/"settings.json"
cfg=json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
cfg["live_max_positions"]=8
cfg["live_dynamic_min_order_gbp"]=2.0
cfg["live_slot_aware_sizing_enabled"]=True
cfg.setdefault("live_slot_reserve_gbp",2.0)
path.write_text(json.dumps(cfg,indent=2,sort_keys=True)+"\n",encoding="utf-8")
print("R5.4 settings added. Existing live positions and risk caps were not changed.")
