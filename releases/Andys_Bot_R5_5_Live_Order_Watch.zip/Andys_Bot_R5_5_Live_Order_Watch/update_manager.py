#!/usr/bin/env python3
"""Secure update-channel support for Andy's Bot.

The bot never accepts arbitrary uploaded Python from the LAN.  It only checks an explicit
manifest URL configured on the PC, requires HTTPS for remote channels, validates a SHA-256
for the release ZIP, then verifies the embedded UPDATE_PACKAGE.json before staging it.

Trading/risk/full-engine packages always require an explicit Install action.  UI-only
packages may be auto-applied only if the user explicitly enables that setting.
"""
from __future__ import annotations
import hashlib, json, os, shutil, tempfile, threading, time, urllib.parse, urllib.request, zipfile
from pathlib import Path

BASE=Path(__file__).resolve().parent
UPDATES=BASE/'.updates'; UPDATES.mkdir(exist_ok=True)
STATE_FILE=UPDATES/'update_state.json'; STAGED_ZIP=UPDATES/'staged_update.zip'; STAGED_META=UPDATES/'staged_update.json'
_LOCK=threading.RLock()

# Withdrawn releases are fail-closed even if an older copy is already staged.
# 5.13.2.1 was incomplete and failed its isolated regression/startup checks.
QUARANTINED_VERSIONS={
 '5.13.2.1':'withdrawn after isolated regression and dependency validation failed'
}

PRESERVE_NAMES={
 'settings.json','coinbase_api_config.json','kraken_api_config.json','email_config.json','live_bridge_config.json','phone_access.json','PHONE_ACCESS_URL.txt',
 'coinbase_fee_override.json','autopilot_state.json','fast_paper_state.json','shadow_gate_lab_state.json','market_maker_lab_state.json','okx_oi_history.json',
 'review_journal.db','liquidity_reversal_lab_state.json','market_recordings','replay_exports','andys_bot_v54.db','andys_bot_v55_executors.db','andys_bot_v511_orders.db','paper_trades.csv','fast_paper_trades.csv','shadow_gate_lab_trades.csv',
 'market_maker_lab_trades.csv','decision_log.csv','market_telemetry.csv','scanner_telemetry.csv','watchdog.log','edge_profiles.json'
}

def _load(path,default):
    try:return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:return default

def _save(path,obj):
    tmp=Path(str(path)+'.tmp');tmp.write_text(json.dumps(obj,indent=2,sort_keys=True),encoding='utf-8');os.replace(tmp,path)

def _state():
    d=_load(STATE_FILE,{})
    d.setdefault('last_check_ts',0.0);d.setdefault('last_error',None);d.setdefault('available',None);d.setdefault('staged',None);d.setdefault('history',[])
    return d

def _sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest().lower()

def _safe_remote_url(url,cfg):
    p=urllib.parse.urlparse(str(url or ''))
    if p.scheme!='https':raise ValueError('Remote update channel must use HTTPS')
    allowed=[str(x).lower() for x in (cfg.get('update_allowed_hosts') or []) if str(x).strip()]
    if allowed and (p.hostname or '').lower() not in allowed:raise ValueError(f'Update host {(p.hostname or "unknown")} is not in update_allowed_hosts')
    return url

def _fetch_json(url,cfg):
    url=_safe_remote_url(url,cfg)
    req=urllib.request.Request(url,headers={'User-Agent':'AndysBot-SecureUpdater/1.0','Accept':'application/json','Cache-Control':'no-cache'})
    with urllib.request.urlopen(req,timeout=15) as r:
        _safe_remote_url(r.geturl(),cfg)
        if int(getattr(r,'status',200))!=200:raise RuntimeError(f'HTTP {getattr(r,"status",None)}')
        raw=r.read(256*1024+1)
    if len(raw)>256*1024:raise ValueError('Update manifest too large')
    return json.loads(raw.decode('utf-8'))

def _version_tuple(v):
    import re
    m=re.findall(r'\d+',str(v or ''))[:4]
    return tuple(int(x) for x in m)+(0,)*(4-len(m))

def _quarantine_reason(version):
    return QUARANTINED_VERSIONS.get(str(version or '').strip())

def check(current_version,cfg,force=False):
    with _LOCK:
        st=_state(); now=time.time(); interval=max(300.0,float(cfg.get('update_check_interval_seconds',900.0)))
        if not force and now-float(st.get('last_check_ts') or 0)<interval:return public_status(current_version,cfg)
        st['last_check_ts']=now; st['last_error']=None
        url=str(cfg.get('update_manifest_url') or '').strip()
        if not bool(cfg.get('update_checks_enabled',True)):
            st['available']=None;st['last_error']='Update checks disabled';_save(STATE_FILE,st);return public_status(current_version,cfg)
        if not url:
            st['available']=None;st['last_error']='Update channel not linked yet';_save(STATE_FILE,st);return public_status(current_version,cfg)
        try:
            m=_fetch_json(url,cfg)
            if str(m.get('package_type') or '')!='andys-bot-release-manifest':raise ValueError('Unrecognised update manifest type')
            for k in ('version','zip_url','sha256','kind'):
                if not m.get(k):raise ValueError(f'Manifest missing {k}')
            reason=_quarantine_reason(m.get('version'))
            if reason:
                STAGED_ZIP.unlink(missing_ok=True);STAGED_META.unlink(missing_ok=True)
                st['staged']=None;st['available']=None
                st['last_error']=f"Update {m.get('version')} blocked: {reason}. Waiting for a newer verified release."
                _save(STATE_FILE,st);return public_status(current_version,cfg)
            if str(m.get('kind')).lower() not in ('ui','full'):raise ValueError('kind must be ui or full')
            if len(str(m.get('sha256'))) != 64:raise ValueError('Manifest SHA-256 is invalid')
            _safe_remote_url(m['zip_url'],cfg)
            m['newer']=_version_tuple(m['version'])>_version_tuple(current_version)
            st['available']=m if m['newer'] else None
            if not m['newer']: st['last_error']=None
        except Exception as exc:
            st['available']=None;st['last_error']=str(exc)
        _save(STATE_FILE,st);return public_status(current_version,cfg)

def _find_package_manifest(zip_path):
    with zipfile.ZipFile(zip_path) as z:
        names=z.namelist()
        if any(Path(n).is_absolute() or '..' in Path(n).parts for n in names):raise ValueError('Update ZIP contains an unsafe path')
        hits=[n for n in names if n.endswith('UPDATE_PACKAGE.json')]
        if len(hits)!=1:raise ValueError('Update ZIP must contain exactly one UPDATE_PACKAGE.json')
        data=json.loads(z.read(hits[0]).decode('utf-8')); root=str(Path(hits[0]).parent).replace('\\','/')
        if data.get('package_type')!='andys-bot-update-package':raise ValueError('Invalid embedded package type')
        if str(data.get('kind'))=='full':
            if int(data.get('contract_version') or 0)<2:raise ValueError('Full update requires package contract v2')
            required=data.get('required_files') or [];tests=data.get('tests') or []
            if not required or not tests:raise ValueError('Full update must declare required files and regression tests')
            prefix=(root+'/' if root and root!='.' else '')
            missing=[name for name in required if prefix+str(name).replace('\\','/') not in names]
            if missing:raise ValueError('Update ZIP is incomplete: '+', '.join(missing))
        return data,root

def stage(current_version,cfg):
    with _LOCK:
        st=_state();m=st.get('available') or {}
        if not m:raise RuntimeError('No newer update is currently available')
        reason=_quarantine_reason(m.get('version'))
        if reason:
            clear_stage();raise RuntimeError(f"Update {m.get('version')} is blocked: {reason}")
        url=_safe_remote_url(m.get('zip_url'),cfg)
        tmp=UPDATES/'download.tmp'
        req=urllib.request.Request(url,headers={'User-Agent':'AndysBot-SecureUpdater/1.0','Accept':'application/zip'})
        with urllib.request.urlopen(req,timeout=60) as r, open(tmp,'wb') as f:
            _safe_remote_url(r.geturl(),cfg)
            total=0
            while True:
                b=r.read(1024*1024)
                if not b:break
                total+=len(b)
                if total>250*1024*1024:raise ValueError('Update ZIP exceeds 250MB safety limit')
                f.write(b)
        got=_sha256(tmp);want=str(m.get('sha256')).lower()
        if got!=want:
            tmp.unlink(missing_ok=True);raise ValueError('Update SHA-256 mismatch; package rejected')
        pkg,root=_find_package_manifest(tmp)
        if str(pkg.get('version'))!=str(m.get('version')) or str(pkg.get('kind'))!=str(m.get('kind')):raise ValueError('Embedded update metadata does not match channel manifest')
        if _version_tuple(pkg.get('version'))<=_version_tuple(current_version):raise ValueError('Staged package is not newer than the running version')
        os.replace(tmp,STAGED_ZIP)
        meta={'manifest':m,'package':pkg,'root':root,'sha256':got,'staged_ts':time.time()};_save(STAGED_META,meta);st['staged']=meta;_save(STATE_FILE,st)
        return public_status(current_version,cfg)

def public_status(current_version,cfg):
    with _LOCK:
        st=_state();avail=st.get('available');staged=_load(STAGED_META,None) if STAGED_ZIP.exists() else None
        staged_version=((staged or {}).get('package') or {}).get('version')
        staged_reason=_quarantine_reason(staged_version)
        available_reason=_quarantine_reason((avail or {}).get('version'))
        if staged_reason or available_reason:
            blocked_version=staged_version if staged_reason else (avail or {}).get('version')
            reason=staged_reason or available_reason
            STAGED_ZIP.unlink(missing_ok=True);STAGED_META.unlink(missing_ok=True)
            staged=None;avail=None;st['staged']=None;st['available']=None
            st['last_error']=f"Update {blocked_version} blocked: {reason}. Waiting for a newer verified release."
            _save(STATE_FILE,st)
        return {
          'ok':True,'current_version':current_version,'checks_enabled':bool(cfg.get('update_checks_enabled',True)),'channel_configured':bool(str(cfg.get('update_manifest_url') or '').strip()),
          'last_check_ts':st.get('last_check_ts'),'last_error':st.get('last_error'),'available':avail,'staged':staged,
          'manual_engine_approval_required':True,'ui_auto_update_enabled':bool(cfg.get('ui_auto_update_enabled',False)),
          'security':'HTTPS manifest + allowed-host policy + SHA-256 + embedded package metadata. Withdrawn releases are blocked. Full trading-engine/risk updates always require explicit approval.'
        }

def configure_channel(url,cfg,settings_file):
    """Persist the secure manifest URL used by the running bot.

    This changes update-channel settings only. It never alters trading, risk or
    credential settings. Remote channels remain HTTPS-only and allow-host checked.
    """
    with _LOCK:
        u=str(url or '').strip()
        if u:
            _safe_remote_url(u,cfg)
        settings_file=Path(settings_file)
        persisted=_load(settings_file,{})
        if not isinstance(persisted,dict):
            persisted={}
        persisted['update_manifest_url']=u
        persisted['update_checks_enabled']=bool(u)
        persisted['engine_auto_update_enabled']=False
        _save(settings_file,persisted)
        cfg['update_manifest_url']=u
        cfg['update_checks_enabled']=bool(u)
        cfg['engine_auto_update_enabled']=False
        st=_state();st['last_error']=None;st['available']=None;_save(STATE_FILE,st)
        return public_status('',cfg)

def clear_stage():
    STAGED_ZIP.unlink(missing_ok=True);STAGED_META.unlink(missing_ok=True)
    st=_state();st['staged']=None;_save(STATE_FILE,st)

def staged_install_request(current_version):
    meta=_load(STAGED_META,None)
    if not meta or not STAGED_ZIP.exists():raise RuntimeError('No verified staged update')
    version=((meta.get('package') or {}).get('version'))
    reason=_quarantine_reason(version)
    if reason:
        clear_stage();raise RuntimeError(f'Update {version} is blocked: {reason}')
    return {'ok':True,'staged_zip':str(STAGED_ZIP),'meta':meta,'current_version':current_version}
