#!/usr/bin/env python3
"""Cumulative R5.4.2 UI migration. Never reads or writes live trading state."""
from pathlib import Path
import runpy

ROOT=Path(__file__).resolve().parent

# Make the package safe to install directly from R5.4 as well as from R5.4.1.
runpy.run_path(str(ROOT/"migrate_r541_position_values.py"),run_name="__main__")

dashboard=ROOT/"dashboard.html"
text=dashboard.read_text(encoding="utf-8")
if "CASH R:R" not in text:
    old_end="}});let unreal=rows.reduce((a,r)=>a+r.pnl,0)"
    new_end="}});rows.sort((a,b)=>(a.toStop??99)-(b.toStop??99));let unreal=rows.reduce((a,r)=>a+r.pnl,0)"
    old_symbol='''<div class="live-trade-symbol">${esc(r.symbol)}-GBP</div><span class="sub">${gbp(r.cost)} invested • ${liveAge(r.p.opened_ts)} open</span>'''
    new_symbol='''<div class="live-trade-symbol">${esc(r.symbol)}-GBP</div><span class="pill ${r.p.protection_verified_ts?'green':'amber'}" style="display:inline-flex;margin:4px 0;padding:4px 7px">${r.p.protection_verified_ts?'COINBASE PROTECTED':'VERIFYING PROTECTION'}</span><span class="sub">${gbp(r.cost)} invested • ${liveAge(r.p.opened_ts)} open</span>'''
    old_note='''<div class="live-ledger-note">Stop and target cash estimates are before the eventual Coinbase exit fee.</div>'''
    new_note='''<div class="source-health"><span>STOP RISK <b class="neg">${gbp(Math.abs(Math.min(0,r.stopPnl)))}</b></span><span>TARGET GAIN <b class="pos">+${gbp(Math.max(0,r.targetPnl))}</b></span><span>CASH R:R <b>${r.stopPnl<0&&r.targetPnl>0?(r.targetPnl/Math.abs(r.stopPnl)).toFixed(2)+' : 1':'—'}</b></span></div><div class="live-ledger-note">Stop and target cash estimates are before the eventual Coinbase exit fee. Coinbase bracket orders disable the other side after one side fills.</div>'''
    for old,new,name in ((old_end,new_end,"urgency sort"),(old_symbol,new_symbol,"protection badge"),(old_note,new_note,"cash risk strip")):
        if old not in text:raise SystemExit(f"R5.4.2 refused: expected {name} marker not found")
        text=text.replace(old,new,1)
    text=text.replace("Safety & Evidence R5.4.1</title>","Safety & Evidence R5.4.2</title>",1)
    dashboard.write_text(text,encoding="utf-8")
else:
    print("R5.4.2 protection monitor already installed")

server=ROOT/"server.py"
source=server.read_text(encoding="utf-8")
if 'VERSION = "5.13.3.1-supervised-live"' in source:
    source=source.replace('VERSION = "5.13.3.1-supervised-live"','VERSION = "5.13.3.2-supervised-live"',1)
    server.write_text(source,encoding="utf-8")
elif 'VERSION = "5.13.3.2-supervised-live"' not in source:
    raise SystemExit("R5.4.2 refused: unexpected server version")

print("R5.4.2 UI installed. Live positions, orders and safety limits were untouched.")
