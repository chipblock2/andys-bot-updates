@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "BOTURL=http://127.0.0.1:8765/"
set "HEALTH=http://127.0.0.1:8765/api/health"

rem If Andy's Bot is already running, do not start a duplicate instance.
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing '%HEALTH%' -TimeoutSec 2; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){exit 0}; exit 1 } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 goto :open_dashboard

rem Start the normal verified bot entry point minimized.
start "Andy's Bot Engine" /min cmd /c ""%~dp000_START_HERE_V5_13_2.bat""

rem Wait up to 60 seconds for the local dashboard to become ready.
for /L %%N in (1,1,60) do (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing '%HEALTH%' -TimeoutSec 1; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){exit 0}; exit 1 } catch { exit 1 }" >nul 2>nul
  if not errorlevel 1 goto :open_dashboard
  timeout /t 1 /nobreak >nul
)

echo Andy's Bot did not become ready within 60 seconds.
echo Open the main bot folder and run 00_START_HERE_V5_13_2.bat to see any startup error.
pause
exit /b 1

:open_dashboard
start "" "%BOTURL%"
exit /b 0
