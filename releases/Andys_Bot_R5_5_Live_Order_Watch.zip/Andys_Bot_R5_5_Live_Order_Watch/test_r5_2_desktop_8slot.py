#!/usr/bin/env python3
from __future__ import annotations
import copy
from pathlib import Path
import allocation_engine
import coinbase_live_canary as live
import config_guard
import engine

checks=[]
def ck(name, ok, detail=''):
    if not ok:
        raise AssertionError(f'FAIL {name}: {detail}')
    checks.append(name); print('PASS',name)

ck('hard live slot ceiling is eight', live.HARD_MAX_POSITIONS == 8, live.HARD_MAX_POSITIONS)
ck('hard order cap remains ten pounds', live.HARD_ORDER_CAP_GBP == 10.0)
ck('hard total exposure remains twenty pounds', live.HARD_EXPOSURE_CAP_GBP == 20.0)
ck('daily new-entry cap remains four', live.HARD_MAX_ORDERS_PER_DAY == 4)
ck('engine defaults to eight live slots', int(engine.CFG.get('live_max_positions')) == 8)

cfg=copy.deepcopy(engine.CFG)
cfg.update({
    'live_trading_enabled':True,'execution_mode':'live_supervised','live_bankroll_cap_gbp':100.0,
    'live_order_cap_gbp':10.0,'live_max_total_exposure_gbp':20.0,'live_max_positions':8,
    'live_max_orders_per_day':4,'live_daily_loss_limit_gbp':2.0,'live_lifetime_loss_limit_gbp':10.0,
    'live_dynamic_min_order_gbp':2.0,'live_slot_reserve_gbp':2.0,'live_max_same_bucket_positions':2,
})
ck('eight-slot supervised config validates', config_guard.validate_config(cfg)['ok'], config_guard.validate_config(cfg))
bad=dict(cfg); bad['live_max_positions']=9
ck('ninth live slot is rejected', not config_guard.validate_config(bad)['ok'], config_guard.validate_config(bad))

row={
    'coinbase_price':100.0,'calibrated_probability':0.88,'expected_return':0.04,'required_edge':0.008,
    'decision_council':{'score':96},'market_opportunity':{'activity_score':92},
    'market_quality':{'score':96,'pass':True},'order_flow':{'quality':'HIGH','score':45},
    'trade_plan':{'stop_price':96.0},'meme_intelligence':{'is_meme':False},
}
first=allocation_engine.plan('LINK',row,{},cfg,hard_bankroll=100,hard_order_cap=10,hard_exposure_cap=20)
ck('first entry reserves capacity for seven future slots', first['remaining_slots_after']==7, first)
ck('first entry cannot consume whole portfolio', 0.0 < first['quote_size_gbp'] <= 6.0, first)

canary_src=Path('coinbase_live_canary.py').read_text(encoding='utf-8')
ck('live adapter blocks when all eight slots are occupied', 'len(state.get("positions") or {}) >= min(int(settings.get("live_max_positions", HARD_MAX_POSITIONS)), HARD_MAX_POSITIONS)' in canary_src)

launcher=Path('START_ANDYS_BOT_DESKTOP.bat').read_text(encoding='utf-8')
installer=Path('INSTALL_DESKTOP_ANDYS_BOT.bat').read_text(encoding='utf-8')
ck('desktop launcher checks health before starting', '/api/health' in launcher and 'already running' in launcher.lower())
ck('desktop launcher opens local dashboard', '127.0.0.1:8765' in launcher and 'start "" "%BOTURL%"' in launcher)
ck('desktop shortcut installer targets user desktop', "SpecialFolders.Item('Desktop')" in installer and 'Andys Bot.lnk' in installer)
ck('desktop icon is bundled', Path('andys_bot.ico').exists() and Path('andys_bot.ico').stat().st_size>1000)

html=Path('dashboard.html').read_text(encoding='utf-8').lower()
ck('dashboard advertises eight live positions', 'up to eight positions' in html)
ck('manual real-trade approval remains in dashboard', 'approve live trade' in html and 'preview live trade' in html)

print(f'PASS {len(checks)}/{len(checks)} R5.2 desktop + eight-slot checks')
