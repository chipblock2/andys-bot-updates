#!/usr/bin/env python3
"""Read-only Coinbase user-channel order monitor.

The stream improves visibility and latency only. REST reconciliation in
``coinbase_live_canary`` remains authoritative for every fill, position close,
fee, stop and target decision. This module never submits, edits or cancels an
order and never persists an API key, private key, JWT, balance or order size.
"""
from __future__ import annotations

import json
import math
import threading
import time
from pathlib import Path
from typing import Any, Callable

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "coinbase_live_config.json"

SAFE_FIELDS = {
    "order_id",
    "client_order_id",
    "product_id",
    "status",
    "order_side",
    "order_type",
    "completion_percentage",
    "trigger_status",
    "creation_time",
    "end_time",
    "edit_history",
}


def _as_dict(value: Any) -> dict:
    if isinstance(value, dict):
        return value
    fn = getattr(value, "to_dict", None)
    if callable(fn):
        try:
            out = fn()
            return out if isinstance(out, dict) else {}
        except Exception:
            return {}
    return {}


def _load(path: Path) -> dict:
    try:
        out = json.loads(Path(path).read_text(encoding="utf-8"))
        return out if isinstance(out, dict) else {}
    except Exception:
        return {}


def _finite(value: Any, default: float | None = None) -> float | None:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except Exception:
        return default


def decode_message(message: Any) -> dict:
    """Decode the SDK's raw JSON without accepting non-object payloads."""
    if isinstance(message, (bytes, bytearray)):
        try:
            message = bytes(message).decode("utf-8")
        except Exception:
            return {}
    if isinstance(message, str):
        try:
            message = json.loads(message)
        except Exception:
            return {}
    return _as_dict(message)


def parse_user_message(message: Any, seen_ts: float | None = None) -> list[dict]:
    """Return a deliberately small, non-financial order-event projection."""
    data = decode_message(message)
    stamp = time.time() if seen_ts is None else float(seen_ts)
    out: list[dict] = []
    for event in data.get("events") or []:
        event = _as_dict(event)
        for order in event.get("orders") or []:
            order = _as_dict(order)
            clean = {key: order.get(key) for key in SAFE_FIELDS if key in order}
            clean["seen_ts"] = stamp
            out.append(clean)
    return out


class OrderEventMonitor:
    """Supervise one authenticated, observational Coinbase user connection."""

    def __init__(
        self,
        config_file: Path = CONFIG_FILE,
        client_factory: Callable[..., Any] | None = None,
        clock: Callable[[], float] = time.time,
    ):
        self._lock = threading.RLock()
        self._config_file = Path(config_file)
        self._client_factory = client_factory
        self._clock = clock
        self._events: list[dict] = []
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._client = None
        self._connected = False
        self._subscribed = False
        self._last_message_ts: float | None = None
        self._last_user_event_ts: float | None = None
        self._last_heartbeat_ts: float | None = None
        self._last_heartbeat_counter: int | None = None
        self._last_sequence_num: dict[str, int] = {}
        self._missed_messages = 0
        self._connections = 0
        self._last_error: str | None = None
        self._configured = False

    def _factory(self):
        if self._client_factory is not None:
            return self._client_factory
        from coinbase.websocket import WSUserClient

        return WSUserClient

    def _configuration(self) -> tuple[bool, Path | None]:
        cfg = _load(self._config_file)
        key = Path(str(cfg.get("key_file") or "")).expanduser()
        enabled = cfg.get("enabled") is True and bool(str(cfg.get("key_file") or "").strip())
        return enabled and key.is_file(), key if enabled else None

    def _on_open(self, *_args) -> None:
        with self._lock:
            self._connected = True
            self._connections += 1
            self._last_error = None

    def _on_close(self, *_args) -> None:
        with self._lock:
            self._connected = False
            self._subscribed = False

    def _on_message(self, message: Any) -> None:
        data = decode_message(message)
        if not data:
            return
        now = self._clock()
        channel = str(data.get("channel") or data.get("type") or "").lower()
        sequence = _finite(data.get("sequence_num"))
        rows = parse_user_message(data, seen_ts=now) if channel == "user" else []
        with self._lock:
            self._last_message_ts = now
            if sequence is not None:
                seq = int(sequence)
                previous = self._last_sequence_num.get(channel)
                if previous is not None and seq > previous + 1:
                    self._missed_messages += seq - previous - 1
                if previous is None or seq >= previous:
                    self._last_sequence_num[channel] = seq
            if channel == "heartbeats":
                self._last_heartbeat_ts = now
                events = data.get("events") or []
                counter = _finite((_as_dict(events[0])).get("heartbeat_counter")) if events else None
                if counter is not None:
                    counter = int(counter)
                    if self._last_heartbeat_counter is not None and counter > self._last_heartbeat_counter + 1:
                        self._missed_messages += counter - self._last_heartbeat_counter - 1
                    self._last_heartbeat_counter = counter
            if rows:
                self._last_user_event_ts = now
                merged = rows + self._events
                unique: list[dict] = []
                seen: set[str] = set()
                for row in merged:
                    identity = str(row.get("order_id") or row.get("client_order_id") or "")
                    if identity and identity in seen:
                        continue
                    if identity:
                        seen.add(identity)
                    unique.append(row)
                self._events = unique[:25]

    def ingest(self, message: Any) -> None:
        """Compatibility/test hook; applies exactly the live sanitisation path."""
        self._on_message(message)

    def _safe_close(self) -> None:
        client = self._client
        self._client = None
        if client is not None:
            try:
                client.close()
            except Exception:
                pass
        self._on_close()

    def _run(self) -> None:
        delay = 2.0
        while not self._stop.is_set():
            configured, key_file = self._configuration()
            with self._lock:
                self._configured = configured
            if not configured or key_file is None:
                self._safe_close()
                self._stop.wait(5.0)
                continue
            try:
                factory = self._factory()
                client = factory(
                    key_file=str(key_file),
                    on_message=self._on_message,
                    on_open=self._on_open,
                    on_close=self._on_close,
                    timeout=10,
                    max_size=2 * 1024 * 1024,
                    retry=True,
                    verbose=False,
                )
                self._client = client
                client.open()
                # An empty product list intentionally subscribes to every product.
                client.user([])
                client.heartbeats()
                with self._lock:
                    self._subscribed = True
                    self._last_error = None
                delay = 2.0
                started = self._clock()
                while not self._stop.wait(2.0):
                    client.raise_background_exception()
                    current_configured, current_key = self._configuration()
                    if not current_configured or current_key != key_file:
                        break
                    with self._lock:
                        heartbeat = self._last_heartbeat_ts
                    if self._clock() - started > 20.0 and (heartbeat is None or self._clock() - heartbeat > 15.0):
                        raise RuntimeError("Coinbase user-channel heartbeat became stale")
            except Exception as exc:
                with self._lock:
                    self._last_error = str(exc)
            finally:
                self._safe_close()
            if not self._stop.is_set():
                self._stop.wait(delay)
                delay = min(30.0, delay * 2.0)

    def start(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop.clear()
            self._thread = threading.Thread(target=self._run, name="coinbase-user-order-watch", daemon=True)
            self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._safe_close()
        thread = self._thread
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=3.0)

    def status(self) -> dict:
        now = self._clock()
        with self._lock:
            heartbeat_age = None if self._last_heartbeat_ts is None else max(0.0, now - self._last_heartbeat_ts)
            event_age = None if self._last_user_event_ts is None else max(0.0, now - self._last_user_event_ts)
            fresh = bool(self._connected and self._subscribed and heartbeat_age is not None and heartbeat_age <= 10.0)
            if not self._configured:
                state = "NOT CONFIGURED"
            elif fresh:
                state = "USER CHANNEL LIVE"
            elif self._last_error:
                state = "REST FALLBACK"
            elif self._connected:
                state = "CONNECTING"
            else:
                state = "RECONNECTING"
            return {
                "ok": fresh,
                "configured": self._configured,
                "mode": "OBSERVATIONAL",
                "state": state,
                "connected": self._connected,
                "subscribed": self._subscribed,
                "rest_authoritative": True,
                "heartbeat_age_seconds": heartbeat_age,
                "last_event_age_seconds": event_age,
                "last_event_ts": self._last_user_event_ts,
                "missed_messages": self._missed_messages,
                "connections": self._connections,
                "last_error": self._last_error,
                "events": list(self._events),
                "submits_orders": False,
                "edits_orders": False,
                "cancels_orders": False,
                "stores_credentials": False,
            }


SERVICE = OrderEventMonitor()
