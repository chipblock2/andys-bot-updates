ANDY'S BOT — LIVE ORDER WATCH R5.5

Install through Live Update and confirm the full update on this PC.

What changes:
- Adds the official Coinbase authenticated user WebSocket for observational order updates.
- Adds Coinbase heartbeats and stale-stream reconnects.
- Shows ORDER WATCH LIVE or REST FALLBACK beside the live portfolio.
- Includes every R5.4.1 and R5.4.2 position-value/protection display improvement.
- Keeps Coinbase REST as the authority for fills, fees, stop and target verification.

What does NOT change:
- Existing ETH, LINK or any other open position.
- Existing Coinbase bracket orders.
- Credentials, trade history, journals or evidence.
- GBP10 maximum per approved order.
- GBP20 total live exposure.
- Eight maximum open positions and four new entries per day.
- GBP2 daily and GBP10 lifetime realised-loss breakers.
- Manual PC Preview then Approve for every real-money entry.

The WebSocket is read-only and observational. It cannot submit, edit, cancel or
approve an order. If it is unavailable, the dashboard shows REST FALLBACK and the
existing Coinbase REST reconciliation continues.
