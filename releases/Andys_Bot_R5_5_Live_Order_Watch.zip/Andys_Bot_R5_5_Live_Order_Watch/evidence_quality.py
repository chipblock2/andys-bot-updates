#!/usr/bin/env python3
"""Read-only evidence gate. It reports readiness; it never enables a strategy."""
from __future__ import annotations
import csv, json
from pathlib import Path

BASE = Path(__file__).resolve().parent

def _closed(path: Path) -> tuple[int, float]:
    try:
        rows=list(csv.DictReader(path.open(encoding="utf-8-sig", newline="")))
    except Exception:
        return 0, 0.0
    pnl=[]
    for row in rows:
        if str(row.get("side") or row.get("action") or "").upper() != "SELL": continue
        try: pnl.append(float(row.get("pnl_gbp") or row.get("pnl") or 0))
        except Exception: pass
    return len(pnl), sum(pnl)

def snapshot() -> dict:
    normal_n, normal_pnl = _closed(BASE / "paper_trades.csv")
    mm_n, mm_pnl = _closed(BASE / "market_maker_lab_trades.csv")
    robust_assets=0
    try:
        raw=json.loads((BASE/"historical_robustness.json").read_text(encoding="utf-8"))
        rows=raw.get("rows") if isinstance(raw,dict) else raw
        robust_assets=len(rows or [])
    except Exception: pass
    reasons=[]
    if normal_n < 30: reasons.append(f"normal paper evidence {normal_n}/30 closed trades")
    if robust_assets < 3: reasons.append(f"historical robustness {robust_assets}/3 assets")
    allowed=not reasons
    mm_locked=mm_n < 100 or mm_pnl <= 0
    return {"ok":True,"read_only":True,"strategy_promotion_allowed":allowed,
            "normal_closed_trades":normal_n,"normal_pnl_gbp":round(normal_pnl,2),
            "robust_assets":robust_assets,"reasons":reasons,
            "market_maker_closed_trades":mm_n,"market_maker_pnl_gbp":round(mm_pnl,2),
            "market_maker_live_locked":mm_locked,
            "note":"Evidence can block promotion but cannot enable live trading or raise a risk limit."}
