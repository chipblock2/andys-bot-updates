from pathlib import Path
ROOT=Path(__file__).resolve().parent
html=(ROOT/"dashboard.html").read_text(encoding="utf-8")
server=(ROOT/"server.py").read_text(encoding="utf-8")
checks={
 "R5.4.1 cash clarity included":"Your money</span>" in html and "Price per ${esc(r.symbol)}" in html,
 "Coinbase protection badge":"COINBASE PROTECTED" in html and "VERIFYING PROTECTION" in html,
 "cash stop risk shown":"STOP RISK" in html and "Math.min(0,r.stopPnl)" in html,
 "cash target gain shown":"TARGET GAIN" in html and "Math.max(0,r.targetPnl)" in html,
 "cash risk reward shown":"CASH R:R" in html and "r.targetPnl/Math.abs(r.stopPnl)" in html,
 "urgent positions sort first":"rows.sort((a,b)=>(a.toStop??99)-(b.toStop??99))" in html,
 "bracket behaviour explained":"disable the other side after one side fills" in html,
 "version advanced":'VERSION = "5.13.3.2-supervised-live"' in server,
 "manual approval retained":'id="liveApproveBtn"' in html and "real order submission is never automatic" in html.lower(),
 "hard caps retained":"£10/order" in html and "£20 total exposure" in html,
}
for name,ok in checks.items():
 print("PASS" if ok else "FAIL",name)
 if not ok:raise SystemExit(1)
print(f"RESULT {len(checks)}/{len(checks)} passed")
