#!/usr/bin/env python3
"""R5.4.1 UI-only migration. Does not read or write trading state."""
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
dashboard=ROOT/"dashboard.html"
server=ROOT/"server.py"

text=dashboard.read_text(encoding="utf-8")
old_calc="toStop=(live>0&&stop>0)?(live-stop)/live:null,toTarget=(live>0&&target>0)?(target-live)/live:null,span=target-stop"
new_calc="stopValue=(qty>0&&stop>0)?qty*stop:0,targetValue=(qty>0&&target>0)?qty*target:0,stopPnl=stopValue-cost,targetPnl=targetValue-cost,toStop=(live>0&&stop>0)?(live-stop)/live:null,toTarget=(live>0&&target>0)?(target-live)/live:null,span=target-stop"
old_return="return {symbol,p,live,qty,cost,entry,stop,target,value,pnl,pnlPct,toStop,toTarget,progress}"
new_return="return {symbol,p,live,qty,cost,entry,stop,target,value,pnl,pnlPct,stopValue,targetValue,stopPnl,targetPnl,toStop,toTarget,progress}"
old_card='''<div class="live-trade-meta"><div><span>Coinbase buy fill → market</span><b>${gbp(r.entry)} → ${gbp(r.live)}</b></div><div><span>Position value now</span><b>${gbp(r.value)}</b></div><div><span>Coinbase stop</span><b>${gbp(r.stop)} ${r.toStop==null?'':`• ${pct(r.toStop)} away`}</b></div><div><span>Coinbase target</span><b>${gbp(r.target)} ${r.toTarget==null?'':`• ${pct(r.toTarget)} away`}</b></div></div>'''
new_card='''<div class="live-trade-meta"><div><span>Your money</span><b>${gbp(r.cost)} invested → ${gbp(r.value)} now</b></div><div><span>Price per ${esc(r.symbol)}</span><b>Bought ${gbp(r.entry)} → now ${gbp(r.live)}</b></div><div><span>Stop plan</span><b>${esc(r.symbol)} ${gbp(r.stop)} → est. ${gbp(r.stopValue)} <span class="${r.stopPnl>=0?'pos':'neg'}">(${r.stopPnl>=0?'+':''}${gbp(r.stopPnl)})</span></b></div><div><span>Target plan</span><b>${esc(r.symbol)} ${gbp(r.target)} → est. ${gbp(r.targetValue)} <span class="${r.targetPnl>=0?'pos':'neg'}">(${r.targetPnl>=0?'+':''}${gbp(r.targetPnl)})</span></b></div></div><div class="live-ledger-note">Stop and target cash estimates are before the eventual Coinbase exit fee.</div>'''

if "Your money</span>" in text and "Stop and target cash estimates" in text:
    print("R5.4.1 clear position values already installed")
else:
    for old,new,name in ((old_calc,new_calc,"cash calculations"),(old_return,new_return,"cash fields"),(old_card,new_card,"position card")):
        if old not in text:
            raise SystemExit(f"R5.4.1 refused: expected R5.4 {name} was not found")
        text=text.replace(old,new,1)
    text=text.replace("Andy’s Bot — Safety & Evidence R5.4</title>","Andy’s Bot — Safety & Evidence R5.4.1</title>",1)
    dashboard.write_text(text,encoding="utf-8")

source=server.read_text(encoding="utf-8")
if 'VERSION = "5.13.3-supervised-live"' in source:
    source=source.replace('VERSION = "5.13.3-supervised-live"','VERSION = "5.13.3.1-supervised-live"',1)
    server.write_text(source,encoding="utf-8")
elif 'VERSION = "5.13.3.1-supervised-live"' not in source:
    raise SystemExit("R5.4.1 refused: unexpected server version")

print("R5.4.1 UI installed. Live positions, orders and settings were not touched.")
