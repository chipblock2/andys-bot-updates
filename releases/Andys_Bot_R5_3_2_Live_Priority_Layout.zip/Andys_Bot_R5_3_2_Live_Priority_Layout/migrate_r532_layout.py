#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def replace_any(path: Path, olds, new):
    text=path.read_text(encoding='utf-8')
    if new in text: return False
    for old in olds:
        if old in text:
            path.write_text(text.replace(old,new),encoding='utf-8'); return True
    raise RuntimeError(f'Expected update anchor not found in {path.name}')

def patch_tests():
    patches = {
        'test_v5122_charts_replay.py': [("pkg['version']=='5.13.2-live-canary'", "str(pkg.get('version') or '').startswith('5.13.2')")],
        'test_v5123_performance_multiexchange.py': [("pkg.get('version')=='5.13.2-live-canary'", "str(pkg.get('version') or '').startswith('5.13.2')"), ("pkg.get('migration_script')=='migrate_v5123.py'", "pkg.get('migration_script') in ('','migrate_v5123.py','migrate_r531_test.py','migrate_r532_layout.py')")],
        'test_v5124_order_safety.py': [("pkg.get('version')=='5.13.2-live-canary'", "str(pkg.get('version') or '').startswith('5.13.2')")],
        'test_v5130_research_integrity.py': [("server.VERSION=='5.13.2-live-canary'", "str(server.VERSION).startswith('5.13.2')")],
        'test_v5132_catalyst_fusion_r1.py': [("server.VERSION=='5.13.2-live-canary'", "str(server.VERSION).startswith('5.13.2')")],
        'test_r5_3_live_portfolio_dashboard.py': [("build.get('patch')=='R5.3'", "str(build.get('patch') or '').startswith('R5.3')")],
        'test_v5122_opportunity_updater.py': [("'Secure Software Updates' in dash", "('Secure Software Updates' in dash or 'Secure Live Updates' in dash)")],
        'test_v5131_btc_regime_breadth.py': [("(\"AUTO-PILOT SUPERVISED R4\" in dashboard or \"FULL COINBASE GBP SCANNER + £100 SUPERVISED LIVE\" in dashboard)", "(\"AUTO-PILOT SUPERVISED R4\" in dashboard or \"FULL COINBASE GBP SCANNER + £100 SUPERVISED LIVE\" in dashboard or \"MULTI-VENUE EDGE R5\" in dashboard)")],
    }
    for name,reps in patches.items():
        p=ROOT/name
        if not p.exists(): continue
        text=p.read_text(encoding='utf-8')
        for old,new in reps:
            if old in text: text=text.replace(old,new)
        p.write_text(text,encoding='utf-8')

def patch_dashboard():
    p=ROOT/'dashboard.html'
    s=p.read_text(encoding='utf-8')
    if 'R5.3.2 PRIORITY LAYOUT' in s: return
    old_nav = '''    <button class="active" data-view="overview"><span class="dot"></span>Command Centre</button>
    <button data-view="opportunities"><span class="dot"></span>Opportunities</button>
    <button data-view="intelligence"><span class="dot"></span>AI & Timeframes</button>
    <button data-view="smartintel"><span class="dot"></span>Smart AI + News</button>
    <button data-view="edgeintel"><span class="dot"></span>Edge & Market Intel</button>
    <button data-view="chartsreplay"><span class="dot"></span>Charts & Replay</button>
    <button data-view="positions"><span class="dot"></span>Positions & Trades</button>'''
    new_nav = '''    <button class="active" data-view="overview"><span class="dot"></span>Live Dashboard</button>
    <button data-view="positions"><span class="dot"></span>Live Positions & Trades</button>
    <button data-view="opportunities"><span class="dot"></span>Opportunities</button>
    <button data-view="chartsreplay"><span class="dot"></span>Charts & Replay</button>
    <button data-view="smartintel"><span class="dot"></span>Smart AI + News</button>
    <button data-view="intelligence"><span class="dot"></span>AI & Timeframes</button>
    <button data-view="edgeintel"><span class="dot"></span>Edge & Market Intel</button>'''
    if old_nav not in s: raise RuntimeError('Navigation anchor not found')
    s=s.replace(old_nav,new_nav)
    approval_start=s.index(' <div class="card" id="liveApprovalCard"')
    portfolio_start=s.index(' <div class="card live-portfolio-card" id="livePortfolioCard"')
    hero_start=s.index(' <div class="hero512">', portfolio_start)
    approval=s[approval_start:portfolio_start]
    portfolio=s[portfolio_start:hero_start]
    s=s[:approval_start]+s[hero_start:]
    portfolio=portfolio.replace('id="livePortfolioCard" style="margin-top:12px"','id="livePortfolioCard" style="margin-top:0"')
    section_anchor='<section class="view active" id="overview">\n'
    if section_anchor not in s: raise RuntimeError('Overview anchor not found')
    s=s.replace(section_anchor, section_anchor+portfolio+approval,1)
    old_pill='<span class="pill green" id="livePortfolioPill">0/8 OPEN</span></div>'
    new_pill='<div class="live-head-actions"><span class="pill green" id="livePortfolioPill">0/8 OPEN</span><button class="btn" id="portfolioDetailsBtn" type="button">View all trades</button></div></div>'
    if old_pill in s: s=s.replace(old_pill,new_pill,1)
    old_pos='<section class="view" id="positions">\n <div class="sectionhead"><div><h2>Positions & Trades</h2><p>Real Coinbase supervised positions first, then the separate paper-training ledger.</p></div><span class="pill green">LIVE + PAPER</span></div>'
    new_pos='<section class="view" id="positions">\n <div class="sectionhead"><div><h2>Live Positions & Trades</h2><p>Real Coinbase supervised positions first. Paper-training evidence stays below and visually separate.</p></div><div class="action-row"><button class="btn" id="backLiveDashBtn" type="button">← Live dashboard</button><span class="pill green">LIVE + PAPER</span></div></div>'
    if old_pos in s: s=s.replace(old_pos,new_pos,1)
    css='''
/* R5.3.2 PRIORITY LAYOUT — live state first, diagnostics second */
#nav button[data-view="positions"]{border-color:#315c77;background:linear-gradient(90deg,#102b3d,#0b1c29);font-weight:800}
#livePortfolioCard{border-color:#2f745a;box-shadow:0 0 0 1px rgba(85,225,157,.08),0 12px 30px rgba(0,0,0,.16)}
#livePortfolioCard .live-portfolio-head h2{font-size:22px;letter-spacing:.02em}
.live-head-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:flex-end}
#liveApprovalCard{border-color:#66542b!important;background:linear-gradient(180deg,rgba(103,78,30,.12),rgba(11,25,37,.8))}
#healthStrip{opacity:.92}
#overview>.risk-banner{margin-top:12px}
#positions>.sectionhead{position:sticky;top:0;z-index:3;background:rgba(7,16,25,.96);backdrop-filter:blur(8px);padding:8px 0 10px}
@media(max-width:760px){.live-head-actions{justify-content:flex-start}.live-summary-grid{grid-template-columns:repeat(2,minmax(0,1fr))}#livePortfolioCard .live-portfolio-head h2{font-size:19px}}
'''
    s=s.replace('</style>',css+'</style>',1)
    js_anchor="document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>nav(b.dataset.view));if(location.hash)nav(location.hash.slice(1));"
    js_new=js_anchor+"if($('portfolioDetailsBtn'))$('portfolioDetailsBtn').onclick=()=>nav('positions');if($('backLiveDashBtn'))$('backLiveDashBtn').onclick=()=>nav('overview');"
    if js_anchor not in s: raise RuntimeError('Nav JS anchor not found')
    s=s.replace(js_anchor,js_new,1)
    s=s.replace('<title>Andy’s Bot — Multi-Venue Edge R5.3 Live Portfolio</title>','<title>Andy’s Bot — R5.3.2 Live Priority Dashboard</title>',1)
    s=s.replace('</body>','<!-- R5.3.2 PRIORITY LAYOUT -->\n</body>',1)
    p.write_text(s,encoding='utf-8')

def main():
    server=ROOT/'server.py'
    replace_any(server,['VERSION = "5.13.2-live-canary"','VERSION = "5.13.2.1"'],'VERSION = "5.13.2.2"')
    patch_tests(); patch_dashboard()
    info_path=ROOT/'BUILD_INFO.json'
    try: info=json.loads(info_path.read_text(encoding='utf-8')) if info_path.exists() else {}
    except Exception: info={}
    info.update({'package_type':'andys-bot-build-info','product':"Andy's Bot — Crypto AI Autopilot",'compatibility_version':'5.13.2.2','semantic_version':'5.13.2.2','release':'Multi-Venue Edge R5.3.2','patch':'R5.3.2','sidebar_label':'v5.13.2.2 • Multi-Venue Edge R5.3.2','topbar_label':'v5.13.2.2 • R5.3.2 LIVE PRIORITY','full_label':"Andy's Bot v5.13.2.2 — R5.3.2 Live Priority Dashboard",'layout_priority':['live portfolio','live approval/action','system health','strategy context','research/labs'],'built_utc':'2026-08-22T09:40:00Z'})
    info_path.write_text(json.dumps(info,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return 0
if __name__=='__main__': raise SystemExit(main())
