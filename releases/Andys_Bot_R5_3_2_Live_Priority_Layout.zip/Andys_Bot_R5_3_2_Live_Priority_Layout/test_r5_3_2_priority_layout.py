from pathlib import Path
import json
s=Path('dashboard.html').read_text(encoding='utf-8')
checks=[]
def ck(name,cond):
    checks.append((name,bool(cond)));print(('PASS' if cond else 'FAIL'),name)
ck('priority marker','R5.3.2 PRIORITY LAYOUT' in s)
ck('positions second nav',s.index('data-view="positions"') < s.index('data-view="opportunities"'))
ck('live portfolio before health',s.index('id="livePortfolioCard"') < s.index('id="healthStrip"'))
ck('approval before health',s.index('id="liveApprovalCard"') < s.index('id="healthStrip"'))
ck('portfolio drilldown','id="portfolioDetailsBtn"' in s and "nav('positions')" in s)
ck('positions return','id="backLiveDashBtn"' in s and "nav('overview')" in s)
ck('live first label','Live Positions & Trades' in s)
bi=json.loads(Path('BUILD_INFO.json').read_text(encoding='utf-8'))
ck('build patch',bi.get('patch')=='R5.3.2')
if not all(v for _,v in checks): raise SystemExit(1)
print(f'{sum(v for _,v in checks)}/{len(checks)} PASS')
