from pathlib import Path
ROOT=Path(__file__).resolve().parent
html=(ROOT/"dashboard.html").read_text(encoding="utf-8")
server=(ROOT/"server.py").read_text(encoding="utf-8")
checks={
 "cash position is primary":"Your money</span>" in html and "${gbp(r.cost)} invested → ${gbp(r.value)} now" in html,
 "per-coin price is explicit":"Price per ${esc(r.symbol)}" in html,
 "stop cash outcome shown":"stopValue" in html and "stopPnl" in html,
 "target cash outcome shown":"targetValue" in html and "targetPnl" in html,
 "exit fee caveat shown":"before the eventual Coinbase exit fee" in html,
 "updater version advanced":'VERSION = "5.13.3.1-supervised-live"' in server,
 "manual approval retained":'id="liveApproveBtn"' in html and "real order submission is never automatic" in html.lower(),
 "hard caps still displayed":"£10/order" in html and "£20 total exposure" in html,
}
for name,ok in checks.items():
 print("PASS" if ok else "FAIL",name)
 if not ok:raise SystemExit(1)
print(f"RESULT {len(checks)}/{len(checks)} passed")
