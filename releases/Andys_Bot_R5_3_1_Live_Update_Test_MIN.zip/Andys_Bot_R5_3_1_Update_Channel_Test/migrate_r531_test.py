#!/usr/bin/env python3
from __future__ import annotations
import json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def replace_required(path: Path, old: str, new: str):
    text = path.read_text(encoding='utf-8')
    if old in text:
        path.write_text(text.replace(old, new), encoding='utf-8')
        return True
    if new in text:
        return False
    raise RuntimeError(f'Expected update anchor not found in {path.name}')


def main():
    server = ROOT / 'server.py'
    replace_required(server, 'VERSION = "5.13.2-live-canary"', 'VERSION = "5.13.2.1"')

    patches = {
        'test_v5122_charts_replay.py': [
            ("pkg['version']=='5.13.2-live-canary'", "str(pkg.get('version') or '').startswith('5.13.2')"),
        ],
        'test_v5123_performance_multiexchange.py': [
            ("pkg.get('version')=='5.13.2-live-canary'", "str(pkg.get('version') or '').startswith('5.13.2')"),
            ("pkg.get('migration_script')=='migrate_v5123.py'", "pkg.get('migration_script') in ('','migrate_v5123.py','migrate_r531_test.py')"),
        ],
        'test_v5124_order_safety.py': [
            ("pkg.get('version')=='5.13.2-live-canary'", "str(pkg.get('version') or '').startswith('5.13.2')"),
        ],
        'test_v5130_research_integrity.py': [
            ("server.VERSION=='5.13.2-live-canary'", "str(server.VERSION).startswith('5.13.2')"),
        ],
        'test_v5132_catalyst_fusion_r1.py': [
            ("server.VERSION=='5.13.2-live-canary'", "str(server.VERSION).startswith('5.13.2')"),
        ],
    }
    patches['test_r5_3_live_portfolio_dashboard.py'] = [("build.get('patch')=='R5.3'", "str(build.get('patch') or '').startswith('R5.3')")]
    for name, reps in patches.items():
        p = ROOT / name
        if not p.exists():
            continue
        for old, new in reps:
            text = p.read_text(encoding='utf-8')
            if old in text:
                p.write_text(text.replace(old, new), encoding='utf-8')

    info_path = ROOT / 'BUILD_INFO.json'
    try:
        info = json.loads(info_path.read_text(encoding='utf-8')) if info_path.exists() else {}
    except Exception:
        info = {}
    info.update({
        'package_type': 'andys-bot-build-info',
        'product': "Andy's Bot — Crypto AI Autopilot",
        'compatibility_version': '5.13.2.1',
        'semantic_version': '5.13.2.1',
        'release': 'Multi-Venue Edge R5.3.1',
        'patch': 'R5.3.1',
        'sidebar_label': 'v5.13.2.1 • Multi-Venue Edge R5.3.1',
        'topbar_label': 'v5.13.2.1 • R5.3.1 UPDATE TEST ✅',
        'full_label': "Andy's Bot v5.13.2.1 — R5.3.1 Update Channel Test",
        'built_utc': '2026-08-22T08:53:00Z',
        'update_test': 'PASS MARKER — installed through secure Live Update channel',
    })
    info_path.write_text(json.dumps(info, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    (ROOT / 'UPDATE_TEST_MARKER.txt').write_text('R5.3.1 update channel test installed successfully.\n', encoding='utf-8')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
